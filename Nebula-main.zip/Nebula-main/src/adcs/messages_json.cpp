#include "messages_json.h"

namespace adcs::messages {

std::string get_messages_json() {
  return R"END([
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Perform a reset - Table 10: Reset Command Format",
        "ID": "1",
        "Length (bytes)": "1",
        "Name": "Reset"
      },
      {
        "Description": "Reset pointer to log buffer (from where LastLogEvent TLM is returned) - Table 11: Reset Log Pointer Command Format",
        "ID": "4",
        "Length (bytes)": "0",
        "Name": "Reset Log Pointer"
      },
      {
        "Description": "Advance pointer to log buffer (from where LastLogEvent TLM is returned) - Table 12: Advance Log Pointer Command Format",
        "ID": "5",
        "Length (bytes)": "0",
        "Name": "Advance Log Pointer"
      },
      {
        "Description": "Reset Boot Registers - Table 13: Reset Boot Registers Command Format",
        "ID": "6",
        "Length (bytes)": "0",
        "Name": "Reset Boot Registers"
      },
      {
        "Description": "Format SD card - Table 14: Format SD card Command Format",
        "ID": "33",
        "Length (bytes)": "1",
        "Name": "Format SD card"
      },
      {
        "Description": "Erase File - Table 15: Erase File Command Format",
        "ID": "108",
        "Length (bytes)": "3",
        "Name": "Erase File"
      },
      {
        "Description": "Fill download buffer with file contents - Table 17: Load File Download Block Command Format",
        "ID": "112",
        "Length (bytes)": "8",
        "Name": "Load File Download Block"
      },
      {
        "Description": "Advance File List Read Pointer - Table 18: Advance File List Read Pointer Command Format",
        "ID": "113",
        "Length (bytes)": "0",
        "Name": "Advance File List Read Pointer"
      },
      {
        "Description": "Initiate File Upload - Table 19: Initiate File Upload Command Format",
        "ID": "114",
        "Length (bytes)": "2",
        "Name": "Initiate File Upload"
      },
      {
        "Description": "File Upload Packet - Table 21: File Upload Packet Command Format",
        "ID": "115",
        "Length (bytes)": "22",
        "Name": "File Upload Packet"
      },
      {
        "Description": "Finalize Uploaded File Block - Table 22: Finalize Upload Block Command Format",
        "ID": "116",
        "Length (bytes)": "7",
        "Name": "Finalize Upload Block"
      },
      {
        "Description": "Reset HoleMap for Upload Block - Table 23: Reset Upload Block Command Format",
        "ID": "117",
        "Length (bytes)": "0",
        "Name": "Reset Upload Block"
      },
      {
        "Description": "Reset File List Read Pointer - Table 24: Reset File List Read Pointer Command Format",
        "ID": "118",
        "Length (bytes)": "0",
        "Name": "Reset File List Read Pointer"
      },
      {
        "Description": "Initiate Download Burst - Table 25: Initiate Download Burst Command Format",
        "ID": "119",
        "Length (bytes)": "2",
        "Name": "Initiate Download Burst"
      }
    ],
    "Table": "Table 9: List of Common Telecommands"
  },
  {
    "Properties": {
      "Description": "Perform a reset",
      "ID": "1",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Magic number to make sure it is a valid reset command. Should equal 0x5A",
        "Length (bits)": "8",
        "Name": "Magic number",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 10: Reset Command Format"
  },
  {
    "Properties": {
      "Description": "Reset pointer to log buffer (from where LastLogEvent TLM is returned)",
      "ID": "4",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 11: Reset Log Pointer Command Format"
  },
  {
    "Properties": {
      "Description": "Advance pointer to log buffer (from where LastLogEvent TLM is returned)",
      "ID": "5",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 12: Advance Log Pointer Command Format"
  },
  {
    "Properties": {
      "Description": "Reset Boot Registers",
      "ID": "6",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 13: Reset Boot Registers Command Format"
  },
  {
    "Properties": {
      "Description": "Format SD card",
      "ID": "33",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Magic number to prevent against accidental format. Has to be set to 90 (0x5A)",
        "Length (bits)": "8",
        "Name": "Magic Number",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 14: Format SD card Command Format"
  },
  {
    "Properties": {
      "Description": "Erase File",
      "ID": "108",
      "Parameters Length (bytes)": "3"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "File Type. Possible values are in Table 16: FileType Enumeration Values",
        "Length (bits)": "8",
        "Name": "File Type",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "File Counter",
        "Length (bits)": "8",
        "Name": "File Counter",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "BOOL",
        "Description": "Erase All",
        "Length (bits)": "1",
        "Name": "Erase All",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 15: Erase File Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Telemetry Log File",
        "Name": "Telemetry Log",
        "Numeric Value": "2"
      },
      {
        "Description": "JPG Image File",
        "Name": "JPG Image",
        "Numeric Value": "3"
      },
      {
        "Description": "BMP Image File",
        "Name": "BMP Image",
        "Numeric Value": "4"
      },
      {
        "Description": "Index File",
        "Name": "Index",
        "Numeric Value": "15"
      }
    ],
    "Table": "Table 16: FileType Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Fill download buffer with file contents",
      "ID": "112",
      "Parameters Length (bytes)": "8"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "File Type. Possible values are in Table 16: FileType Enumeration Values",
        "Length (bits)": "8",
        "Name": "File Type",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Counter",
        "Length (bits)": "8",
        "Name": "Counter",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Offset",
        "Length (bits)": "32",
        "Name": "Offset",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Block Length",
        "Length (bits)": "16",
        "Name": "BlockLength",
        "Offset (bits)": "48"
      }
    ],
    "Table": "Table 17: Load File Download Block Command Format"
  },
  {
    "Properties": {
      "Description": "Advance File List Read Pointer",
      "ID": "113",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 18: Advance File List Read Pointer Command Format"
  },
  {
    "Properties": {
      "Description": "Initiate File Upload",
      "ID": "114",
      "Parameters Length (bytes)": "2"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Destination. Possible values are in Table 20: FileUploadDestination Enumeration Values",
        "Length (bits)": "8",
        "Name": "Destination",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Block Size",
        "Length (bits)": "8",
        "Name": "BlockSize",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 19: Initiate File Upload Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "EEPROM",
        "Name": "EEPROM",
        "Numeric Value": "2"
      },
      {
        "Description": "Flash program 1",
        "Name": "Flash program 1",
        "Numeric Value": "3"
      },
      {
        "Description": "Flash program 2",
        "Name": "Flash program 2",
        "Numeric Value": "4"
      },
      {
        "Description": "Flash program 3",
        "Name": "Flash program 3",
        "Numeric Value": "5"
      },
      {
        "Description": "Flash program 4",
        "Name": "Flash program 4",
        "Numeric Value": "6"
      },
      {
        "Description": "Flash program 5",
        "Name": "Flash program 5",
        "Numeric Value": "7"
      },
      {
        "Description": "Flash program 6",
        "Name": "Flash program 6",
        "Numeric Value": "8"
      },
      {
        "Description": "Flash program 7",
        "Name": "Flash program 7",
        "Numeric Value": "9"
      },
      {
        "Description": "SD User file 1",
        "Name": "SD User file 1",
        "Numeric Value": "10"
      },
      {
        "Description": "SD User file 2",
        "Name": "SD User file 2",
        "Numeric Value": "11"
      },
      {
        "Description": "SD User file 3",
        "Name": "SD User file 3",
        "Numeric Value": "12"
      },
      {
        "Description": "SD User file 4",
        "Name": "SD User file 4",
        "Numeric Value": "13"
      },
      {
        "Description": "SD User file 5",
        "Name": "SD User file 5",
        "Numeric Value": "14"
      },
      {
        "Description": "SD User file 6",
        "Name": "SD User file 6",
        "Numeric Value": "15"
      },
      {
        "Description": "SD User file 7",
        "Name": "SD User file 7",
        "Numeric Value": "16"
      },
      {
        "Description": "SD User file 8",
        "Name": "SD User file 8",
        "Numeric Value": "17"
      }
    ],
    "Table": "Table 20: FileUploadDestination Enumeration Values"
  },
  {
    "Properties": {
      "Description": "File Upload Packet",
      "ID": "115",
      "Parameters Length (bytes)": "22"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Packet Number",
        "Length (bits)": "16",
        "Name": "Packet Number",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ARRAY",
        "Description": "File Bytes",
        "Length (bits)": "160",
        "Name": "File Bytes",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 21: File Upload Packet Command Format"
  },
  {
    "Properties": {
      "Description": "Finalize Uploaded File Block",
      "ID": "116",
      "Parameters Length (bytes)": "7"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Destination. Possible values are in Table 20: FileUploadDestination Enumeration Values",
        "Length (bits)": "8",
        "Name": "Destination",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Offset into file",
        "Length (bits)": "32",
        "Name": "Offset",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Length of block",
        "Length (bits)": "16",
        "Name": "Block Length",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 22: Finalize Upload Block Command Format"
  },
  {
    "Properties": {
      "Description": "Reset HoleMap for Upload Block",
      "ID": "117",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 23: Reset Upload Block Command Format"
  },
  {
    "Properties": {
      "Description": "Reset File List Read Pointer",
      "ID": "118",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 24: Reset File List Read Pointer Command Format"
  },
  {
    "Properties": {
      "Description": "Initiate Download Burst",
      "ID": "119",
      "Parameters Length (bytes)": "2"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Message Length",
        "Length (bits)": "8",
        "Name": "Message Length",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Ignore Hole Map",
        "Length (bits)": "1",
        "Name": "Ignore Hole Map",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 25: Initiate Download Burst Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Identification information for this node - Table 27: Identification Telemetry Format",
        "ID": "128",
        "Length (bytes)": "8",
        "Name": "Identification"
      },
      {
        "Description": "Boot And Running Program Status - Table 28: Boot And Running Program Status Telemetry Format",
        "ID": "129",
        "Length (bytes)": "6",
        "Name": "Boot And Running Program Status"
      },
      {
        "Description": "Current selected boot index and status of last boot - Table 32: Boot Index and Status Telemetry Format",
        "ID": "130",
        "Length (bytes)": "2",
        "Name": "Boot Index and Status"
      },
      {
        "Description": "Last Logged Event (relative to pointer - adjusted via Advance and Reset TCs (3 & 4) - Table 34: Last Logged Event Telemetry Format",
        "ID": "141",
        "Length (bytes)": "6",
        "Name": "Last Logged Event"
      },
      {
        "Description": "SD card format or erase progress - Table 38: SD card format/erase progress Telemetry Format",
        "ID": "234",
        "Length (bytes)": "1",
        "Name": "SD card format/erase progress"
      },
      {
        "Description": "Telemetry frame with acknowledge status of the previously sent command - Table 39: Telecommand Acknowledge Telemetry Format",
        "ID": "240",
        "Length (bytes)": "4",
        "Name": "Telecommand Acknowledge"
      },
      {
        "Description": "File Download buffer 20-byte packet - Table 41: File Download Buffer with File Contents Telemetry Format",
        "ID": "241",
        "Length (bytes)": "22",
        "Name": "File Download Buffer with File Contents"
      },
      {
        "Description": "Status about download block preparation - Table 42: Download Block Ready Telemetry Format",
        "ID": "242",
        "Length (bytes)": "5",
        "Name": "Download Block Ready"
      },
      {
        "Description": "File Information - Table 43: File Information Telemetry Format",
        "ID": "243",
        "Length (bytes)": "12",
        "Name": "File Information"
      },
      {
        "Description": "Initialize Upload Complete - Table 44: Initialize Upload Complete Telemetry Format",
        "ID": "244",
        "Length (bytes)": "1",
        "Name": "Initialize Upload Complete"
      },
      {
        "Description": "Finalize Upload Block Complete - Table 45: Upload Block Complete Telemetry Format",
        "ID": "245",
        "Length (bytes)": "1",
        "Name": "Upload Block Complete"
      },
      {
        "Description": "File upload Block CRC16 Checksum - Table 46: Block Checksum Telemetry Format",
        "ID": "246",
        "Length (bytes)": "2",
        "Name": "Block Checksum"
      },
      {
        "Description": "SRAM Latchup counters - Table 35: SRAM Latchup counters Telemetry Format",
        "ID": "142",
        "Length (bytes)": "6",
        "Name": "SRAM Latchup counters"
      },
      {
        "Description": "EDAC Error Counters - Table 36: EDAC Error Counters Telemetry Format",
        "ID": "143",
        "Length (bytes)": "6",
        "Name": "EDAC Error Counters"
      },
      {
        "Description": "Communication status - includes command and telemetry counters and error flags - Table 37: Communication Status Telemetry Format",
        "ID": "144",
        "Length (bytes)": "6",
        "Name": "Communication Status"
      }
    ],
    "Table": "Table 26: List of Common Telemetry Frames"
  },
  {
    "Properties": {
      "Description": "Identification information for this node",
      "Frame Length (bytes)": "8",
      "ID": "128"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Node type identifier.",
        "Length (bits)": "8",
        "Name": "Node type",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Interface version. This field should have a value of 1",
        "Length (bits)": "8",
        "Name": "Interface version",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Firmware version (Major)",
        "Length (bits)": "8",
        "Name": "Firmware version (Major)",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Firmware version (Minor)",
        "Length (bits)": "8",
        "Name": "Firmware version (Minor)",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of seconds since processor start-up",
        "Length (bits)": "16",
        "Name": "Runtime (seconds)",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of milliseconds (after the integer second) since processor start-up",
        "Length (bits)": "16",
        "Name": "Runtime (milliseconds)",
        "Offset (bits)": "48"
      }
    ],
    "Table": "Table 27: Identification Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Boot And Running Program Status",
      "Frame Length (bytes)": "6",
      "ID": "129"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Cause of MCU reset. Possible values are in Table 29: ResetCause Enumeration Values",
        "Length (bits)": "4",
        "Name": "Cause of MCU Reset",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cause of last reboot. Possible values are in Table 30: BootCause Enumeration Values",
        "Length (bits)": "4",
        "Name": "Boot Cause",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of times CubeComputer has booted",
        "Length (bits)": "16",
        "Name": "Boot Counter",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Location of program that is currently running. Possible values are in Table 31: BootProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Boot Program Index",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "Firmware version (Major)",
        "Length (bits)": "8",
        "Name": "Firmware version (Major)",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Firmware version (Minor)",
        "Length (bits)": "8",
        "Name": "Firmware version (Minor)",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 28: Boot And Running Program Status Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Power-On Reset",
        "Name": "Power-On Reset",
        "Numeric Value": "0"
      },
      {
        "Description": "Brown-Out Detected on Regulated Power",
        "Name": "Brown-Out Detected on Regulated Power",
        "Numeric Value": "1"
      },
      {
        "Description": "Brown-Out Detected on Unregulated Power",
        "Name": "Brown-Out Detected on Unregulated Power",
        "Numeric Value": "2"
      },
      {
        "Description": "External Watchdog Reset",
        "Name": "External Watchdog Reset",
        "Numeric Value": "3"
      },
      {
        "Description": "External Reset",
        "Name": "External Reset",
        "Numeric Value": "4"
      },
      {
        "Description": "Watchdog Reset",
        "Name": "Watchdog Reset",
        "Numeric Value": "5"
      },
      {
        "Description": "Lockup System Reset",
        "Name": "Lockup System Reset",
        "Numeric Value": "6"
      },
      {
        "Description": "Lockup Reset",
        "Name": "Lockup Reset",
        "Numeric Value": "7"
      },
      {
        "Description": "System Request Reset",
        "Name": "System Request Reset",
        "Numeric Value": "8"
      },
      {
        "Description": "Backup domain brown-out reset",
        "Name": "Backup Brown-Out",
        "Numeric Value": "9"
      },
      {
        "Description": "Backup mode reset",
        "Name": "Backup Mode Reset",
        "Numeric Value": "10"
      },
      {
        "Description": "Backup Mode reset and Backup domain brown-out on VDD regulated",
        "Name": "Backup Mode RST and Backup Brown-Out Vdd Regulated",
        "Numeric Value": "11"
      },
      {
        "Description": "Backup Mode reset and Backup domain brown-out on VDD regulated and brown out on regulated",
        "Name": "BackupModeRST and Backup Brown-Out Vdd Regulated and Brown-Out Regulated",
        "Numeric Value": "12"
      },
      {
        "Description": "Backup mode reset and Watchdog reset",
        "Name": "Backup Mode RST and Watchdog Reset",
        "Numeric Value": "13"
      },
      {
        "Description": "Backup Domain brown-out on BUVIN and System request reset.",
        "Name": "Backup Brown-Out Buvin and System Request Reset",
        "Numeric Value": "14"
      },
      {
        "Description": "Unkown Reset Cause",
        "Name": "Unkown Reset Cause",
        "Numeric Value": "15"
      }
    ],
    "Table": "Table 29: ResetCause Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Unexpected reset",
        "Name": "Unexpected",
        "Numeric Value": "0"
      },
      {
        "Description": "",
        "Name": "Not Used",
        "Numeric Value": "1"
      },
      {
        "Description": "Timeout due to lack of communications",
        "Name": "Communications Timeout",
        "Numeric Value": "2"
      },
      {
        "Description": "Software commanded MCU reset",
        "Name": "Commanded",
        "Numeric Value": "3"
      },
      {
        "Description": "",
        "Name": "Not Used",
        "Numeric Value": "4"
      },
      {
        "Description": "Latchup detected in SRAM",
        "Name": "SRAM Latchup",
        "Numeric Value": "5"
      }
    ],
    "Table": "Table 30: BootCause Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Internal Flash Program",
        "Name": "Internal Flash Program",
        "Numeric Value": "1"
      },
      {
        "Description": "Bootloader",
        "Name": "Bootloader",
        "Numeric Value": "2"
      }
    ],
    "Table": "Table 31: BootProgramsList Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Current selected boot index and status of last boot",
      "Frame Length (bytes)": "2",
      "ID": "130"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Program Index. Possible values are in Table 31: BootProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Program Index",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Boot Status. Possible values are in Table 33: BootStatus Enumeration Values",
        "Length (bits)": "8",
        "Name": "Boot Status",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 32: Boot Index and Status Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "New Selection",
        "Name": "New Selection",
        "Numeric Value": "0"
      },
      {
        "Description": "Boot Success",
        "Name": "Boot Success",
        "Numeric Value": "1"
      },
      {
        "Description": "1 Failed boot attempt",
        "Name": "1 Failed boot attempt",
        "Numeric Value": "2"
      },
      {
        "Description": "2 Failed boot attempts",
        "Name": "2 Failed boot attempts",
        "Numeric Value": "3"
      },
      {
        "Description": "3 Failed boot attempts",
        "Name": "3 Failed boot attempts",
        "Numeric Value": "4"
      }
    ],
    "Table": "Table 33: BootStatus Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Last Logged Event (relative to pointer - adjusted via Advance and Reset TCs (3 & 4)",
      "Frame Length (bytes)": "6",
      "ID": "141"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "",
        "Length (bits)": "32",
        "Name": "Time of Event",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Event ID",
        "Length (bits)": "8",
        "Name": "Event ID",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Event Parameter",
        "Length (bits)": "8",
        "Name": "Event Parameter",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 34: Last Logged Event Telemetry Format"
  },
  {
    "Properties": {
      "Description": "SRAM Latchup counters",
      "Frame Length (bytes)": "6",
      "ID": "142"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "The number of SRAM1 latchups detected",
        "Length (bits)": "16",
        "Name": "SRAM1 latchups",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "The number of SRAM2 latchups detected",
        "Length (bits)": "16",
        "Name": "SRAM2 latchups",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 35: SRAM Latchup counters Telemetry Format"
  },
  {
    "Properties": {
      "Description": "EDAC Error Counters",
      "Frame Length (bytes)": "6",
      "ID": "143"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "The number of single SRAM upsets (per byte) detected",
        "Length (bits)": "16",
        "Name": "Single SRAM upsets",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "The number of double SRAM upsets (per byte) detected",
        "Length (bits)": "16",
        "Name": "Double SRAM upsets",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "The number of multiple SRAM upsets (per byte) detected",
        "Length (bits)": "16",
        "Name": "Multiple SRAM upsets",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 36: EDAC Error Counters Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Communication status - includes command and telemetry counters and error flags",
      "Frame Length (bytes)": "6",
      "ID": "144"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "No. of telecommands received",
        "Length (bits)": "16",
        "Name": "Telecommand counter",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "No. of telemetry requests received",
        "Length (bits)": "16",
        "Name": "Telemetry request counter",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "BOOL",
        "Description": "TC buffer was overrun while receiving a telecommand",
        "Length (bits)": "1",
        "Name": "Telecommand buffer overrun",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "BOOL",
        "Description": "UART protocol error occurred",
        "Length (bits)": "1",
        "Name": "UART protocol error",
        "Offset (bits)": "33"
      },
      {
        "Data Type": "BOOL",
        "Description": "UART start-of-message identifier was received without a preceding end-of-message",
        "Length (bits)": "1",
        "Name": "UART incomplete message",
        "Offset (bits)": "34"
      },
      {
        "Data Type": "BOOL",
        "Description": "Number of data clocked out was more than telemetry package",
        "Length (bits)": "1",
        "Name": "I2C telemetry error",
        "Offset (bits)": "35"
      },
      {
        "Data Type": "BOOL",
        "Description": "Telecommand sent exceeds buffer size",
        "Length (bits)": "1",
        "Name": "I2C telecommand buffer error",
        "Offset (bits)": "36"
      },
      {
        "Data Type": "BOOL",
        "Description": "Telecommand sent exceeds buffer size",
        "Length (bits)": "1",
        "Name": "CAN telecommand buffer error",
        "Offset (bits)": "37"
      }
    ],
    "Table": "Table 37: Communication Status Telemetry Format"
  },
  {
    "Properties": {
      "Description": "SD card format or erase progress",
      "Frame Length (bytes)": "1",
      "ID": "234"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Busy formatting SD card",
        "Length (bits)": "1",
        "Name": "Format Busy",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Busy formatting erasing all SD files",
        "Length (bits)": "1",
        "Name": "Erase All Busy",
        "Offset (bits)": "1"
      }
    ],
    "Table": "Table 38: SD card format/erase progress Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Telemetry frame with acknowledge status of the previously sent command",
      "Frame Length (bytes)": "4",
      "ID": "240"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "ID of last received TC",
        "Length (bits)": "8",
        "Name": "Last TC ID",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate if the last TC has been processed.",
        "Length (bits)": "1",
        "Name": "Processed flag",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Status of last processed telecommand. Possible values are in Table 40: TcErrorReason Enumeration Values",
        "Length (bits)": "8",
        "Name": "TC error status",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Index of incorrect TC parameter",
        "Length (bits)": "8",
        "Name": "TC parameter error index",
        "Offset (bits)": "24"
      }
    ],
    "Table": "Table 39: Telecommand Acknowledge Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No error",
        "Name": "No Error",
        "Numeric Value": "0"
      },
      {
        "Description": "Invalid telecommand ID",
        "Name": "Invalid TC",
        "Numeric Value": "1"
      },
      {
        "Description": "Incorrect TC parameter length",
        "Name": "Incorrect Length",
        "Numeric Value": "2"
      },
      {
        "Description": "Incorrect TC parameter value",
        "Name": "Incorrect Parameter",
        "Numeric Value": "3"
      },
      {
        "Description": "CRC check failed",
        "Name": "CRC check failed",
        "Numeric Value": "4"
      }
    ],
    "Table": "Table 40: TcErrorReason Enumeration Values"
  },
  {
    "Properties": {
      "Description": "File Download buffer 20-byte packet",
      "Frame Length (bytes)": "22",
      "ID": "241"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Packet counter of this file download packet",
        "Length (bits)": "16",
        "Name": "Packet counter",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ARRAY",
        "Description": "File 20-byte packet",
        "Length (bits)": "160",
        "Name": "File bytes",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 41: File Download Buffer with File Contents Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Status about download block preparation",
      "Frame Length (bytes)": "5",
      "ID": "242"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Ready",
        "Length (bits)": "1",
        "Name": "Ready",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "The combination of message length and hole map resulted in invalid array lengths",
        "Length (bits)": "1",
        "Name": "ParameterError",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "UINT",
        "Description": "Block CRC16 Checksum",
        "Length (bits)": "16",
        "Name": "Block CRC16 Checksum",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Block length",
        "Length (bits)": "16",
        "Name": "Block Length",
        "Offset (bits)": "24"
      }
    ],
    "Table": "Table 42: Download Block Ready Telemetry Format"
  },
  {
    "Properties": {
      "Description": "File Information",
      "Frame Length (bytes)": "12",
      "ID": "243"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "File Type. Possible values are in Table 16: FileType Enumeration Values",
        "Length (bits)": "4",
        "Name": "File Type",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "",
        "Length (bits)": "1",
        "Name": "Busy Updating",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "UINT",
        "Description": "File Counter",
        "Length (bits)": "8",
        "Name": "File Ctr",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "File Size",
        "Length (bits)": "32",
        "Name": "File Size",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "File Date and Time (in MS-DOS format). (Unit of measure is [s])",
        "Length (bits)": "32",
        "Name": "File Date and Time",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "File CRC16 Checksum",
        "Length (bits)": "16",
        "Name": "File CRC16 Checksum",
        "Offset (bits)": "80"
      }
    ],
    "Table": "Table 43: File Information Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Initialize Upload Complete",
      "Frame Length (bytes)": "1",
      "ID": "244"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Busy with file initialization (flash erase, etc.)",
        "Length (bits)": "1",
        "Name": "Busy",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 44: Initialize Upload Complete Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Finalize Upload Block Complete",
      "Frame Length (bytes)": "1",
      "ID": "245"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Busy with block finalization",
        "Length (bits)": "1",
        "Name": "Busy",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Error in block finalization",
        "Length (bits)": "1",
        "Name": "Error",
        "Offset (bits)": "1"
      }
    ],
    "Table": "Table 45: Upload Block Complete Telemetry Format"
  },
  {
    "Properties": {
      "Description": "File upload Block CRC16 Checksum",
      "Frame Length (bytes)": "2",
      "ID": "246"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Checksum",
        "Length (bits)": "16",
        "Name": "Checksum",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 46: Block Checksum Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Cache enabled state - Table 48: Cache enabled state Message Format",
        "Get ID": "131",
        "Length (bytes)": "1",
        "Name": "Cache enabled state",
        "Set ID": "3"
      },
      {
        "Description": "SRAM scrubbing size - Table 49: SRAM Scrub Parameters Message Format",
        "Get ID": "134",
        "Length (bytes)": "2",
        "Name": "SRAM Scrub Parameters",
        "Set ID": "8"
      },
      {
        "Description": "Configuration settings for Unix time flash memory persistence - Table 51: Unix Time Save to Flash Message Format",
        "Get ID": "145",
        "Length (bytes)": "2",
        "Name": "Unix Time Save to Flash",
        "Set ID": "9"
      },
      {
        "Description": "File Upload Hole Map 1 - Table 52: Hole Map 1 Message Format",
        "Get ID": "247",
        "Length (bytes)": "16",
        "Name": "Hole Map 1",
        "Set ID": "120"
      },
      {
        "Description": "File Upload Hole Map 2 - Table 53: Hole Map 2 Message Format",
        "Get ID": "248",
        "Length (bytes)": "16",
        "Name": "Hole Map 2",
        "Set ID": "121"
      },
      {
        "Description": "File Upload Hole Map 3 - Table 54: Hole Map 3 Message Format",
        "Get ID": "249",
        "Length (bytes)": "16",
        "Name": "Hole Map 3",
        "Set ID": "122"
      },
      {
        "Description": "File Upload Hole Map 4 - Table 55: Hole Map 4 Message Format",
        "Get ID": "250",
        "Length (bytes)": "16",
        "Name": "Hole Map 4",
        "Set ID": "123"
      },
      {
        "Description": "File Upload Hole Map 5 - Table 56: Hole Map 5 Message Format",
        "Get ID": "251",
        "Length (bytes)": "16",
        "Name": "Hole Map 5",
        "Set ID": "124"
      },
      {
        "Description": "File Upload Hole Map 6 - Table 57: Hole Map 6 Message Format",
        "Get ID": "252",
        "Length (bytes)": "16",
        "Name": "Hole Map 6",
        "Set ID": "125"
      },
      {
        "Description": "File Upload Hole Map 7 - Table 58: Hole Map 7 Message Format",
        "Get ID": "253",
        "Length (bytes)": "16",
        "Name": "Hole Map 7",
        "Set ID": "126"
      },
      {
        "Description": "File Upload Hole Map 8 - Table 59: Hole Map 8 Message Format",
        "Get ID": "254",
        "Length (bytes)": "16",
        "Name": "Hole Map 8",
        "Set ID": "127"
      },
      {
        "Description": "Current Unix Time - Table 50: Current Unix Time Message Format",
        "Get ID": "140",
        "Length (bytes)": "6",
        "Name": "Current Unix Time",
        "Set ID": "2"
      }
    ],
    "Table": "Table 47: List of Common Configuration Messages"
  },
  {
    "Properties": {
      "Description": "Cache enabled state",
      "Parameters Length (bytes)": "1",
      "Set ID/Get ID": "3/131"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Enabled state",
        "Length (bits)": "1",
        "Name": "Enabled state",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 48: Cache enabled state Message Format"
  },
  {
    "Properties": {
      "Description": "SRAM scrubbing size",
      "Parameters Length (bytes)": "2",
      "Set ID/Get ID": "8/134"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Scrub Size",
        "Length (bits)": "16",
        "Name": "Scrub Size",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 49: SRAM Scrub Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Current Unix Time",
      "Parameters Length (bytes)": "6",
      "Set ID/Get ID": "2/140"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Time in s since 01/01/1970, 00:00. (Unit of measure is [s])",
        "Length (bits)": "32",
        "Name": "Current Unix Time",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Current millisecond count. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Milliseconds",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 50: Current Unix Time Message Format"
  },
  {
    "Properties": {
      "Description": "Configuration settings for unixtime flash memory persistence",
      "Parameters Length (bytes)": "2",
      "Set ID/Get ID": "9/145"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Save current Unix time to flash memory",
        "Length (bits)": "1",
        "Name": "Save Now",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Save Unix time to flash memory whenever there is a command to update the Unix time",
        "Length (bits)": "1",
        "Name": "Save On Update",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "BOOL",
        "Description": "Save Unix time to flash memory periodically",
        "Length (bits)": "1",
        "Name": "Save Periodic",
        "Offset (bits)": "2"
      },
      {
        "Data Type": "UINT",
        "Description": "Interval at which to save Unix time to flash memory. (Unit of measure is [s])",
        "Length (bits)": "8",
        "Name": "Period",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 51: Unix Time Save to Flash Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 1",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "120/247"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 52: Hole Map 1 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 2",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "121/248"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 53: Hole Map 2 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 3",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "122/249"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 54: Hole Map 3 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 4",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "123/250"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 55: Hole Map 4 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 5",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "124/251"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 56: Hole Map 5 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 6",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "125/252"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 57: Hole Map 6 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 7",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "126/253"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 58: Hole Map 7 Message Format"
  },
  {
    "Properties": {
      "Description": "File Upload Hole Map 8",
      "Parameters Length (bytes)": "16",
      "Set ID/Get ID": "127/254"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Hole Map",
        "Length (bits)": "128",
        "Name": "Hole Map",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 59: Hole Map 8 Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Clear Error Flags - Table 61: Clear Error Flags Command Format",
        "ID": "7",
        "Length (bytes)": "0",
        "Name": "Clear Error Flags"
      },
      {
        "Description": "Select which program to boot - Table 62: Set Boot Index Command Format",
        "ID": "100",
        "Length (bytes)": "1",
        "Name": "Set Boot Index"
      },
      {
        "Description": "Run Selected Program - Table 64: Run Selected Program Command Format",
        "ID": "101",
        "Length (bytes)": "0",
        "Name": "Run Selected Program"
      },
      {
        "Description": "Read Program CRC, length - Table 65: Read Program Information Command Format",
        "ID": "102",
        "Length (bytes)": "1",
        "Name": "Read Program Information"
      },
      {
        "Description": "Copy Program to Internal Flash - Table 67: Copy Program to Internal Flash Command Format",
        "ID": "103",
        "Length (bytes)": "2",
        "Name": "Copy Program to Internal Flash"
      }
    ],
    "Table": "Table 60: List of BootLoader Telecommands"
  },
  {
    "Properties": {
      "Description": "Clear Error Flags",
      "ID": "7",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 61: Clear Error Flags Command Format"
  },
  {
    "Properties": {
      "Description": "Select which program to boot",
      "ID": "100",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Program Index. Possible values are in Table 63: BootSetProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Program Index",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 62: Set Boot Index Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Internal Flash Program",
        "Name": "Internal Flash Program",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 63: BootSetProgramsList Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Run Selected Program",
      "ID": "101",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 64: Run Selected Program Command Format"
  },
  {
    "Properties": {
      "Description": "Read Program CRC, length",
      "ID": "102",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Program Index. Possible values are in Table 66: ProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Program Index",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 65: Read Program Information Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Bootloader",
        "Name": "Bootloader",
        "Numeric Value": "0"
      },
      {
        "Description": "Internal Flash Program",
        "Name": "Internal Flash Program",
        "Numeric Value": "1"
      },
      {
        "Description": "EEPROM",
        "Name": "EEPROM",
        "Numeric Value": "2"
      },
      {
        "Description": "External Flash Program 1",
        "Name": "External Flash Program 1",
        "Numeric Value": "3"
      },
      {
        "Description": "External Flash Program 2",
        "Name": "External Flash Program 2",
        "Numeric Value": "4"
      },
      {
        "Description": "External Flash Program 3",
        "Name": "External Flash Program 3",
        "Numeric Value": "5"
      },
      {
        "Description": "External Flash Program 4",
        "Name": "External Flash Program 4",
        "Numeric Value": "6"
      },
      {
        "Description": "External Flash Program 5",
        "Name": "External Flash Program 5",
        "Numeric Value": "7"
      },
      {
        "Description": "External Flash Program 6",
        "Name": "External Flash Program 6",
        "Numeric Value": "8"
      },
      {
        "Description": "External Flash Program 7",
        "Name": "External Flash Program 7",
        "Numeric Value": "9"
      },
      {
        "Description": "SD User file 1",
        "Name": "SD User file 1",
        "Numeric Value": "10"
      },
      {
        "Description": "SD User file 2",
        "Name": "SD User file 2",
        "Numeric Value": "11"
      },
      {
        "Description": "SD User file 3",
        "Name": "SD User file 3",
        "Numeric Value": "12"
      },
      {
        "Description": "SD User file 4",
        "Name": "SD User file 4",
        "Numeric Value": "13"
      },
      {
        "Description": "SD User file 5",
        "Name": "SD User file 5",
        "Numeric Value": "14"
      },
      {
        "Description": "SD User file 6",
        "Name": "SD User file 6",
        "Numeric Value": "15"
      },
      {
        "Description": "SD User file 7",
        "Name": "SD User file 7",
        "Numeric Value": "16"
      },
      {
        "Description": "SD User file 8",
        "Name": "SD User file 8",
        "Numeric Value": "17"
      }
    ],
    "Table": "Table 66: ProgramsList Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Copy Program to Internal Flash",
      "ID": "103",
      "Parameters Length (bytes)": "2"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Source Program Index. Possible values are in Table 66: ProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Source Program Index",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Bootloader overwrite flag. Set to 0x5A to overwrite the boot segment. USE WITH CAUTION!",
        "Length (bits)": "8",
        "Name": "Bootloader overwrite flag",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 67: Copy Program to Internal Flash Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Status flags for bootloader - Table 69: Bootloader State Telemetry Format",
        "ID": "132",
        "Length (bytes)": "6",
        "Name": "Bootloader State"
      },
      {
        "Description": "Program information including file size and CRC - Table 70: Program Information Telemetry Format",
        "ID": "232",
        "Length (bytes)": "8",
        "Name": "Program Information"
      },
      {
        "Description": "Progress of copy to internal flash operation - Table 71: Copy To Internal Flash Progress Telemetry Format",
        "ID": "233",
        "Length (bytes)": "1",
        "Name": "Copy To Internal Flash Progress"
      }
    ],
    "Table": "Table 68: List of BootLoader Telemetry Frames"
  },
  {
    "Properties": {
      "Description": "Status flags for bootloader",
      "Frame Length (bytes)": "6",
      "ID": "132"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Uptime. (Unit of measure is [s])",
        "Length (bits)": "16",
        "Name": "Up-time (s)",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "SRAM1 is enabled",
        "Length (bits)": "1",
        "Name": "SRAM1 is enabled",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "BOOL",
        "Description": "SRAM2 is enabled",
        "Length (bits)": "1",
        "Name": "SRAM2 is enabled",
        "Offset (bits)": "17"
      },
      {
        "Data Type": "BOOL",
        "Description": "SRAM Latch-up Error occurred and could not be recovered",
        "Length (bits)": "1",
        "Name": "SRAM Latch-up Error occurred and could not be recovered",
        "Offset (bits)": "18"
      },
      {
        "Data Type": "BOOL",
        "Description": "SRAM Latch-up Occurred but recovered after power cycle",
        "Length (bits)": "1",
        "Name": "SRAM Latch-up Occurred but recovered after power cycle",
        "Offset (bits)": "19"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that the SD card failed to initialise",
        "Length (bits)": "1",
        "Name": "SD card initialisation error",
        "Offset (bits)": "20"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that a read operation from the SD card failed",
        "Length (bits)": "1",
        "Name": "SD card read error",
        "Offset (bits)": "21"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that a write operation to the SD card failed",
        "Length (bits)": "1",
        "Name": "SD card write error",
        "Offset (bits)": "22"
      },
      {
        "Data Type": "BOOL",
        "Description": "External Flash Erase/write error occurred",
        "Length (bits)": "1",
        "Name": "External Flash Error",
        "Offset (bits)": "23"
      },
      {
        "Data Type": "BOOL",
        "Description": "Internal Flash Erase/write error occurred",
        "Length (bits)": "1",
        "Name": "Internal Flash Error",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "BOOL",
        "Description": "EEPROM Write error occurred",
        "Length (bits)": "1",
        "Name": "EEPROM Error",
        "Offset (bits)": "25"
      },
      {
        "Data Type": "BOOL",
        "Description": "Boot Register contained invalid data",
        "Length (bits)": "1",
        "Name": "Boot Register Corrupt",
        "Offset (bits)": "26"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communications Error with Radio",
        "Length (bits)": "1",
        "Name": "Communications Error with Radio",
        "Offset (bits)": "27"
      }
    ],
    "Table": "Table 69: Bootloader State Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Program information including file size and CRC",
      "Frame Length (bytes)": "8",
      "ID": "232"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Program Index. Possible values are in Table 66: ProgramsList Enumeration Values",
        "Length (bits)": "8",
        "Name": "Program Index",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Busy reading",
        "Length (bits)": "1",
        "Name": "Busy",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "File Size (bytes)",
        "Length (bits)": "32",
        "Name": "File Size",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "CRC16 Checksum",
        "Length (bits)": "16",
        "Name": "Checksum",
        "Offset (bits)": "48"
      }
    ],
    "Table": "Table 70: Program Information Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Progress of copy to internal flash operation",
      "Frame Length (bytes)": "1",
      "ID": "233"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Busy",
        "Length (bits)": "1",
        "Name": "Busy",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Error",
        "Length (bits)": "1",
        "Name": "Error",
        "Offset (bits)": "1"
      }
    ],
    "Table": "Table 71: Copy To Internal Flash Progress Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Deploy magnetometer boom - Table 73: Deploy Magnetometer Boom Command Format",
        "ID": "7",
        "Length (bytes)": "1",
        "Name": "Deploy Magnetometer Boom"
      },
      {
        "Description": "Set ADCS enabled state & control loop behaviour - Table 74: ADCS Run Mode Command Format",
        "ID": "10",
        "Length (bytes)": "1",
        "Name": "ADCS Run Mode"
      },
      {
        "Description": "Clear Latched Error Flags - Table 76: Clear Errors Command Format",
        "ID": "12",
        "Length (bytes)": "1",
        "Name": "Clear Errors"
      },
      {
        "Description": "Set attitude control mode - Table 77: Set Attitude Control Mode Command Format",
        "ID": "13",
        "Length (bytes)": "3",
        "Name": "Set Attitude Control Mode"
      },
      {
        "Description": "Set attitude estimation mode - Table 79: Set Attitude Estimation Mode Command Format",
        "ID": "14",
        "Length (bytes)": "1",
        "Name": "Set Attitude Estimation Mode"
      },
      {
        "Description": "Trigger ADCS to perform one iteration of the control loop (only valid when ADCS Run Mode is Triggered) - Table 83: Trigger ADCS Loop Command Format",
        "ID": "18",
        "Length (bytes)": "0",
        "Name": "Trigger ADCS Loop"
      },
      {
        "Description": "Trigger ADCS to perform one iteration of the control loop (only valid when ADCS Run Mode is Triggered) - Table 84: Trigger ADCS Loop with Simulated Sensor Data Command Format",
        "ID": "19",
        "Length (bytes)": "127",
        "Name": "Trigger ADCS Loop with Simulated Sensor Data"
      },
      {
        "Description": "Set ASGP4 run mode - Table 86: ASGP4 Run Mode Command Format",
        "ID": "31",
        "Length (bytes)": "1",
        "Name": "ASGP4 Run Mode"
      },
      {
        "Description": "Trigger a start of the ASGP4 process - Table 88: ASGP4 Trigger Command Format",
        "ID": "32",
        "Length (bytes)": "0",
        "Name": "ASGP4 Trigger"
      },
      {
        "Description": "Use of main or redundant magnetometer - Table 89: Set Mode of Magnetometer Operation Command Format",
        "ID": "56",
        "Length (bytes)": "1",
        "Name": "Set Mode of Magnetometer Operation"
      },
      {
        "Description": "Convert raw or bmp files to JPG - Table 91: Convert to JPG file Command Format",
        "ID": "57",
        "Length (bytes)": "3",
        "Name": "Convert to JPG file"
      },
      {
        "Description": "Save and capture image from one of CubeSense cameras or CubeStar camera to SD card - Table 94: Save Image Command Format",
        "ID": "80",
        "Length (bytes)": "2",
        "Name": "Save Image"
      },
      {
        "Description": "Set magnetorquer output (only valid if Control Mode is None) - Table 81: Set Magnetorquer Output Command Format",
        "ID": "16",
        "Length (bytes)": "6",
        "Name": "Set Magnetorquer Output"
      },
      {
        "Description": "Set wheel speed (only valid if Control Mode is None) - Table 82: Set Wheel Speed Command Format",
        "ID": "17",
        "Length (bytes)": "6",
        "Name": "Set Wheel Speed"
      },
      {
        "Description": "Save current configuration to flash memory - Table 92: Save Configuration Command Format",
        "ID": "63",
        "Length (bytes)": "0",
        "Name": "Save Configuration"
      },
      {
        "Description": "Save current orbit parameters to flash memory - Table 93: Save Orbit Parameters Command Format",
        "ID": "64",
        "Length (bytes)": "0",
        "Name": "Save Orbit Parameters"
      }
    ],
    "Table": "Table 72: List of CubeAcp Telecommands"
  },
  {
    "Properties": {
      "Description": "Deploy magnetometer boom",
      "ID": "7",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Deployment actuation timeout value. (Unit of measure is [s])",
        "Length (bits)": "8",
        "Name": "Timeout",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 73: Deploy Magnetometer Boom Command Format"
  },
  {
    "Properties": {
      "Description": "Set ADCS enabled state & control loop behaviour",
      "ID": "10",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Set ADCS enabled state. When disabled the CubeACP will not use the ADCS I2C bus. Possible values are in Table 75: AdcsRunMode Enumeration Values",
        "Length (bits)": "8",
        "Name": "Enabled",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 74: ADCS Run Mode Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "ADCS loop is inactive",
        "Name": "Off",
        "Numeric Value": "0"
      },
      {
        "Description": "ADCS 1Hz loop is active",
        "Name": "Enabled",
        "Numeric Value": "1"
      },
      {
        "Description": "ADCS will execute control loop only when triggered",
        "Name": "Triggered",
        "Numeric Value": "2"
      },
      {
        "Description": "ADCS is in simulation mode",
        "Name": "Simulation",
        "Numeric Value": "3"
      }
    ],
    "Table": "Table 75: AdcsRunMode Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Clear Latched Error Flags",
      "ID": "12",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Clear ADCS error flags",
        "Length (bits)": "1",
        "Name": "ADCS Error Flags",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Clear HK Error flags",
        "Length (bits)": "1",
        "Name": "HK Error Flags",
        "Offset (bits)": "1"
      }
    ],
    "Table": "Table 76: Clear Errors Command Format"
  },
  {
    "Properties": {
      "Description": "Set attitude control mode",
      "ID": "13",
      "Parameters Length (bytes)": "3"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Attitude control mode. Possible values are in Table 78: ConModeSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Control Mode",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Control timeout duration. Control will revert to None when timer reaches zero. 0xFFFF for infinite timeout. (Unit of measure is [s])",
        "Length (bits)": "16",
        "Name": "Timeout",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 77: Set Attitude Control Mode Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No control",
        "Name": "No control",
        "Numeric Value": "0"
      },
      {
        "Description": "Detumbling control",
        "Name": "Detumbling control",
        "Numeric Value": "1"
      },
      {
        "Description": "Y-Thomson spin",
        "Name": "Y-Thomson spin",
        "Numeric Value": "2"
      },
      {
        "Description": "Y-Wheel momentum stabilized - Initial Pitch Acquisition",
        "Name": "Y-Wheel momentum stabilized - Initial Pitch Acquisition",
        "Numeric Value": "3"
      },
      {
        "Description": "Y-Wheel momentum stabilized - Steady State",
        "Name": "Y-Wheel momentum stabilized - Steady State",
        "Numeric Value": "4"
      },
      {
        "Description": "XYZ-Wheel control",
        "Name": "XYZ-Wheel control",
        "Numeric Value": "5"
      },
      {
        "Description": "Rwheel sun tracking control",
        "Name": "Rwheel sun tracking control",
        "Numeric Value": "6"
      },
      {
        "Description": "Rwheel target tracking control",
        "Name": "Rwheel target tracking control",
        "Numeric Value": "7"
      },
      {
        "Description": "10Hz Detumbling control within CubeControl",
        "Name": "Very Fast-spin Detumbling control",
        "Numeric Value": "8"
      },
      {
        "Description": "Fast Detumbling control",
        "Name": "Fast-spin Detumbling control",
        "Numeric Value": "9"
      },
      {
        "Description": "User defined, or custom control mode 1",
        "Name": "User Specific Control Mode 1",
        "Numeric Value": "10"
      },
      {
        "Description": "User defined, or custom control mode 2",
        "Name": "User Specific Control Mode 2",
        "Numeric Value": "11"
      },
      {
        "Description": "Stop all R-wheels",
        "Name": "Stop R-wheels",
        "Numeric Value": "12"
      },
      {
        "Description": "User coded control mode",
        "Name": "User Coded Control Mode",
        "Numeric Value": "13"
      },
      {
        "Description": "Yaw-only or roll-only sun tracking mode.",
        "Name": "Sun-tracking yaw- or roll-only wheel control mode",
        "Numeric Value": "14"
      },
      {
        "Description": "Yaw-only wheel control to align selected facet to ground target",
        "Name": "Target-tracking yaw-only wheel control Mode",
        "Numeric Value": "15"
      }
    ],
    "Table": "Table 78: ConModeSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Set attitude estimation mode",
      "ID": "14",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Attitude estimation mode. Possible values are in Table 80: EstimModeSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Attitude Estimation Mode",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 79: Set Attitude Estimation Mode Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No attitude estimation",
        "Name": "No attitude estimation",
        "Numeric Value": "0"
      },
      {
        "Description": "MEMS rate sensing",
        "Name": "MEMS rate sensing",
        "Numeric Value": "1"
      },
      {
        "Description": "Magnetometer rate filter",
        "Name": "Magnetometer rate filter",
        "Numeric Value": "2"
      },
      {
        "Description": "Magnetometer rate filter with pitch estimation",
        "Name": "Magnetometer rate filter with pitch estimation",
        "Numeric Value": "3"
      },
      {
        "Description": "Magnetometer and Fine-sun TRIAD algorithm",
        "Name": "Magnetometer and Fine-sun TRIAD algorithm",
        "Numeric Value": "4"
      },
      {
        "Description": "Full-state EKF",
        "Name": "Full-state EKF",
        "Numeric Value": "5"
      },
      {
        "Description": "MEMS gyro EKF",
        "Name": "MEMS gyro EKF",
        "Numeric Value": "6"
      },
      {
        "Description": "User coded estimation mode",
        "Name": "User Coded Estimation Mode",
        "Numeric Value": "7"
      }
    ],
    "Table": "Table 80: EstimModeSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Set magnetorquer output (only valid if Control Mode is None)",
      "ID": "16",
      "Parameters Length (bytes)": "6"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Commanded X-torquer duty cycle. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*1000.0",
        "Length (bits)": "16",
        "Name": "Commanded X Magnetorquer duty cycle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded Y-torquer duty cycle. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*1000.0",
        "Length (bits)": "16",
        "Name": "Commanded Y Magnetorquer duty cycle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded Z-torquer duty cycle. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*1000.0",
        "Length (bits)": "16",
        "Name": "Commanded Z Magnetorquer duty cycle",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 81: Set Magnetorquer Output Command Format"
  },
  {
    "Properties": {
      "Description": "Set wheel speed (only valid if Control Mode is None)",
      "ID": "17",
      "Parameters Length (bytes)": "6"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Commanded X-wheel speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded X speed",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded Y-wheel speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Y speed",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded Z-wheel speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Z speed",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 82: Set Wheel Speed Command Format"
  },
  {
    "Properties": {
      "Description": "Trigger ADCS to perform one iteration of the control loop (only valid when ADCS Run Mode is Triggered)",
      "ID": "18",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 83: Trigger ADCS Loop Command Format"
  },
  {
    "Properties": {
      "Description": "Trigger ADCS to perform one iteration of the control loop (only valid when ADCS Run Mode is Triggered)",
      "ID": "19",
      "Parameters Length (bytes)": "127"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Unix time for iteration. (Unit of measure is [s])",
        "Length (bits)": "32",
        "Name": "Unix Time",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS1 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 1",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS2 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 2",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS3 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 3",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS4 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 4",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS5 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 5",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS6 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 6",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS7 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 7",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS8 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 8",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS9 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 9",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS10 raw measurement",
        "Length (bits)": "16",
        "Name": "Css Raw 10",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 sensor raw X angle",
        "Length (bits)": "16",
        "Name": "Cam1 Raw X",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 sensor raw Y angle",
        "Length (bits)": "16",
        "Name": "Cam1 Raw Y",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam1 sensor capture status",
        "Length (bits)": "8",
        "Name": "Cam1 Busy",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam1 sensor detection result",
        "Length (bits)": "8",
        "Name": "Cam1 Result",
        "Offset (bits)": "232"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 sensor raw X angle",
        "Length (bits)": "16",
        "Name": "Cam2 Raw X",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 sensor raw Y angle",
        "Length (bits)": "16",
        "Name": "Cam2 Raw Y",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam2 sensor capture status",
        "Length (bits)": "8",
        "Name": "Cam2 Busy",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam2 sensor detection result",
        "Length (bits)": "8",
        "Name": "Cam2 Result",
        "Offset (bits)": "280"
      },
      {
        "Data Type": "INT",
        "Description": "Raw magnetometer X measurement",
        "Length (bits)": "16",
        "Name": "Mag Raw X",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "INT",
        "Description": "Raw magnetometer Y measurement",
        "Length (bits)": "16",
        "Name": "Mag Raw Y",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "INT",
        "Description": "Raw magnetometer Z measurement",
        "Length (bits)": "16",
        "Name": "Mag Raw Z",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "INT",
        "Description": "Raw X rate sensor measurement",
        "Length (bits)": "32",
        "Name": "Rate Raw X",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "INT",
        "Description": "Raw Y rate sensor measurement",
        "Length (bits)": "32",
        "Name": "Rate Raw Y",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "INT",
        "Description": "Raw Z rate sensor measurement",
        "Length (bits)": "32",
        "Name": "Rate Raw Z",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "INT",
        "Description": "Raw X wheel speed measurement. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Wheel Raw X",
        "Offset (bits)": "432"
      },
      {
        "Data Type": "INT",
        "Description": "Raw Y wheel speed measurement. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Wheel Raw Y",
        "Offset (bits)": "448"
      },
      {
        "Data Type": "INT",
        "Description": "Raw Z wheel speed measurement. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Wheel Raw Z",
        "Offset (bits)": "464"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 camera X-vector",
        "Length (bits)": "16",
        "Name": "Star1CameraX",
        "Offset (bits)": "480"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 camera Y-vector",
        "Length (bits)": "16",
        "Name": "Star1CameraY",
        "Offset (bits)": "496"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 camera Z-vector",
        "Length (bits)": "16",
        "Name": "Star1CameraZ",
        "Offset (bits)": "512"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 inertial X-vector",
        "Length (bits)": "16",
        "Name": "Star1InertialX",
        "Offset (bits)": "528"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 inertial Y-vector",
        "Length (bits)": "16",
        "Name": "Star1InertialY",
        "Offset (bits)": "544"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 inertial Z-vector",
        "Length (bits)": "16",
        "Name": "Star1InertialZ",
        "Offset (bits)": "560"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 camera X-vector",
        "Length (bits)": "16",
        "Name": "Star2CameraX",
        "Offset (bits)": "576"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 camera Y-vector",
        "Length (bits)": "16",
        "Name": "Star2CameraY",
        "Offset (bits)": "592"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 camera Z-vector",
        "Length (bits)": "16",
        "Name": "Star2CameraZ",
        "Offset (bits)": "608"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 inertial X-vector",
        "Length (bits)": "16",
        "Name": "Star2InertialX",
        "Offset (bits)": "624"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 inertial Y-vector",
        "Length (bits)": "16",
        "Name": "Star2InertialY",
        "Offset (bits)": "640"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 inertial Z-vector",
        "Length (bits)": "16",
        "Name": "Star2InertialZ",
        "Offset (bits)": "656"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 camera X-vector",
        "Length (bits)": "16",
        "Name": "Star3CameraX",
        "Offset (bits)": "672"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 camera Y-vector",
        "Length (bits)": "16",
        "Name": "Star3CameraY",
        "Offset (bits)": "688"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 camera Z-vector",
        "Length (bits)": "16",
        "Name": "Star3CameraZ",
        "Offset (bits)": "704"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 inertial X-vector",
        "Length (bits)": "16",
        "Name": "Star3InertialX",
        "Offset (bits)": "720"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 inertial Y-vector",
        "Length (bits)": "16",
        "Name": "Star3InertialY",
        "Offset (bits)": "736"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 inertial Z-vector",
        "Length (bits)": "16",
        "Name": "Star3InertialZ",
        "Offset (bits)": "752"
      },
      {
        "Data Type": "ENUM",
        "Description": "GPS Solution Status. Possible values are in Table 85: GpsSolutionStatus Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gps Solution Status",
        "Offset (bits)": "768"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS Reference Week",
        "Length (bits)": "16",
        "Name": "GPS Reference Week",
        "Offset (bits)": "776"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS Time Milliseconds. (Unit of measure is [ms])",
        "Length (bits)": "32",
        "Name": "GPS Time Milliseconds",
        "Offset (bits)": "792"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position X. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position X",
        "Offset (bits)": "824"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity X. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity X",
        "Offset (bits)": "856"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Y. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Y",
        "Offset (bits)": "872"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Y. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Y",
        "Offset (bits)": "904"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Z. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Z",
        "Offset (bits)": "920"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Z. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Z",
        "Offset (bits)": "952"
      },
      {
        "Data Type": "UINT",
        "Description": "X-pos Standard Deviation. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*10.0 (formatted value is in [m] units)",
        "Length (bits)": "8",
        "Name": "X-pos Standard Deviation",
        "Offset (bits)": "968"
      },
      {
        "Data Type": "UINT",
        "Description": "Y-pos Standard Deviation. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*10.0 (formatted value is in [m] units)",
        "Length (bits)": "8",
        "Name": "Y-pos Standard Deviation",
        "Offset (bits)": "976"
      },
      {
        "Data Type": "UINT",
        "Description": "Z-pos Standard Deviation. Raw parameter value is obtained using the formula: (raw parameter) = (formatted value)*10.0 (formatted value is in [m] units)",
        "Length (bits)": "8",
        "Name": "Z-pos Standard Deviation",
        "Offset (bits)": "984"
      },
      {
        "Data Type": "UINT",
        "Description": "X-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "X-vel Standard Deviation",
        "Offset (bits)": "992"
      },
      {
        "Data Type": "UINT",
        "Description": "Y-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "Y-vel Standard Deviation",
        "Offset (bits)": "1000"
      },
      {
        "Data Type": "UINT",
        "Description": "Z-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "Z-vel Standard Deviation",
        "Offset (bits)": "1008"
      }
    ],
    "Table": "Table 84: Trigger ADCS Loop with Simulated Sensor Data Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Solution computed",
        "Name": "Solution computed",
        "Numeric Value": "0"
      },
      {
        "Description": "Insufficient observations",
        "Name": "Insufficient observations",
        "Numeric Value": "1"
      },
      {
        "Description": "No convergence",
        "Name": "No convergence",
        "Numeric Value": "2"
      },
      {
        "Description": "Singularity at parameters matrix",
        "Name": "Singularity at parameters matrix",
        "Numeric Value": "3"
      },
      {
        "Description": "Covariance trace exceeds maximum",
        "Name": "Covariance trace exceeds maximum",
        "Numeric Value": "4"
      },
      {
        "Description": "Not yet converged from cold start",
        "Name": "Not yet converged from cold start",
        "Numeric Value": "5"
      },
      {
        "Description": "Height or velocity limits exceeded",
        "Name": "Height or velocity limits exceeded",
        "Numeric Value": "6"
      },
      {
        "Description": "Variance exceeds limits",
        "Name": "Variance exceeds limits",
        "Numeric Value": "7"
      },
      {
        "Description": "Large residuals make position unreliable",
        "Name": "Large residuals make position unreliable",
        "Numeric Value": "8"
      },
      {
        "Description": "Calculating comparison to user provided",
        "Name": "Calculating comparison to user provided",
        "Numeric Value": "9"
      },
      {
        "Description": "The fixed position is invalid",
        "Name": "The fixed position is invalid",
        "Numeric Value": "10"
      },
      {
        "Description": "Position type is unauthorized",
        "Name": "Position type is unauthorized",
        "Numeric Value": "11"
      }
    ],
    "Table": "Table 85: GpsSolutionStatus Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Set ASGP4 run mode",
      "ID": "31",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "ASGP4 enabled state. Possible values are in Table 87: Asgp4ModeSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "ASGP4 Mode",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 86: ASGP4 Run Mode Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "ASGP4 is inactive",
        "Name": "Off",
        "Numeric Value": "0"
      },
      {
        "Description": "ASGP4 is active but waiting for trigger TC",
        "Name": "Trigger",
        "Numeric Value": "1"
      },
      {
        "Description": "ASGP4 runs asynchronously with GPS data received, TLEs updated internal to asgp4 module but not used",
        "Name": "Background",
        "Numeric Value": "2"
      },
      {
        "Description": "ASGP4 runs in background but when processing of data is complete, TLEs used by orbit model is updated with asgp4 estimated TLEs",
        "Name": "Augment",
        "Numeric Value": "3"
      }
    ],
    "Table": "Table 87: Asgp4ModeSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Trigger a start of the ASGP4 process",
      "ID": "32",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 88: ASGP4 Trigger Command Format"
  },
  {
    "Properties": {
      "Description": "Use of main or redundant magnetometer",
      "ID": "56",
      "Parameters Length (bytes)": "1"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Mode describing which magnetometer is used for estimation and control. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetometer Mode",
        "Offset (bits)": "0"
      }
    ],
    "Table": "Table 89: Set Mode of Magnetometer Operation Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Main magnetometer, sampled through signal microcontroller",
        "Name": "Main MTM Sampled Through Signal",
        "Numeric Value": "0"
      },
      {
        "Description": "Redundant magnetometer, sampled through signal microcontroller",
        "Name": "Redundant MTM Sampled Through Signal",
        "Numeric Value": "1"
      },
      {
        "Description": "Main magnetometer, sampled through motor microcontroller",
        "Name": "Main MTM Sampled Through Motor",
        "Numeric Value": "2"
      },
      {
        "Description": "None",
        "Name": "None",
        "Numeric Value": "3"
      }
    ],
    "Table": "Table 90: MagModeVal Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Convert raw or bmp files to JPG",
      "ID": "57",
      "Parameters Length (bytes)": "3"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Source File Counter",
        "Length (bits)": "8",
        "Name": "Source File Counter",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Quality Factor",
        "Length (bits)": "8",
        "Name": "Quality Factor",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "White Balance",
        "Length (bits)": "8",
        "Name": "White Balance",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 91: Convert to JPG file Command Format"
  },
  {
    "Properties": {
      "Description": "Save current configuration to flash memory",
      "ID": "63",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 92: Save Configuration Command Format"
  },
  {
    "Properties": {
      "Description": "Save current orbit parameters to flash memory",
      "ID": "64",
      "Parameters Length (bytes)": "0"
    },
    "Rows": [],
    "Table": "Table 93: Save Orbit Parameters Command Format"
  },
  {
    "Properties": {
      "Description": "Save and capture image from one of CubeSense cameras or CubeStar camera to SD card",
      "ID": "80",
      "Parameters Length (bytes)": "2"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Camera Selection. Possible values are in Table 95: CamSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Camera Select",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Image size selection. Possible values are in Table 96: ImSize Enumeration Values",
        "Length (bits)": "8",
        "Name": "Image Size",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 94: Save Image Command Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Cam1 camera",
        "Name": "Cam1",
        "Numeric Value": "0"
      },
      {
        "Description": "Cam2 camera",
        "Name": "Cam2",
        "Numeric Value": "1"
      },
      {
        "Description": "Star camera",
        "Name": "Star",
        "Numeric Value": "2"
      }
    ],
    "Table": "Table 95: CamSelect Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "1024 x 1024 pixels",
        "Name": "Size 0",
        "Numeric Value": "0"
      },
      {
        "Description": "512 x 512 pixels",
        "Name": "Size 1",
        "Numeric Value": "1"
      },
      {
        "Description": "256 x 256 pixels",
        "Name": "Size 2",
        "Numeric Value": "2"
      },
      {
        "Description": "128 x 128 pixels",
        "Name": "Size 3",
        "Numeric Value": "3"
      },
      {
        "Description": "64 x 64 pixels",
        "Name": "Size 4",
        "Numeric Value": "4"
      }
    ],
    "Table": "Table 96: ImSize Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Current state of the Attitude Control Processor - frame 1 - Table 98: Current ADCS State Telemetry Format",
        "ID": "132",
        "Length (bytes)": "6",
        "Name": "Current ADCS State"
      },
      {
        "Description": "Estimated attitude angles - Table 102: Estimated Attitude Angles Telemetry Format",
        "ID": "146",
        "Length (bytes)": "6",
        "Name": "Estimated Attitude Angles"
      },
      {
        "Description": "Estimated angular rates relative to orbit reference frame - Table 103: Estimated Angular Rates Telemetry Format",
        "ID": "147",
        "Length (bytes)": "6",
        "Name": "Estimated Angular Rates"
      },
      {
        "Description": "Satellite position in ECI frame - Table 104: Satellite Position (ECI) Telemetry Format",
        "ID": "148",
        "Length (bytes)": "6",
        "Name": "Satellite Position (ECI)"
      },
      {
        "Description": "Satellite velocity in ECI frame - Table 105: Satellite Velocity (ECI) Telemetry Format",
        "ID": "149",
        "Length (bytes)": "6",
        "Name": "Satellite Velocity (ECI)"
      },
      {
        "Description": "Satellite position in WGS-84 coordinate frame - Table 106: Satellite Position (LLH) Telemetry Format",
        "ID": "150",
        "Length (bytes)": "6",
        "Name": "Satellite Position (LLH)"
      },
      {
        "Description": "Current ADCS state - Table 149: ADCS State Telemetry Format",
        "ID": "190",
        "Length (bytes)": "54",
        "Name": "ADCS State"
      },
      {
        "Description": "High resolution estimated angular rates relative to orbit reference frame - Table 157: Fine Estimated Angular Rates Telemetry Format",
        "ID": "201",
        "Length (bytes)": "6",
        "Name": "Fine Estimated Angular Rates"
      },
      {
        "Description": "Estimated quaternion set - Table 165: Estimated Quaternion Telemetry Format",
        "ID": "218",
        "Length (bytes)": "6",
        "Name": "Estimated Quaternion"
      },
      {
        "Description": "Satellite position in ECEF coordinates - Table 166: ECEF Position Telemetry Format",
        "ID": "219",
        "Length (bytes)": "6",
        "Name": "ECEF Position"
      },
      {
        "Description": "Current state of the Attitude Control Processor - frame 2 - Table 169: Current ADCS State 2 Telemetry Format",
        "ID": "224",
        "Length (bytes)": "6",
        "Name": "Current ADCS State 2"
      },
      {
        "Description": "Conversion progress - Table 99: JPG Conversion Progress Telemetry Format",
        "ID": "133",
        "Length (bytes)": "3",
        "Name": "JPG Conversion Progress"
      },
      {
        "Description": "Contains flags regarding the state of the ACP - Table 101: CubeACP State Telemetry Format",
        "ID": "135",
        "Length (bytes)": "1",
        "Name": "CubeACP State"
      },
      {
        "Description": "Returns information about execution times of ACP functions - Table 155: Adcs Execution Times Telemetry Format",
        "ID": "196",
        "Length (bytes)": "8",
        "Name": "Adcs Execution Times"
      },
      {
        "Description": "Returns information about the ACP loop - Table 167: ACP Execution State Telemetry Format",
        "ID": "220",
        "Length (bytes)": "3",
        "Name": "ACP Execution State"
      },
      {
        "Description": "Status of Image Capture and Save Operation - Table 176: Status of Image Capture and Save Operation Telemetry Format",
        "ID": "233",
        "Length (bytes)": "2",
        "Name": "Status of Image Capture and Save Operation"
      },
      {
        "Description": "Measured magnetic field vector - Table 107: Magnetic Field Vector Telemetry Format",
        "ID": "151",
        "Length (bytes)": "6",
        "Name": "Magnetic Field Vector"
      },
      {
        "Description": "Measured coarse sun vector - Table 108: Coarse Sun Vector Telemetry Format",
        "ID": "152",
        "Length (bytes)": "6",
        "Name": "Coarse Sun Vector"
      },
      {
        "Description": "Measured fine sun vector - Table 109: Fine Sun Vector Telemetry Format",
        "ID": "153",
        "Length (bytes)": "6",
        "Name": "Fine Sun Vector"
      },
      {
        "Description": "Measured nadir vector - Table 110: Nadir Vector Telemetry Format",
        "ID": "154",
        "Length (bytes)": "6",
        "Name": "Nadir Vector"
      },
      {
        "Description": "Rate sensor measurements - Table 111: Rate Sensor Rates Telemetry Format",
        "ID": "155",
        "Length (bytes)": "6",
        "Name": "Rate Sensor Rates"
      },
      {
        "Description": "Wheel speed measurement - Table 112: Wheel Speed Telemetry Format",
        "ID": "156",
        "Length (bytes)": "6",
        "Name": "Wheel Speed"
      },
      {
        "Description": "Star 1 Body Vector - Table 139: Star 1 Body Vector Telemetry Format",
        "ID": "181",
        "Length (bytes)": "6",
        "Name": "Star 1 Body Vector"
      },
      {
        "Description": "Star 2 Body Vector - Table 140: Star 2 Body Vector Telemetry Format",
        "ID": "182",
        "Length (bytes)": "6",
        "Name": "Star 2 Body Vector"
      },
      {
        "Description": "Star 3 Body Vector - Table 141: Star 3 Body Vector Telemetry Format",
        "ID": "183",
        "Length (bytes)": "6",
        "Name": "Star 3 Body Vector"
      },
      {
        "Description": "Star 1 Orbit Vector - Table 142: Star 1 Orbit Vector Telemetry Format",
        "ID": "184",
        "Length (bytes)": "6",
        "Name": "Star 1 Orbit Vector"
      },
      {
        "Description": "Star 2 Orbit Vector - Table 143: Star 2 Orbit Vector Telemetry Format",
        "ID": "185",
        "Length (bytes)": "6",
        "Name": "Star 2 Orbit Vector"
      },
      {
        "Description": "Star 3 Orbit Vector - Table 144: Star 3 Orbit Vector Telemetry Format",
        "ID": "186",
        "Length (bytes)": "6",
        "Name": "Star 3 Orbit Vector"
      },
      {
        "Description": "Calibrated sensor measurements - Table 150: ADCS Measurements Telemetry Format",
        "ID": "191",
        "Length (bytes)": "72",
        "Name": "ADCS Measurements"
      },
      {
        "Description": "Magnetorquer commands - Table 113: Magnetorquer Command Telemetry Format",
        "ID": "157",
        "Length (bytes)": "6",
        "Name": "Magnetorquer Command"
      },
      {
        "Description": "Wheel speed commands - Table 114: Wheel Speed Commands Telemetry Format",
        "ID": "158",
        "Length (bytes)": "6",
        "Name": "Wheel Speed Commands"
      },
      {
        "Description": "Actuator commands - Table 151: Actuator Commands Telemetry Format",
        "ID": "192",
        "Length (bytes)": "12",
        "Name": "Actuator Commands"
      },
      {
        "Description": "IGRF modelled magnetic field vector (orbit frame referenced) - Table 115: IGRF Modelled Magnetic Field Vector Telemetry Format",
        "ID": "159",
        "Length (bytes)": "6",
        "Name": "IGRF Modelled Magnetic Field Vector"
      },
      {
        "Description": "Modelled sun vector (orbit frame referenced) - Table 116: Modelled Sun Vector Telemetry Format",
        "ID": "160",
        "Length (bytes)": "6",
        "Name": "Modelled Sun Vector"
      },
      {
        "Description": "Estimated rate sensor bias - Table 117: Estimated Gyro Bias Telemetry Format",
        "ID": "161",
        "Length (bytes)": "6",
        "Name": "Estimated Gyro Bias"
      },
      {
        "Description": "Estimation innovation vector - Table 118: Estimation Innovation Vector Telemetry Format",
        "ID": "162",
        "Length (bytes)": "6",
        "Name": "Estimation Innovation Vector"
      },
      {
        "Description": "Quaternion error vector - Table 119: Quaternion Error Vector Telemetry Format",
        "ID": "163",
        "Length (bytes)": "6",
        "Name": "Quaternion Error Vector"
      },
      {
        "Description": "Quaternion covariance - Table 120: Quaternion Covariance Telemetry Format",
        "ID": "164",
        "Length (bytes)": "6",
        "Name": "Quaternion Covariance"
      },
      {
        "Description": "Angular rate covariance - Table 121: Angular Rate Covariance Telemetry Format",
        "ID": "165",
        "Length (bytes)": "6",
        "Name": "Angular Rate Covariance"
      },
      {
        "Description": "Estimation meta-data - Table 152: Estimation Data Telemetry Format",
        "ID": "193",
        "Length (bytes)": "42",
        "Name": "Estimation Data"
      },
      {
        "Description": "ASGP4 TLEs generated - Table 170: ASGP4 TLEs Telemetry Format",
        "ID": "228",
        "Length (bytes)": "33",
        "Name": "ASGP4 TLEs"
      },
      {
        "Description": "Cam2 sensor capture and detection result - Table 122: Raw Cam2 Sensor Telemetry Format",
        "ID": "166",
        "Length (bytes)": "6",
        "Name": "Raw Cam2 Sensor"
      },
      {
        "Description": "Cam1 sensor capture and detection result - Table 125: Raw Cam1 Sensor Telemetry Format",
        "ID": "167",
        "Length (bytes)": "6",
        "Name": "Raw Cam1 Sensor"
      },
      {
        "Description": "Raw CSS measurements 1 to 6 - Table 126: Raw CSS 1 to 6 Telemetry Format",
        "ID": "168",
        "Length (bytes)": "6",
        "Name": "Raw CSS 1 to 6"
      },
      {
        "Description": "Raw CSS measurements 7 to 10 - Table 127: Raw CSS 7 to 10 Telemetry Format",
        "ID": "169",
        "Length (bytes)": "6",
        "Name": "Raw CSS 7 to 10"
      },
      {
        "Description": "Raw magnetometer measurements - Table 128: Raw Magnetometer Telemetry Format",
        "ID": "170",
        "Length (bytes)": "6",
        "Name": "Raw Magnetometer"
      },
      {
        "Description": "Raw GPS status - Table 134: Raw GPS Status Telemetry Format",
        "ID": "176",
        "Length (bytes)": "6",
        "Name": "Raw GPS Status"
      },
      {
        "Description": "Raw GPS time - Table 135: Raw GPS Time Telemetry Format",
        "ID": "177",
        "Length (bytes)": "6",
        "Name": "Raw GPS Time"
      },
      {
        "Description": "Raw GPS X position and velocity (ECI referenced) - Table 136: Raw GPS X Telemetry Format",
        "ID": "178",
        "Length (bytes)": "6",
        "Name": "Raw GPS X"
      },
      {
        "Description": "Raw GPS Y position and velocity (ECI referenced) - Table 137: Raw GPS Y Telemetry Format",
        "ID": "179",
        "Length (bytes)": "6",
        "Name": "Raw GPS Y"
      },
      {
        "Description": "Raw GPS Z position and velocity (ECI referenced) - Table 138: Raw GPS Z Telemetry Format",
        "ID": "180",
        "Length (bytes)": "6",
        "Name": "Raw GPS Z"
      },
      {
        "Description": "Instrument magnitude of identified stars - Table 145: Star Magnitude Telemetry Format",
        "ID": "187",
        "Length (bytes)": "6",
        "Name": "Star Magnitude"
      },
      {
        "Description": "Performance parameters of star measurement - Table 146: Star Performance1 Telemetry Format",
        "ID": "188",
        "Length (bytes)": "6",
        "Name": "Star Performance1"
      },
      {
        "Description": "Timing information of star measurement - Table 148: Star Timing Telemetry Format",
        "ID": "189",
        "Length (bytes)": "6",
        "Name": "Star Timing"
      },
      {
        "Description": "Raw sensor measurements - Table 153: Raw Sensor Measurements Telemetry Format",
        "ID": "194",
        "Length (bytes)": "34",
        "Name": "Raw Sensor Measurements"
      },
      {
        "Description": "Raw GPS measurements - Table 158: Raw GPS Measurements Telemetry Format",
        "ID": "210",
        "Length (bytes)": "36",
        "Name": "Raw GPS Measurements"
      },
      {
        "Description": "Raw Star Tracker Measurement - Table 159: Raw Star Tracker Telemetry Format",
        "ID": "211",
        "Length (bytes)": "54",
        "Name": "Raw Star Tracker"
      },
      {
        "Description": "Catalogue index and detected coordinates for star 1 - Table 160: Star 1 Raw Data Telemetry Format",
        "ID": "212",
        "Length (bytes)": "6",
        "Name": "Star 1 Raw Data"
      },
      {
        "Description": "Catalogue index and detected coordinates for star 2 - Table 161: Star 2 Raw Data Telemetry Format",
        "ID": "213",
        "Length (bytes)": "6",
        "Name": "Star 2 Raw Data"
      },
      {
        "Description": "Catalogue index and detected coordinates for star 3 - Table 162: Star 3 Raw Data Telemetry Format",
        "ID": "214",
        "Length (bytes)": "6",
        "Name": "Star 3 Raw Data"
      },
      {
        "Description": "Secondary Magnetometer raw measurements - Table 163: Secondary Magnetometer Raw Measurements Telemetry Format",
        "ID": "215",
        "Length (bytes)": "6",
        "Name": "Secondary Magnetometer Raw Measurements"
      },
      {
        "Description": "Raw rate sensor measurements - Table 164: Raw Rate Sensor Telemetry Format",
        "ID": "216",
        "Length (bytes)": "6",
        "Name": "Raw Rate Sensor"
      },
      {
        "Description": "Angular rates estimated by CubeStar - Table 172: CubeStar Estimated Rates Telemetry Format",
        "ID": "229",
        "Length (bytes)": "6",
        "Name": "CubeStar Estimated Rates"
      },
      {
        "Description": "Attitude quaternion estimated by CubeStar - Table 173: CubeStar Estimated Quaternion Telemetry Format",
        "ID": "230",
        "Length (bytes)": "6",
        "Name": "CubeStar Estimated Quaternion"
      },
      {
        "Description": "Performance parameters of star measurement - Table 174: Star Performance2 Telemetry Format",
        "ID": "231",
        "Length (bytes)": "6",
        "Name": "Star Performance2"
      },
      {
        "Description": "CubeSense1 current measurements - Table 129: CubeSense1 Current Measurements Telemetry Format",
        "ID": "171",
        "Length (bytes)": "4",
        "Name": "CubeSense1 Current Measurements"
      },
      {
        "Description": "CubeControl current measurements - Table 130: CubeControl Current Measurements Telemetry Format",
        "ID": "172",
        "Length (bytes)": "6",
        "Name": "CubeControl Current Measurements"
      },
      {
        "Description": "XYZ Wheel current measurement - Table 131: Wheel Currents Telemetry Format",
        "ID": "173",
        "Length (bytes)": "6",
        "Name": "Wheel Currents"
      },
      {
        "Description": "Magnetometer + MCU temperature measurements - Table 132: ADCS Temperatures Telemetry Format",
        "ID": "174",
        "Length (bytes)": "6",
        "Name": "ADCS Temperatures"
      },
      {
        "Description": "Rate sensor temperatures - Table 133: Rate sensor temperatures Telemetry Format",
        "ID": "175",
        "Length (bytes)": "6",
        "Name": "Rate sensor temperatures"
      },
      {
        "Description": "Power and temperature measurements - Table 154: Power and Temperature Measurements Telemetry Format",
        "ID": "195",
        "Length (bytes)": "38",
        "Name": "Power and Temperature Measurements"
      },
      {
        "Description": "CubeStar and Torquer current and temperature measurements - Table 156: ADCS Misc Current Measurements Telemetry Format",
        "ID": "198",
        "Length (bytes)": "6",
        "Name": "ADCS Misc Current Measurements"
      },
      {
        "Description": "CubeSense2 current measurements - Table 175: CubeSense2 Current Measurements Telemetry Format",
        "ID": "232",
        "Length (bytes)": "4",
        "Name": "CubeSense2 Current Measurements"
      }
    ],
    "Table": "Table 97: List of CubeAcp Telemetry Frames"
  },
  {
    "Properties": {
      "Description": "Current state of the Attitude Control Processor - frame 1",
      "Frame Length (bytes)": "6",
      "ID": "132"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Current attitude estimation mode. Possible values are in Table 80: EstimModeSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "Attitude Estimation Mode",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current attitude control mode. Possible values are in Table 78: ConModeSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "Control Mode",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current ADCS Running mode. Possible values are in Table 75: AdcsRunMode Enumeration Values",
        "Length (bits)": "2",
        "Name": "ADCS Run Mode",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "ASGP4 enabled state. Possible values are in Table 87: Asgp4ModeSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "ASGP4 Mode",
        "Offset (bits)": "10"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeControl Signal electronics enabled status",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Enabled",
        "Offset (bits)": "12"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeControl Motor electronics enabled status",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Enabled",
        "Offset (bits)": "13"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeSense1 enabled status",
        "Length (bits)": "1",
        "Name": "CubeSense1 Enabled",
        "Offset (bits)": "14"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeSense2 enabled status",
        "Length (bits)": "1",
        "Name": "CubeSense2 Enabled",
        "Offset (bits)": "15"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel1 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Enabled",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel2 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Enabled",
        "Offset (bits)": "17"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel3 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Enabled",
        "Offset (bits)": "18"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeStar enabled status",
        "Length (bits)": "1",
        "Name": "CubeStar Enabled",
        "Offset (bits)": "19"
      },
      {
        "Data Type": "BOOL",
        "Description": "GPS Receiver enabled status",
        "Length (bits)": "1",
        "Name": "GPS Receiver Enabled",
        "Offset (bits)": "20"
      },
      {
        "Data Type": "BOOL",
        "Description": "GPS Antenna LNA enabled status",
        "Length (bits)": "1",
        "Name": "GPS LNA Power Enabled",
        "Offset (bits)": "21"
      },
      {
        "Data Type": "BOOL",
        "Description": "Motor Driver Electronics enabled status",
        "Length (bits)": "1",
        "Name": "Motor Driver Enabled",
        "Offset (bits)": "22"
      },
      {
        "Data Type": "BOOL",
        "Description": "Sun is above the local horizon (elevation > 0)",
        "Length (bits)": "1",
        "Name": "Sun is Above Local Horizon",
        "Offset (bits)": "23"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeSense1",
        "Length (bits)": "1",
        "Name": "CubeSense1 Communications Error",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeSense2",
        "Length (bits)": "1",
        "Name": "CubeSense2 Communications Error",
        "Offset (bits)": "25"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeControl Signal MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Communications Error",
        "Offset (bits)": "26"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeControl Motor MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Communications Error",
        "Offset (bits)": "27"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel1",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Communications Error",
        "Offset (bits)": "28"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel2",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Communications Error",
        "Offset (bits)": "29"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel3",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Communications Error",
        "Offset (bits)": "30"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeStar",
        "Length (bits)": "1",
        "Name": "CubeStar Communications Error",
        "Offset (bits)": "31"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetometer measured magnetic field with size 65 uT",
        "Length (bits)": "1",
        "Name": "Magnetometer Range Error",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 SRAM overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam1 SRAM Overcurrent Detected",
        "Offset (bits)": "33"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 3V3 overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam1 3V3 Overcurrent Detected",
        "Offset (bits)": "34"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 sensor was not idle at the start of ADCS loop",
        "Length (bits)": "1",
        "Name": "Cam1 Sensor Busy Error",
        "Offset (bits)": "35"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 sensor was unable to compute angles (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Cam1 Sensor Detection Error",
        "Offset (bits)": "36"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detected sun angles were outside of +/- 90 deg",
        "Length (bits)": "1",
        "Name": "Sun Sensor Range Error",
        "Offset (bits)": "37"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 SRAM overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam2 SRAM Overcurrent Detected",
        "Offset (bits)": "38"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 3V3 overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam2 3V3 Overcurrent Detected",
        "Offset (bits)": "39"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 sensor was not idle at the start of ADCS loop",
        "Length (bits)": "1",
        "Name": "Cam2 Sensor Busy Error",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 sensor was unable to compute angles (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Cam2 Sensor Detection Error",
        "Offset (bits)": "41"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detected nadir angles were outside of +/- 60 deg",
        "Length (bits)": "1",
        "Name": "Nadir Sensor Range Error",
        "Offset (bits)": "42"
      },
      {
        "Data Type": "BOOL",
        "Description": "Measured XYZ-body rate is outside of the range +/-20 deg/s",
        "Length (bits)": "1",
        "Name": "Rate Sensor Range Error",
        "Offset (bits)": "43"
      },
      {
        "Data Type": "BOOL",
        "Description": "Wheel XYZ speed measurement was outside the range +/-8500 rpm",
        "Length (bits)": "1",
        "Name": "Wheel Speed Range Error",
        "Offset (bits)": "44"
      },
      {
        "Data Type": "BOOL",
        "Description": "Unable to compute Coarse Sun vector (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Coarse Sun Sensor Error",
        "Offset (bits)": "45"
      },
      {
        "Data Type": "BOOL",
        "Description": "Unable to obtain enough matched stars",
        "Length (bits)": "1",
        "Name": "StarTracker Match Error",
        "Offset (bits)": "46"
      },
      {
        "Data Type": "BOOL",
        "Description": "Star tracker overcurrent detected",
        "Length (bits)": "1",
        "Name": "Star Tracker Overcurrent Detected",
        "Offset (bits)": "47"
      }
    ],
    "Table": "Table 98: Current ADCS State Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Conversion progress",
      "Frame Length (bytes)": "3",
      "ID": "133"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Progress %",
        "Length (bits)": "8",
        "Name": "Progress Percentage",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "JPG Conversion Result. Possible values are in Table 100: JpgConvertResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Conversion Result",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Output File Counter",
        "Length (bits)": "8",
        "Name": "Output File Counter",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 99: JPG Conversion Progress Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Nothing Converted Yet",
        "Name": "Nothing Converted Yet",
        "Numeric Value": "0"
      },
      {
        "Description": "Success",
        "Name": "Success",
        "Numeric Value": "1"
      },
      {
        "Description": "File Load Error",
        "Name": "File Load Error",
        "Numeric Value": "2"
      },
      {
        "Description": "Busy",
        "Name": "Busy",
        "Numeric Value": "3"
      }
    ],
    "Table": "Table 100: JpgConvertResult Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Contains flags regarding the state of the ACP",
      "Frame Length (bytes)": "1",
      "ID": "135"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that the ADCS configuration was not read successfully out of flash",
        "Length (bits)": "1",
        "Name": "ADCS Config Load Error",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that the Orbit parameters were not read successfully out of flash",
        "Length (bits)": "1",
        "Name": "Orbit Parameter Load Error",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that the System Configuration was not read successfully out of flash",
        "Length (bits)": "1",
        "Name": "System Configuration Load Error",
        "Offset (bits)": "2"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that the SD card failed to initialise",
        "Length (bits)": "1",
        "Name": "SD card initialisation error",
        "Offset (bits)": "3"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that a read operation from the SD card failed",
        "Length (bits)": "1",
        "Name": "SD card read error",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "BOOL",
        "Description": "Flag to indicate that a write operation to the SD card failed",
        "Length (bits)": "1",
        "Name": "SD card write error",
        "Offset (bits)": "5"
      }
    ],
    "Table": "Table 101: CubeACP State Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimated attitude angles",
      "Frame Length (bytes)": "6",
      "ID": "146"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated roll angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Roll Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated pitch angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Pitch Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated yaw angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Yaw Angle",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 102: Estimated Attitude Angles Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimated angular rates relative to orbit reference frame",
      "Frame Length (bytes)": "6",
      "ID": "147"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated X angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated X Angular Rate",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Y angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Y Angular Rate",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Z angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Z Angular Rate",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 103: Estimated Angular Rates Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Satellite position in ECI frame",
      "Frame Length (bytes)": "6",
      "ID": "148"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECI referenced X coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "X position",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Y coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Y position",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Z coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Z position",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 104: Satellite Position (ECI) Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Satellite velocity in ECI frame",
      "Frame Length (bytes)": "6",
      "ID": "149"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECI referenced X velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "X Velocity",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Y velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Y Velocity",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Z velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Z Velocity",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 105: Satellite Velocity (ECI) Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Satellite position in WGS-84 coordinate frame",
      "Frame Length (bytes)": "6",
      "ID": "150"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "WGS-84 Latitude angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Latitude",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Longitude angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Longitude",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "WGS-84 altitude. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Altitude",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 106: Satellite Position (LLH) Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Measured magnetic field vector",
      "Frame Length (bytes)": "6",
      "ID": "151"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Magnetic Field X. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetic Field Y. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetic Field Z. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 107: Magnetic Field Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Measured coarse sun vector",
      "Frame Length (bytes)": "6",
      "ID": "152"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Coarse Sun X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Coarse Sun Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Coarse Sun Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 108: Coarse Sun Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Measured fine sun vector",
      "Frame Length (bytes)": "6",
      "ID": "153"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Sun X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Sun Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Sun Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 109: Fine Sun Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Measured nadir vector",
      "Frame Length (bytes)": "6",
      "ID": "154"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Nadir X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Nadir Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Nadir Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 110: Nadir Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Rate sensor measurements",
      "Frame Length (bytes)": "6",
      "ID": "155"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "X Angular Rate",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Y Angular Rate",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Z Angular Rate",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 111: Rate Sensor Rates Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Wheel speed measurement",
      "Frame Length (bytes)": "6",
      "ID": "156"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "X Wheel Speed",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Y Wheel Speed",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Z Wheel Speed",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 112: Wheel Speed Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Magnetorquer commands",
      "Frame Length (bytes)": "6",
      "ID": "157"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "X Magnetorquer Command",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "Y Magnetorquer Command",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "Z Magnetorquer Command",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 113: Magnetorquer Command Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Wheel speed commands",
      "Frame Length (bytes)": "6",
      "ID": "158"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded X Wheel Speed",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Y Wheel Speed",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Z Wheel Speed",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 114: Wheel Speed Commands Telemetry Format"
  },
  {
    "Properties": {
      "Description": "IGRF modelled magnetic field vector (orbit frame referenced)",
      "Frame Length (bytes)": "6",
      "ID": "159"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field X. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field Y. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field Z. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 115: IGRF Modelled Magnetic Field Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Modelled sun vector (orbit frame referenced)",
      "Frame Length (bytes)": "6",
      "ID": "160"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 116: Modelled Sun Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimated rate sensor bias",
      "Frame Length (bytes)": "6",
      "ID": "161"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated X-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated X-gyro Bias",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Y-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Y-gyro Bias",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Z-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Z-gyro Bias",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 117: Estimated Gyro Bias Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimation innovation vector",
      "Frame Length (bytes)": "6",
      "ID": "162"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Innovation Vector X. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Innovation Vector Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Innovation Vector Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 118: Estimation Innovation Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Quaternion error vector",
      "Frame Length (bytes)": "6",
      "ID": "163"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q1. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q1",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q2. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q2",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q3. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q3",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 119: Quaternion Error Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Quaternion covariance",
      "Frame Length (bytes)": "6",
      "ID": "164"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q1 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q1 RMS",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q2 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q2 RMS",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q3 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q3 RMS",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 120: Quaternion Covariance Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Angular rate covariance",
      "Frame Length (bytes)": "6",
      "ID": "165"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "X Angular Rate Covariance",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Y Angular Rate Covariance",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Z Angular Rate Covariance",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 121: Angular Rate Covariance Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Cam2 sensor capture and detection result",
      "Frame Length (bytes)": "6",
      "ID": "166"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Cam2 azimuth angle",
        "Length (bits)": "16",
        "Name": "Cam2 centroid X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 elevation angle",
        "Length (bits)": "16",
        "Name": "Cam2 centroid Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam2 capture status. Possible values are in Table 123: CaptureResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam2 Capture status",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam2 detection result. Possible values are in Table 124: DetectResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam2 Detection result",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 122: Raw Cam2 Sensor Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Start-up",
        "Name": "Startup",
        "Numeric Value": "0"
      },
      {
        "Description": "Capture pending",
        "Name": "Pending",
        "Numeric Value": "1"
      },
      {
        "Description": "Successfully captured",
        "Name": "Success",
        "Numeric Value": "2"
      },
      {
        "Description": "Successfully captured on other SRAM (only applicable to CubeSense V2 hardware)",
        "Name": "SuccessShift",
        "Numeric Value": "3"
      },
      {
        "Description": "Camera timeout",
        "Name": "Timeout",
        "Numeric Value": "4"
      },
      {
        "Description": "SRAM overcurrent",
        "Name": "SRAMError",
        "Numeric Value": "5"
      }
    ],
    "Table": "Table 123: CaptureResult Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Start-up",
        "Name": "Startup",
        "Numeric Value": "0"
      },
      {
        "Description": "No detection scheduled",
        "Name": "NoDetect",
        "Numeric Value": "1"
      },
      {
        "Description": "Detection pending",
        "Name": "Pending",
        "Numeric Value": "2"
      },
      {
        "Description": "Nadir error - too many detected edges",
        "Name": "TooManyEdges",
        "Numeric Value": "3"
      },
      {
        "Description": "Nadir error - not enough edges detected",
        "Name": "TooFewEdges",
        "Numeric Value": "4"
      },
      {
        "Description": "Nadir error - bad fit",
        "Name": "BadFit",
        "Numeric Value": "5"
      },
      {
        "Description": "Sun error - sun not found",
        "Name": "SunNotFound",
        "Numeric Value": "6"
      },
      {
        "Description": "Successful detection",
        "Name": "Success",
        "Numeric Value": "7"
      }
    ],
    "Table": "Table 124: DetectResult Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Cam1 sensor capture and detection result",
      "Frame Length (bytes)": "6",
      "ID": "167"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Cam1 azimuth angle",
        "Length (bits)": "16",
        "Name": "Cam1 centroid X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 elevation angle",
        "Length (bits)": "16",
        "Name": "Cam1 centroid Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam1 capture status. Possible values are in Table 123: CaptureResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam1 Capture status",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam1 detection result. Possible values are in Table 124: DetectResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam1 Detection result",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 125: Raw Cam1 Sensor Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw CSS measurements 1 to 6",
      "Frame Length (bytes)": "6",
      "ID": "168"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS1",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS2",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS3",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS4",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS5",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS6",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 126: Raw CSS 1 to 6 Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw CSS measurements 7 to 10",
      "Frame Length (bytes)": "6",
      "ID": "169"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS7",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS8",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS9",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS10",
        "Offset (bits)": "24"
      }
    ],
    "Table": "Table 127: Raw CSS 7 to 10 Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw magnetometer measurements",
      "Frame Length (bytes)": "6",
      "ID": "170"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 128: Raw Magnetometer Telemetry Format"
  },
  {
    "Properties": {
      "Description": "CubeSense1 current measurements",
      "Frame Length (bytes)": "4",
      "ID": "171"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "CubeSense1 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense1 3V3 Current",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense1 Cam SRAM Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense1 Cam SRAM Current",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 129: CubeSense1 Current Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "CubeControl current measurements",
      "Frame Length (bytes)": "6",
      "ID": "172"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "CubeControl 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl 3V3 Current",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl 5V Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl 5V Current",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl Vbat Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl Vbat Current",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 130: CubeControl Current Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "XYZ Wheel current measurement",
      "Frame Length (bytes)": "6",
      "ID": "173"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Wheel1 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel1Current",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Wheel2 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel2Current",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Wheel3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel3Current",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 131: Wheel Currents Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Magnetometer + MCU temperature measurements",
      "Frame Length (bytes)": "6",
      "ID": "174"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "MCU Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "MCU Temperature",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/10.0",
        "Length (bits)": "16",
        "Name": "Magnetometer Temperature",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/10.0",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Temperature",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 132: ADCS Temperatures Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Rate sensor temperatures",
      "Frame Length (bytes)": "6",
      "ID": "175"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "X-Rate Sensor Temperature",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "Y-Rate Sensor Temperature",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "Z-Rate Sensor Temperature",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 133: Rate sensor temperatures Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS status",
      "Frame Length (bytes)": "6",
      "ID": "176"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "GPS Solution Status. Possible values are in Table 85: GpsSolutionStatus Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gps Solution Status",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of tracked GPS satellites",
        "Length (bits)": "8",
        "Name": "Number of tracked GPS satellites",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of GPS satellites used in solution",
        "Length (bits)": "8",
        "Name": "Number of GPS satellites used in solution",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Counter for XYZ Lof from GPS",
        "Length (bits)": "8",
        "Name": "Counter for XYZ Lof from GPS",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "Counter for RANGE log from GPS",
        "Length (bits)": "8",
        "Name": "Counter for RANGE log from GPS",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Response Message for GPS log setup - p656 of OEMV615 reference manual",
        "Length (bits)": "8",
        "Name": "Response Message for GPS log setup",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 134: Raw GPS Status Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS time",
      "Frame Length (bytes)": "6",
      "ID": "177"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "GPS Reference Week",
        "Length (bits)": "16",
        "Name": "GPS Reference Week",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS Time Milliseconds. (Unit of measure is [ms])",
        "Length (bits)": "32",
        "Name": "GPS Time Milliseconds",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 135: Raw GPS Time Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS X position and velocity (ECI referenced)",
      "Frame Length (bytes)": "6",
      "ID": "178"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECEF Position X. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity X. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity X",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 136: Raw GPS X Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS Y position and velocity (ECI referenced)",
      "Frame Length (bytes)": "6",
      "ID": "179"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECEF Position Y. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Y",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Y. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Y",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 137: Raw GPS Y Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS Z position and velocity (ECI referenced)",
      "Frame Length (bytes)": "6",
      "ID": "180"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECEF Position Z. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Z",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Z. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 138: Raw GPS Z Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 1 Body Vector",
      "Frame Length (bytes)": "6",
      "ID": "181"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star1 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 139: Star 1 Body Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 2 Body Vector",
      "Frame Length (bytes)": "6",
      "ID": "182"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star2 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 140: Star 2 Body Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 3 Body Vector",
      "Frame Length (bytes)": "6",
      "ID": "183"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star3 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 141: Star 3 Body Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 1 Orbit Vector",
      "Frame Length (bytes)": "6",
      "ID": "184"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star1 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 142: Star 1 Orbit Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 2 Orbit Vector",
      "Frame Length (bytes)": "6",
      "ID": "185"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star2 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 143: Star 2 Orbit Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Star 3 Orbit Vector",
      "Frame Length (bytes)": "6",
      "ID": "186"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Star3 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 144: Star 3 Orbit Vector Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Instrument magnitude of identified stars",
      "Frame Length (bytes)": "6",
      "ID": "187"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 1",
        "Length (bits)": "16",
        "Name": "Magnitude Star 1",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 2",
        "Length (bits)": "16",
        "Name": "Magnitude Star 2",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 3",
        "Length (bits)": "16",
        "Name": "Magnitude Star 3",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 145: Star Magnitude Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Performance parameters of star measurement",
      "Frame Length (bytes)": "6",
      "ID": "188"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Number of stars detected. (Unit of measure is [stars])",
        "Length (bits)": "8",
        "Name": "Number of stars detected",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Star image noise. (Unit of measure is [noise])",
        "Length (bits)": "8",
        "Name": "Star image noise",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of invalid stars detected. (Unit of measure is [Invalid stars])",
        "Length (bits)": "8",
        "Name": "Invalid Stars",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of stars identified. (Unit of measure is [stars])",
        "Length (bits)": "8",
        "Name": "Number of stars identified",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "ENUM",
        "Description": "Identification mode. Possible values are in Table 147: StarIDModeVal Enumeration Values",
        "Length (bits)": "8",
        "Name": "Identification mode",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "The average value of center line in image. (Unit of measure is [8-bit pixel value])",
        "Length (bits)": "8",
        "Name": "Image dark value",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 146: Star Performance1 Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "",
        "Name": "Tracking Mode",
        "Numeric Value": "0"
      },
      {
        "Description": "",
        "Name": "Lost Mode",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 147: StarIDModeVal Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Timing information of star measurement",
      "Frame Length (bytes)": "6",
      "ID": "189"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Capture. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Capture",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Detection. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Detection",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Identification. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Identification",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 148: Star Timing Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Current ADCS state",
      "Frame Length (bytes)": "54",
      "ID": "190"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Current attitude estimation mode. Possible values are in Table 80: EstimModeSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "Attitude Estimation Mode",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current attitude control mode. Possible values are in Table 78: ConModeSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "Control Mode",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current ADCS Running mode. Possible values are in Table 75: AdcsRunMode Enumeration Values",
        "Length (bits)": "2",
        "Name": "ADCS Run Mode",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "ASGP4 enabled state. Possible values are in Table 87: Asgp4ModeSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "ASGP4 Mode",
        "Offset (bits)": "10"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeControl Signal electronics enabled status",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Enabled",
        "Offset (bits)": "12"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeControl Motor electronics enabled status",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Enabled",
        "Offset (bits)": "13"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeSense1 enabled status",
        "Length (bits)": "1",
        "Name": "CubeSense1 Enabled",
        "Offset (bits)": "14"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeSense2 enabled status",
        "Length (bits)": "1",
        "Name": "CubeSense2 Enabled",
        "Offset (bits)": "15"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel1 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Enabled",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel2 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Enabled",
        "Offset (bits)": "17"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeWheel3 enabled status",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Enabled",
        "Offset (bits)": "18"
      },
      {
        "Data Type": "BOOL",
        "Description": "CubeStar enabled status",
        "Length (bits)": "1",
        "Name": "CubeStar Enabled",
        "Offset (bits)": "19"
      },
      {
        "Data Type": "BOOL",
        "Description": "GPS Receiver enabled status",
        "Length (bits)": "1",
        "Name": "GPS Receiver Enabled",
        "Offset (bits)": "20"
      },
      {
        "Data Type": "BOOL",
        "Description": "GPS Antenna LNA enabled status",
        "Length (bits)": "1",
        "Name": "GPS LNA Power Enabled",
        "Offset (bits)": "21"
      },
      {
        "Data Type": "BOOL",
        "Description": "Motor Driver Electronics enabled status",
        "Length (bits)": "1",
        "Name": "Motor Driver Enabled",
        "Offset (bits)": "22"
      },
      {
        "Data Type": "BOOL",
        "Description": "Sun is above the local horizon (elevation > 0)",
        "Length (bits)": "1",
        "Name": "Sun is Above Local Horizon",
        "Offset (bits)": "23"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeSense1",
        "Length (bits)": "1",
        "Name": "CubeSense1 Communications Error",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeSense2",
        "Length (bits)": "1",
        "Name": "CubeSense2 Communications Error",
        "Offset (bits)": "25"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeControl Signal MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Communications Error",
        "Offset (bits)": "26"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeControl Motor MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Communications Error",
        "Offset (bits)": "27"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel1",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Communications Error",
        "Offset (bits)": "28"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel2",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Communications Error",
        "Offset (bits)": "29"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeWheel3",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Communications Error",
        "Offset (bits)": "30"
      },
      {
        "Data Type": "BOOL",
        "Description": "Communication error occurred with the CubeStar",
        "Length (bits)": "1",
        "Name": "CubeStar Communications Error",
        "Offset (bits)": "31"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetometer measured magnetic field with size 65 uT",
        "Length (bits)": "1",
        "Name": "Magnetometer Range Error",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 SRAM overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam1 SRAM Overcurrent Detected",
        "Offset (bits)": "33"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 3V3 overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam1 3V3 Overcurrent Detected",
        "Offset (bits)": "34"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 sensor was not idle at the start of ADCS loop",
        "Length (bits)": "1",
        "Name": "Cam1 Sensor Busy Error",
        "Offset (bits)": "35"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam1 sensor was unable to compute angles (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Cam1 Sensor Detection Error",
        "Offset (bits)": "36"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detected sun angles were outside of +/- 90 deg",
        "Length (bits)": "1",
        "Name": "Sun Sensor Range Error",
        "Offset (bits)": "37"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 SRAM overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam2 SRAM Overcurrent Detected",
        "Offset (bits)": "38"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 3V3 overcurrent detected",
        "Length (bits)": "1",
        "Name": "Cam2 3V3 Overcurrent Detected",
        "Offset (bits)": "39"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 sensor was not idle at the start of ADCS loop",
        "Length (bits)": "1",
        "Name": "Cam2 Sensor Busy Error",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "BOOL",
        "Description": "Cam2 sensor was unable to compute angles (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Cam2 Sensor Detection Error",
        "Offset (bits)": "41"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detected nadir angles were outside of +/- 60 deg",
        "Length (bits)": "1",
        "Name": "Nadir Sensor Range Error",
        "Offset (bits)": "42"
      },
      {
        "Data Type": "BOOL",
        "Description": "Measured XYZ-body rate is outside of the range +/-20 deg/s",
        "Length (bits)": "1",
        "Name": "Rate Sensor Range Error",
        "Offset (bits)": "43"
      },
      {
        "Data Type": "BOOL",
        "Description": "Wheel XYZ speed measurement was outside the range +/-8500 rpm",
        "Length (bits)": "1",
        "Name": "Wheel Speed Range Error",
        "Offset (bits)": "44"
      },
      {
        "Data Type": "BOOL",
        "Description": "Unable to compute Coarse Sun vector (could be not in FOV)",
        "Length (bits)": "1",
        "Name": "Coarse Sun Sensor Error",
        "Offset (bits)": "45"
      },
      {
        "Data Type": "BOOL",
        "Description": "Unable to obtain enough matched stars",
        "Length (bits)": "1",
        "Name": "StarTracker Match Error",
        "Offset (bits)": "46"
      },
      {
        "Data Type": "BOOL",
        "Description": "Star tracker overcurrent detected",
        "Length (bits)": "1",
        "Name": "Star Tracker Overcurrent Detected",
        "Offset (bits)": "47"
      },
      {
        "Data Type": "BOOL",
        "Description": "Orbit Parameters are not in allowed bounds (angle exceeding limits etc.). Failed to initialize SGP4 propagator using supplied parameters",
        "Length (bits)": "1",
        "Name": "Orbit Parameters are Invalid",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetorquer Configuration or CSS in invalid. Each principle axis should have a torquer output (1,2, or 3) assigned. At least one CSS per principle axis needed",
        "Length (bits)": "1",
        "Name": "Configuration is Invalid",
        "Offset (bits)": "49"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attempt was made to select control mode without appropriate estimator, or command to set Y-momentum mode while not in steady-state Y-Thomson",
        "Length (bits)": "1",
        "Name": "Control Mode Change is not allowed",
        "Offset (bits)": "50"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attempt was made to change to an estimation mode that would be inappropriate for the current control mode",
        "Length (bits)": "1",
        "Name": "Estimator Change is not allowed",
        "Offset (bits)": "51"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current magnetometer sampling mode. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Current Magnetometer Sampling Mode",
        "Offset (bits)": "52"
      },
      {
        "Data Type": "BOOL",
        "Description": "Modelled and measured magnetic field differs in size by more than 5000 nT",
        "Length (bits)": "1",
        "Name": "Modelled and measured magnetic field differs in size",
        "Offset (bits)": "54"
      },
      {
        "Data Type": "BOOL",
        "Description": "Failed to Recover an ADCS Node by successive resets",
        "Length (bits)": "1",
        "Name": "Node Recovery Error",
        "Offset (bits)": "55"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeSense1",
        "Length (bits)": "1",
        "Name": "CubeSense1 Runtime Error",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeSense2",
        "Length (bits)": "1",
        "Name": "CubeSense2 Runtime Error",
        "Offset (bits)": "57"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeControl Signal MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Runtime Error",
        "Offset (bits)": "58"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeControl Motor MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Runtime Error",
        "Offset (bits)": "59"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel1",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Runtime Error",
        "Offset (bits)": "60"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel2",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Runtime Error",
        "Offset (bits)": "61"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel3",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Runtime Error",
        "Offset (bits)": "62"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeStar",
        "Length (bits)": "1",
        "Name": "CubeStar Runtime Error",
        "Offset (bits)": "63"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetometer failure occurred",
        "Length (bits)": "1",
        "Name": "Magnetometer Error",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "BOOL",
        "Description": "Rate sensor failure occurred",
        "Length (bits)": "1",
        "Name": "Rate Sensor Failure",
        "Offset (bits)": "65"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated roll angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Roll Angle",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated pitch angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Pitch Angle",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated yaw angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Yaw Angle",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated q1",
        "Length (bits)": "16",
        "Name": "Estimated q1",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated q2",
        "Length (bits)": "16",
        "Name": "Estimated q2",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated q3",
        "Length (bits)": "16",
        "Name": "Estimated q3",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated X angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated X Angular Rate",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Y angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Y Angular Rate",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Z angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Estimated Z Angular Rate",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced X coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "X position",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Y coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Y position",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Z coordinate. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Z position",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced X velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "X Velocity",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Y velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Y Velocity",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "INT",
        "Description": "ECI referenced Z velocity. Formatted value is obtained using the formula: (formatted value) [m/s] = RAWVAL*0.25",
        "Length (bits)": "16",
        "Name": "Z Velocity",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "INT",
        "Description": "WGS-84 Latitude angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Latitude",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "INT",
        "Description": "Longitude angle. Formatted value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Longitude",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "UINT",
        "Description": "WGS-84 altitude. Formatted value is obtained using the formula: (formatted value) [km] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Altitude",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position X. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position X",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Y. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position Y",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Z. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position Z",
        "Offset (bits)": "416"
      }
    ],
    "Table": "Table 149: ADCS State Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Calibrated sensor measurements",
      "Frame Length (bytes)": "72",
      "ID": "191"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Magnetic Field X. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetic Field Y. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetic Field Z. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetic Field Z",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "Coarse Sun X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun X",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Coarse Sun Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun Y",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "Coarse Sun Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Coarse Sun Z",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "INT",
        "Description": "Sun X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun X",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Sun Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun Y",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Sun Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Sun Z",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Nadir X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir X",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "Nadir Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir Y",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Nadir Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Nadir Z",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "X Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "X Angular Rate",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Y Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Y Angular Rate",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Z Angular Rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Z Angular Rate",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "INT",
        "Description": "X Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "X Wheel Speed",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "Y Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Y Wheel Speed",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "INT",
        "Description": "Z Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Z Wheel Speed",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BX",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BY",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1BZ",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OX",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OY",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "INT",
        "Description": "Star1 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star1OZ",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BX",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BY",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2BZ",
        "Offset (bits)": "416"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OX",
        "Offset (bits)": "432"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OY",
        "Offset (bits)": "448"
      },
      {
        "Data Type": "INT",
        "Description": "Star2 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star2OZ",
        "Offset (bits)": "464"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 body X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BX",
        "Offset (bits)": "480"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 body Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BY",
        "Offset (bits)": "496"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 body Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3BZ",
        "Offset (bits)": "512"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 orbit X-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OX",
        "Offset (bits)": "528"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 orbit Y-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OY",
        "Offset (bits)": "544"
      },
      {
        "Data Type": "INT",
        "Description": "Star3 orbit Z-vector. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Star3OZ",
        "Offset (bits)": "560"
      }
    ],
    "Table": "Table 150: ADCS Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Actuator commands",
      "Frame Length (bytes)": "12",
      "ID": "192"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "X Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "X Magnetorquer Command",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Y Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "Y Magnetorquer Command",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Z Magnetorquer Commanded on-time. (Unit of measure is [10ms units])",
        "Length (bits)": "16",
        "Name": "Z Magnetorquer Command",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "X Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded X Wheel Speed",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Y Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Y Wheel Speed",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "Z Wheel Speed. (Unit of measure is [rpm])",
        "Length (bits)": "16",
        "Name": "Commanded Z Wheel Speed",
        "Offset (bits)": "80"
      }
    ],
    "Table": "Table 151: Actuator Commands Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimation meta-data",
      "Frame Length (bytes)": "42",
      "ID": "193"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field X. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field Y. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "IGRF Modelled Magnetic Field Z. Formatted value is obtained using the formula: (formatted value) [uT] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "IGRF Modelled Magnetic Field Z",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector X. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector X",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector Y",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "Modelled Sun Vector Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Modelled Sun Vector Z",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated X-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated X-gyro Bias",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Y-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Y-gyro Bias",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Z-gyro Bias. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Z-gyro Bias",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Innovation Vector X. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector X",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "Innovation Vector Y. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector Y",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Innovation Vector Z. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Innovation Vector Z",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q1. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q1",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q2. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q2",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Error - Q3. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.0001",
        "Length (bits)": "16",
        "Name": "Quaternion Error - Q3",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q1 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q1 RMS",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q2 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q2 RMS",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "INT",
        "Description": "Quaternion Covariance - Q3 RMS. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Quaternion Covariance - Q3 RMS",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "INT",
        "Description": "X Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "X Angular Rate Covariance",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "INT",
        "Description": "Y Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Y Angular Rate Covariance",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "INT",
        "Description": "Z Angular Rate Covariance. Formatted value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Z Angular Rate Covariance",
        "Offset (bits)": "320"
      }
    ],
    "Table": "Table 152: Estimation Data Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw sensor measurements",
      "Frame Length (bytes)": "34",
      "ID": "194"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Cam2 azimuth angle",
        "Length (bits)": "16",
        "Name": "Cam2 centroid X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 elevation angle",
        "Length (bits)": "16",
        "Name": "Cam2 centroid Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam2 capture status. Possible values are in Table 123: CaptureResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam2 Capture status",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam2 detection result. Possible values are in Table 124: DetectResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam2 Detection result",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 azimuth angle",
        "Length (bits)": "16",
        "Name": "Cam1 centroid X",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 elevation angle",
        "Length (bits)": "16",
        "Name": "Cam1 centroid Y",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam1 capture status. Possible values are in Table 123: CaptureResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam1 Capture status",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "ENUM",
        "Description": "Cam1 detection result. Possible values are in Table 124: DetectResult Enumeration Values",
        "Length (bits)": "8",
        "Name": "Cam1 Detection result",
        "Offset (bits)": "88"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS1",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS2",
        "Offset (bits)": "104"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS3",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS4",
        "Offset (bits)": "120"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS5",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS6",
        "Offset (bits)": "136"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS7",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS8",
        "Offset (bits)": "152"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS9",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "UINT",
        "Description": "sampled A/D value - corresponds to COS(sun_angle)",
        "Length (bits)": "8",
        "Name": "CSS10",
        "Offset (bits)": "168"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagX",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagY",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagZ",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateX",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateY",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateZ",
        "Offset (bits)": "256"
      }
    ],
    "Table": "Table 153: Raw Sensor Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Power and temperature measurements",
      "Frame Length (bytes)": "38",
      "ID": "195"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "CubeSense1 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense1 3V3 Current",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense1 Cam SRAM Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense1 Cam SRAM Current",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense2 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense2 3V3 Current",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense2 Cam SRAM Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense2 Cam SRAM Current",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl 3V3 Current",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl 5V Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl 5V Current",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl Vbat Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.48828125",
        "Length (bits)": "16",
        "Name": "CubeControl Vbat Current",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "Wheel1 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel1Current",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "Wheel2 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel2Current",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "Wheel3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Wheel3Current",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeStar Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "CubeStarCurrent",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "UINT",
        "Description": "Magnetorquer Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "Magnetorquer Current",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar MCU temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/100.0",
        "Length (bits)": "16",
        "Name": "CubeStar MCU temperature",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "MCU Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "MCU Temperature",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/10.0",
        "Length (bits)": "16",
        "Name": "Magnetometer Temperature",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/10.0",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Temperature",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "X-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "X-Rate Sensor Temperature",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "INT",
        "Description": "Y-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "Y-Rate Sensor Temperature",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "INT",
        "Description": "Z-Rate sensor Temperature. (Unit of measure is [C])",
        "Length (bits)": "16",
        "Name": "Z-Rate Sensor Temperature",
        "Offset (bits)": "288"
      }
    ],
    "Table": "Table 154: Power and Temperature Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Returns information about execution times of ACP functions",
      "Frame Length (bytes)": "8",
      "ID": "196"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Time to perform complete ADCS Update function. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Time to Perform ADCS Update",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Time to perform Sensor/actuator communications. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Time to Perform Sensor/Actuator Communications",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Time to execute SGP4 propagator. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Time to Execute SGP4 Propagator",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Time to execute IGRF computation. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Time to Execute IGRF Model",
        "Offset (bits)": "48"
      }
    ],
    "Table": "Table 155: Adcs Execution Times Telemetry Format"
  },
  {
    "Properties": {
      "Description": "CubeStar and Torquer current and temperature measurements",
      "Frame Length (bytes)": "6",
      "ID": "198"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "CubeStar Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "CubeStarCurrent",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Magnetorquer Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "Magnetorquer Current",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar MCU temperature. Formatted value is obtained using the formula: (formatted value) [C] = RAWVAL/100.0",
        "Length (bits)": "16",
        "Name": "CubeStar MCU temperature",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 156: ADCS Misc Current Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "High resolution estimated angular rates relative to orbit reference frame",
      "Frame Length (bytes)": "6",
      "ID": "201"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated X angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated X Angular Rate",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Y angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Y Angular Rate",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Z angular rate. Formatted value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Estimated Z Angular Rate",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 157: Fine Estimated Angular Rates Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw GPS measurements",
      "Frame Length (bytes)": "36",
      "ID": "210"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "GPS Solution Status. Possible values are in Table 85: GpsSolutionStatus Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gps Solution Status",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of tracked GPS satellites",
        "Length (bits)": "8",
        "Name": "Number of tracked GPS satellites",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of GPS satellites used in solution",
        "Length (bits)": "8",
        "Name": "Number of GPS satellites used in solution",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Counter for XYZ Lof from GPS",
        "Length (bits)": "8",
        "Name": "Counter for XYZ Lof from GPS",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "Counter for RANGE log from GPS",
        "Length (bits)": "8",
        "Name": "Counter for RANGE log from GPS",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Response Message for GPS log setup - p656 of OEMV615 reference manual",
        "Length (bits)": "8",
        "Name": "Response Message for GPS log setup",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS Reference Week",
        "Length (bits)": "16",
        "Name": "GPS Reference Week",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS Time Milliseconds. (Unit of measure is [ms])",
        "Length (bits)": "32",
        "Name": "GPS Time Milliseconds",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position X. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position X",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity X. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity X",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Y. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Y",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Y. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Y",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Z. (Unit of measure is [m])",
        "Length (bits)": "32",
        "Name": "ECEF Position Z",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Velocity Z. (Unit of measure is [m/s])",
        "Length (bits)": "16",
        "Name": "ECEF Velocity Z",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "UINT",
        "Description": "X-pos Standard Deviation. Formatted value is obtained using the formula: (formatted value) [m] = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "X-pos Standard Deviation",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "UINT",
        "Description": "Y-pos Standard Deviation. Formatted value is obtained using the formula: (formatted value) [m] = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Y-pos Standard Deviation",
        "Offset (bits)": "248"
      },
      {
        "Data Type": "UINT",
        "Description": "Z-pos Standard Deviation. Formatted value is obtained using the formula: (formatted value) [m] = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Z-pos Standard Deviation",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "UINT",
        "Description": "X-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "X-vel Standard Deviation",
        "Offset (bits)": "264"
      },
      {
        "Data Type": "UINT",
        "Description": "Y-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "Y-vel Standard Deviation",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "UINT",
        "Description": "Z-vel Standard Deviation. (Unit of measure is [m/s])",
        "Length (bits)": "8",
        "Name": "Z-vel Standard Deviation",
        "Offset (bits)": "280"
      }
    ],
    "Table": "Table 158: Raw GPS Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw Star Tracker Measurement",
      "Frame Length (bytes)": "54",
      "ID": "211"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Number of stars detected. (Unit of measure is [stars])",
        "Length (bits)": "8",
        "Name": "Number of stars detected",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Star image noise. (Unit of measure is [noise])",
        "Length (bits)": "8",
        "Name": "Star image noise",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of invalid stars detected. (Unit of measure is [Invalid stars])",
        "Length (bits)": "8",
        "Name": "Invalid Stars",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Number of stars identified. (Unit of measure is [stars])",
        "Length (bits)": "8",
        "Name": "Number of stars identified",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "ENUM",
        "Description": "Identification mode. Possible values are in Table 147: StarIDModeVal Enumeration Values",
        "Length (bits)": "8",
        "Name": "Identification mode",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "The average value of center line in image. (Unit of measure is [8-bit pixel value])",
        "Length (bits)": "8",
        "Name": "Image dark value",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "BOOL",
        "Description": "Image Capture Success",
        "Length (bits)": "1",
        "Name": "Image Capture Success",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detection Success",
        "Length (bits)": "1",
        "Name": "Detection Success",
        "Offset (bits)": "49"
      },
      {
        "Data Type": "BOOL",
        "Description": "Identification Success",
        "Length (bits)": "1",
        "Name": "Identification Success",
        "Offset (bits)": "50"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attitude Success",
        "Length (bits)": "1",
        "Name": "AttitudeSuccess",
        "Offset (bits)": "51"
      },
      {
        "Data Type": "BOOL",
        "Description": "Processing time Error",
        "Length (bits)": "1",
        "Name": "Processing Time Error",
        "Offset (bits)": "52"
      },
      {
        "Data Type": "BOOL",
        "Description": "Tracking Module Enabled",
        "Length (bits)": "1",
        "Name": "Tracking Module Enabled",
        "Offset (bits)": "53"
      },
      {
        "Data Type": "BOOL",
        "Description": "Prediction Enabled",
        "Length (bits)": "1",
        "Name": "Prediction Enabled",
        "Offset (bits)": "54"
      },
      {
        "Data Type": "BOOL",
        "Description": "Comms error",
        "Length (bits)": "1",
        "Name": "Comms error",
        "Offset (bits)": "55"
      },
      {
        "Data Type": "UINT",
        "Description": "Sample Period",
        "Length (bits)": "16",
        "Name": "Sample Period",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 1 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 1 confidence",
        "Offset (bits)": "72"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 2 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 2 confidence",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 3 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 3 confidence",
        "Offset (bits)": "88"
      },
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 1",
        "Length (bits)": "16",
        "Name": "Magnitude Star 1",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 2",
        "Length (bits)": "16",
        "Name": "Magnitude Star 2",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "Instrument magnitude of star 3",
        "Length (bits)": "16",
        "Name": "Magnitude Star 3",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 1",
        "Length (bits)": "16",
        "Name": "Catalogue Star 1",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 1",
        "Length (bits)": "16",
        "Name": "Centroid X Star 1",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 1",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 1",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 2",
        "Length (bits)": "16",
        "Name": "Catalogue Star 2",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 2",
        "Length (bits)": "16",
        "Name": "Centroid X Star 2",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 2",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 2",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 3",
        "Length (bits)": "16",
        "Name": "Catalogue Star 3",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 3",
        "Length (bits)": "16",
        "Name": "Centroid X Star 3",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 3",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 3",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "UINT",
        "Description": "Capture. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Capture",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "UINT",
        "Description": "Detection. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Detection",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "UINT",
        "Description": "Identification. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Identification",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar X-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "x-Axis rate",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar Y-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "y-Axis rate",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar Z-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "z-Axis rate",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q1. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q0",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q2. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q1",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q3. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q2",
        "Offset (bits)": "416"
      }
    ],
    "Table": "Table 159: Raw Star Tracker Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Catalogue index and detected coordinates for star 1",
      "Frame Length (bytes)": "6",
      "ID": "212"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 1",
        "Length (bits)": "16",
        "Name": "Catalogue Star 1",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 1",
        "Length (bits)": "16",
        "Name": "Centroid X Star 1",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 1",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 1",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 160: Star 1 Raw Data Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Catalogue index and detected coordinates for star 2",
      "Frame Length (bytes)": "6",
      "ID": "213"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 2",
        "Length (bits)": "16",
        "Name": "Catalogue Star 2",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 2",
        "Length (bits)": "16",
        "Name": "Centroid X Star 2",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 2",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 2",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 161: Star 2 Raw Data Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Catalogue index and detected coordinates for star 3",
      "Frame Length (bytes)": "6",
      "ID": "214"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Catalogue number of star 3",
        "Length (bits)": "16",
        "Name": "Catalogue Star 3",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "X centroid of star 3",
        "Length (bits)": "16",
        "Name": "Centroid X Star 3",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Y centroid of star 3",
        "Length (bits)": "16",
        "Name": "Centroid Y Star 3",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 162: Star 3 Raw Data Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Secondary Magnetometer raw measurements",
      "Frame Length (bytes)": "6",
      "ID": "215"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "MagZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 163: Secondary Magnetometer Raw Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Raw rate sensor measurements",
      "Frame Length (bytes)": "6",
      "ID": "216"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateX",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateY",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "sampled A/D value",
        "Length (bits)": "16",
        "Name": "RateZ",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 164: Raw Rate Sensor Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Estimated quaternion set",
      "Frame Length (bytes)": "6",
      "ID": "218"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated q1",
        "Length (bits)": "16",
        "Name": "Estimated q1",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated q2",
        "Length (bits)": "16",
        "Name": "Estimated q2",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated q3",
        "Length (bits)": "16",
        "Name": "Estimated q3",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 165: Estimated Quaternion Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Satellite position in ECEF coordinates",
      "Frame Length (bytes)": "6",
      "ID": "219"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "ECEF Position X. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position X",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Y. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position Y",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "ECEF Position Z. (Unit of measure is [m])",
        "Length (bits)": "16",
        "Name": "ECEF Position Z",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 166: ECEF Position Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Returns information about the ACP loop",
      "Frame Length (bytes)": "3",
      "ID": "220"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Time since the start of the current loop iteration. (Unit of measure is [ms])",
        "Length (bits)": "16",
        "Name": "Time Since Iteration Start",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Indicates which part of the loop is currently executing. Possible values are in Table 168: ExecutionWaypoints Enumeration Values",
        "Length (bits)": "8",
        "Name": "Current Execution Point",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 167: ACP Execution State Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Busy with initialization",
        "Name": "Init",
        "Numeric Value": "0"
      },
      {
        "Description": "Idle",
        "Name": "Idle",
        "Numeric Value": "1"
      },
      {
        "Description": "Sensor/Actuator Communications",
        "Name": "Sensor/Actuator Communications",
        "Numeric Value": "2"
      },
      {
        "Description": "ADCS Estimation & Control Update",
        "Name": "ADCS Update",
        "Numeric Value": "3"
      },
      {
        "Description": "Peripheral Power commands (over I2C)",
        "Name": "Peripheral Power commands (over I2C)",
        "Numeric Value": "4"
      },
      {
        "Description": "CPU Temperature Sampling",
        "Name": "CPU Temperature Sampling",
        "Numeric Value": "5"
      },
      {
        "Description": "Image Download",
        "Name": "Image Download",
        "Numeric Value": "6"
      },
      {
        "Description": "Image Compression",
        "Name": "Image Compression",
        "Numeric Value": "7"
      },
      {
        "Description": "Saving Image to SD Card",
        "Name": "Saving Image to SD Card",
        "Numeric Value": "8"
      },
      {
        "Description": "Logging",
        "Name": "Logging",
        "Numeric Value": "9"
      },
      {
        "Description": "Log File Compression",
        "Name": "Log File Compression",
        "Numeric Value": "10"
      },
      {
        "Description": "Saving Log to SD Card",
        "Name": "Saving Log to SD Card",
        "Numeric Value": "11"
      },
      {
        "Description": "Writing to flash memory",
        "Name": "Writing to flash",
        "Numeric Value": "12"
      }
    ],
    "Table": "Table 168: ExecutionWaypoints Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Current state of the Attitude Control Processor - frame 2",
      "Frame Length (bytes)": "6",
      "ID": "224"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Orbit Parameters are not in allowed bounds (angle exceeding limits etc.). Failed to initialize SGP4 propagator using supplied parameters",
        "Length (bits)": "1",
        "Name": "Orbit Parameters are Invalid",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetorquer Configuration or CSS in invalid. Each principle axis should have a torquer output (1,2, or 3) assigned. At least one CSS per principle axis needed",
        "Length (bits)": "1",
        "Name": "Configuration is Invalid",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attempt was made to select control mode without appropriate estimator, or command to set Y-momentum mode while not in steady-state Y-Thomson",
        "Length (bits)": "1",
        "Name": "Control Mode Change is not allowed",
        "Offset (bits)": "2"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attempt was made to change to an estimation mode that would be inappropriate for the current control mode",
        "Length (bits)": "1",
        "Name": "Estimator Change is not allowed",
        "Offset (bits)": "3"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current magnetometer sampling mode. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Current Magnetometer Sampling Mode",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "BOOL",
        "Description": "Modelled and measured magnetic field differs in size by more than 5000 nT",
        "Length (bits)": "1",
        "Name": "Modelled and measured magnetic field differs in size",
        "Offset (bits)": "6"
      },
      {
        "Data Type": "BOOL",
        "Description": "Failed to Recover an ADCS Node by successive resets",
        "Length (bits)": "1",
        "Name": "Node Recovery Error",
        "Offset (bits)": "7"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeSense1",
        "Length (bits)": "1",
        "Name": "CubeSense1 Runtime Error",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeSense2",
        "Length (bits)": "1",
        "Name": "CubeSense2 Runtime Error",
        "Offset (bits)": "9"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeControl Signal MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Signal Runtime Error",
        "Offset (bits)": "10"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeControl Motor MCU",
        "Length (bits)": "1",
        "Name": "CubeControl Motor Runtime Error",
        "Offset (bits)": "11"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel1",
        "Length (bits)": "1",
        "Name": "CubeWheel1 Runtime Error",
        "Offset (bits)": "12"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel2",
        "Length (bits)": "1",
        "Name": "CubeWheel2 Runtime Error",
        "Offset (bits)": "13"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeWheel3",
        "Length (bits)": "1",
        "Name": "CubeWheel3 Runtime Error",
        "Offset (bits)": "14"
      },
      {
        "Data Type": "BOOL",
        "Description": "Runtime error occurred with the CubeStar",
        "Length (bits)": "1",
        "Name": "CubeStar Runtime Error",
        "Offset (bits)": "15"
      },
      {
        "Data Type": "BOOL",
        "Description": "Magnetometer failure occurred",
        "Length (bits)": "1",
        "Name": "Magnetometer Error",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "BOOL",
        "Description": "Rate sensor failure occurred",
        "Length (bits)": "1",
        "Name": "Rate Sensor Failure",
        "Offset (bits)": "17"
      }
    ],
    "Table": "Table 169: Current ADCS State 2 Telemetry Format"
  },
  {
    "Properties": {
      "Description": "ASGP4 TLEs generated",
      "Frame Length (bytes)": "33",
      "ID": "228"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Is ASGP4 process complete",
        "Length (bits)": "1",
        "Name": "ASGP4 complete",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "The error state that the asgp4 module is in. Possible values are in Table 171: AsgpError Enumeration Values",
        "Length (bits)": "7",
        "Name": "ASGP4 error",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Epoch from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 Epoch",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Inclination from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 inclination",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RAAN from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 RAAN",
        "Offset (bits)": "72"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Eccentricity from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 ECC",
        "Offset (bits)": "104"
      },
      {
        "Data Type": "FLOAT",
        "Description": "AOP from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 AOP",
        "Offset (bits)": "136"
      },
      {
        "Data Type": "FLOAT",
        "Description": "MA from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 MA",
        "Offset (bits)": "168"
      },
      {
        "Data Type": "FLOAT",
        "Description": "MM from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 MM",
        "Offset (bits)": "200"
      },
      {
        "Data Type": "FLOAT",
        "Description": "BStar from asgp4",
        "Length (bits)": "32",
        "Name": "ASGP4 Bstar",
        "Offset (bits)": "232"
      }
    ],
    "Table": "Table 170: ASGP4 TLEs Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No error",
        "Name": "Off",
        "Numeric Value": "0"
      },
      {
        "Description": "Error due to time",
        "Name": "Unix Time",
        "Numeric Value": "1"
      },
      {
        "Description": "Error due to position error exceeding threshold",
        "Name": "Position",
        "Numeric Value": "2"
      },
      {
        "Description": "Error overflow",
        "Name": "Overflow",
        "Numeric Value": "3"
      }
    ],
    "Table": "Table 171: AsgpError Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Angular rates estimated by CubeStar",
      "Frame Length (bytes)": "6",
      "ID": "229"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar X-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "x-Axis rate",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar Y-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "y-Axis rate",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Estimated Rate around CubeStar Z-axis. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "z-Axis rate",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 172: CubeStar Estimated Rates Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Attitude quaternion estimated by CubeStar",
      "Frame Length (bytes)": "6",
      "ID": "230"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q1. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q0",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q2. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q1",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "CubeStar estimated attitude Q3. Formatted value is obtained using the formula: (formatted value) = RAWVAL/10000.0",
        "Length (bits)": "16",
        "Name": "Q2",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 173: CubeStar Estimated Quaternion Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Performance parameters of star measurement",
      "Frame Length (bytes)": "6",
      "ID": "231"
    },
    "Rows": [
      {
        "Data Type": "BOOL",
        "Description": "Image Capture Success",
        "Length (bits)": "1",
        "Name": "Image Capture Success",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "BOOL",
        "Description": "Detection Success",
        "Length (bits)": "1",
        "Name": "Detection Success",
        "Offset (bits)": "1"
      },
      {
        "Data Type": "BOOL",
        "Description": "Identification Success",
        "Length (bits)": "1",
        "Name": "Identification Success",
        "Offset (bits)": "2"
      },
      {
        "Data Type": "BOOL",
        "Description": "Attitude Success",
        "Length (bits)": "1",
        "Name": "AttitudeSuccess",
        "Offset (bits)": "3"
      },
      {
        "Data Type": "BOOL",
        "Description": "Processing time Error",
        "Length (bits)": "1",
        "Name": "Processing Time Error",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "BOOL",
        "Description": "Tracking Module Enabled",
        "Length (bits)": "1",
        "Name": "Tracking Module Enabled",
        "Offset (bits)": "5"
      },
      {
        "Data Type": "BOOL",
        "Description": "Prediction Enabled",
        "Length (bits)": "1",
        "Name": "Prediction Enabled",
        "Offset (bits)": "6"
      },
      {
        "Data Type": "BOOL",
        "Description": "Comms error",
        "Length (bits)": "1",
        "Name": "Comms error",
        "Offset (bits)": "7"
      },
      {
        "Data Type": "UINT",
        "Description": "Sample Period",
        "Length (bits)": "16",
        "Name": "Sample Period",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 1 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 1 confidence",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 2 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 2 confidence",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Star 3 confidence. (Unit of measure is [percentage])",
        "Length (bits)": "8",
        "Name": "Star 3 confidence",
        "Offset (bits)": "40"
      }
    ],
    "Table": "Table 174: Star Performance2 Telemetry Format"
  },
  {
    "Properties": {
      "Description": "CubeSense2 current measurements",
      "Frame Length (bytes)": "4",
      "ID": "232"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "CubeSense2 3V3 Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense2 3V3 Current",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense2 Cam SRAM Current. Formatted value is obtained using the formula: (formatted value) [mA] = RAWVAL*0.1",
        "Length (bits)": "16",
        "Name": "CubeSense2 Cam SRAM Current",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 175: CubeSense2 Current Measurements Telemetry Format"
  },
  {
    "Properties": {
      "Description": "Status of Image Capture and Save Operation",
      "Frame Length (bytes)": "2",
      "ID": "233"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Current progress of operation. (Unit of measure is [%])",
        "Length (bits)": "8",
        "Name": "Percentage Complete",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Current status of operation. Possible values are in Table 177: ImSaveStatus Enumeration Values",
        "Length (bits)": "8",
        "Name": "Status",
        "Offset (bits)": "8"
      }
    ],
    "Table": "Table 176: Status of Image Capture and Save Operation Telemetry Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No Error",
        "Name": "No Error",
        "Numeric Value": "0"
      },
      {
        "Description": "Timeout waiting for sensor to become available",
        "Name": "Timeout waiting for sensor to become available",
        "Numeric Value": "1"
      },
      {
        "Description": "Timeout waiting for next frame to become ready",
        "Name": "Timeout waiting for next frame to become ready",
        "Numeric Value": "2"
      },
      {
        "Description": "Checksum mismatch between downloaded frame and unit frame",
        "Name": "Checksum mismatch between downloaded frame and unit frame",
        "Numeric Value": "3"
      },
      {
        "Description": "Error writing to SD card",
        "Name": "Error writing to SD card",
        "Numeric Value": "4"
      }
    ],
    "Table": "Table 177: ImSaveStatus Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Set magnetorquer configuration parameters - Table 179: Set Magnetorquer Configuration Message Format",
        "Get ID": "136",
        "Length (bytes)": "3",
        "Name": "Set Magnetorquer Configuration",
        "Set ID": "21"
      },
      {
        "Description": "Set wheel configuration parameters - Table 181: Set Wheel Configuration Message Format",
        "Get ID": "137",
        "Length (bytes)": "4",
        "Name": "Set Wheel Configuration",
        "Set ID": "22"
      },
      {
        "Description": "Set rate gyro configuration parameters - Table 182: Set Rate Gyro Configuration Message Format",
        "Get ID": "138",
        "Length (bytes)": "10",
        "Name": "Set Rate Gyro Configuration",
        "Set ID": "23"
      },
      {
        "Description": "Photodiode pointing directions and scale factors - Table 183: CSS Configuration Message Format",
        "Get ID": "139",
        "Length (bytes)": "21",
        "Name": "CSS Configuration",
        "Set ID": "24"
      },
      {
        "Description": "Set configurations of CubeStar - Table 188: Set Star Tracker Configuration Message Format",
        "Get ID": "202",
        "Length (bytes)": "53",
        "Name": "Set Star Tracker Configuration",
        "Set ID": "37"
      },
      {
        "Description": "CubeSense configuration parameters - Table 189: CubeSense Configuration Message Format",
        "Get ID": "203",
        "Length (bytes)": "112",
        "Name": "CubeSense Configuration",
        "Set ID": "25"
      },
      {
        "Description": "Magnetometer configuration parameters - Table 190: Magnetometer Configuration Message Format",
        "Get ID": "204",
        "Length (bytes)": "30",
        "Name": "Magnetometer Configuration",
        "Set ID": "26"
      },
      {
        "Description": "Redundant magnetometer configuration parameters - Table 191: Redundant Magnetometer Configuration Message Format",
        "Get ID": "205",
        "Length (bytes)": "30",
        "Name": "Redundant Magnetometer Configuration",
        "Set ID": "36"
      },
      {
        "Description": "Current configuration - Table 192: ADCS Configuration Message Format",
        "Get ID": "206",
        "Length (bytes)": "504",
        "Name": "ADCS Configuration",
        "Set ID": "20"
      },
      {
        "Description": "SGP4 Orbit Parameters - Table 194: SGP4 Orbit Parameters Message Format",
        "Get ID": "207",
        "Length (bytes)": "64",
        "Name": "SGP4 Orbit Parameters",
        "Set ID": "45"
      },
      {
        "Description": "Set controller gains and reference values for Detumbling control mode - Table 195: Set Detumbling Control Parameters Message Format",
        "Get ID": "208",
        "Length (bytes)": "14",
        "Name": "Set Detumbling Control Parameters",
        "Set ID": "38"
      },
      {
        "Description": "Set controller gains and reference value for Y-wheel control mode - Table 196: Set Y-Wheel Control Parameters Message Format",
        "Get ID": "209",
        "Length (bytes)": "20",
        "Name": "Set Y-Wheel Control Parameters",
        "Set ID": "39"
      },
      {
        "Description": "Set controller gains and reference value for reaction wheel control mode - Table 197: Set Reaction Wheel Control Parameters Message Format",
        "Get ID": "217",
        "Length (bytes)": "13",
        "Name": "Set Reaction Wheel Control Parameters",
        "Set ID": "40"
      },
      {
        "Description": "Set controller gains for tracking control mode - Table 198: Set Tracking Controller Gain Parameters Message Format",
        "Get ID": "221",
        "Length (bytes)": "13",
        "Name": "Set Tracking Controller Gain Parameters",
        "Set ID": "54"
      },
      {
        "Description": "Satellite moment of inertia matrix - Table 199: Moment of Inertia Matrix Message Format",
        "Get ID": "222",
        "Length (bytes)": "24",
        "Name": "Moment of Inertia Matrix",
        "Set ID": "41"
      },
      {
        "Description": "Estimation noise covariance and sensor mask - Table 200: Estimation Parameters Message Format",
        "Get ID": "223",
        "Length (bytes)": "31",
        "Name": "Estimation Parameters",
        "Set ID": "27"
      },
      {
        "Description": "Current hard-coded system configuration - Table 201: ADCS System Configuration Message Format",
        "Get ID": "225",
        "Length (bytes)": "173",
        "Name": "ADCS System Configuration",
        "Set ID": "30"
      },
      {
        "Description": "Settings for user-coded estimation and control modes - Table 208: User-coded Controller and Estimator Parameters Message Format",
        "Get ID": "226",
        "Length (bytes)": "96",
        "Name": "User-coded Controller and Estimator Parameters",
        "Set ID": "29"
      },
      {
        "Description": "Settings for GPS augmented SGP4 - Table 209: Augmented-SGP4 Parameters Message Format",
        "Get ID": "227",
        "Length (bytes)": "30",
        "Name": "Augmented-SGP4 Parameters",
        "Set ID": "28"
      },
      {
        "Description": "Control power to selected components - Table 184: ADCS Power Control Message Format",
        "Get ID": "197",
        "Length (bytes)": "3",
        "Name": "ADCS Power Control",
        "Set ID": "11"
      },
      {
        "Description": "Commanded attitude angles - Table 186: Commanded Attitude Angles Message Format",
        "Get ID": "199",
        "Length (bytes)": "6",
        "Name": "Commanded Attitude Angles",
        "Set ID": "15"
      },
      {
        "Description": "Target reference for tracking control mode - Table 187: Tracking Controller Target Reference Message Format",
        "Get ID": "200",
        "Length (bytes)": "12",
        "Name": "Tracking Controller Target Reference",
        "Set ID": "55"
      },
      {
        "Description": "Log selection and period for LOG1 - Table 210: SD Log1 Configuration Message Format",
        "Get ID": "235",
        "Length (bytes)": "13",
        "Name": "SD Log1 Configuration",
        "Set ID": "104"
      },
      {
        "Description": "Log selection and period for LOG2 - Table 212: SD Log2 Configuration Message Format",
        "Get ID": "236",
        "Length (bytes)": "13",
        "Name": "SD Log2 Configuration",
        "Set ID": "105"
      },
      {
        "Description": "Log selection and period for UART (unsolicited TLM) - Table 213: UART Log Configuration Message Format",
        "Get ID": "237",
        "Length (bytes)": "12",
        "Name": "UART Log Configuration",
        "Set ID": "106"
      },
      {
        "Description": "Reference unit vector for inertial pointing control mode - Table 214: Inertial Pointing Reference Vector Message Format",
        "Get ID": "238",
        "Length (bytes)": "6",
        "Name": "Inertial Pointing Reference Vector",
        "Set ID": "34"
      }
    ],
    "Table": "Table 178: List of CubeAcp Configuration Messages"
  },
  {
    "Properties": {
      "Description": "Set magnetorquer configuration parameters",
      "Parameters Length (bytes)": "3",
      "Set ID/Get ID": "21/136"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 1 Configuration",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 2 Configuration",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 3 Configuration",
        "Offset (bits)": "16"
      }
    ],
    "Table": "Table 179: Set Magnetorquer Configuration Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Positive X",
        "Name": "Positive X",
        "Numeric Value": "0"
      },
      {
        "Description": "Negative X",
        "Name": "Negative X",
        "Numeric Value": "1"
      },
      {
        "Description": "Positive Y",
        "Name": "Positive Y",
        "Numeric Value": "2"
      },
      {
        "Description": "Negative Y",
        "Name": "Negative Y",
        "Numeric Value": "3"
      },
      {
        "Description": "Positive Z",
        "Name": "Positive Z",
        "Numeric Value": "4"
      },
      {
        "Description": "Negative Z",
        "Name": "Negative Z",
        "Numeric Value": "5"
      },
      {
        "Description": "Not Used",
        "Name": "Not Used",
        "Numeric Value": "6"
      }
    ],
    "Table": "Table 180: AxisSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Set wheel configuration parameters",
      "Parameters Length (bytes)": "4",
      "Set ID/Get ID": "22/137"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "RW1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW1 Configuration",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW2 Configuration",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW3 Configuration",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW4 or Momentum wheel Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW4 Configuration",
        "Offset (bits)": "24"
      }
    ],
    "Table": "Table 181: Set Wheel Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Set rate gyro configuration parameters",
      "Parameters Length (bytes)": "10",
      "Set ID/Get ID": "23/138"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Gyro1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro1 Configuration",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Gyro2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro2 Configuration",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Gyro3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro3 Configuration",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "X-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "X-Rate Sensor Offset",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "INT",
        "Description": "Y-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Y-Rate Sensor Offset",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "INT",
        "Description": "Z-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Z-Rate Sensor Offset",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "UINT",
        "Description": "Multiplier of rate sensor measurement",
        "Length (bits)": "8",
        "Name": "RateSensorMult",
        "Offset (bits)": "72"
      }
    ],
    "Table": "Table 182: Set Rate Gyro Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Photodiode pointing directions and scale factors",
      "Parameters Length (bytes)": "21",
      "Set ID/Get ID": "24/139"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "CSS1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS1 Configuration",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS2 Configuration",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS3 Configuration",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS4 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS4 Configuration",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS5 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS5 Configuration",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS6 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS6 Configuration",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS7 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS7 Configuration",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS8 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS8 Configuration",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS9 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS9 Configuration",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS10 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS10 Configuration",
        "Offset (bits)": "72"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS1 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS1 Relative Scale",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS2 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS2 Relative Scale",
        "Offset (bits)": "88"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS3 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS3 Relative Scale",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS4 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS4 Relative Scale",
        "Offset (bits)": "104"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS5 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS5 Relative Scale",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS6 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS6 Relative Scale",
        "Offset (bits)": "120"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS7 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS7 Relative Scale",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS8 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS8 Relative Scale",
        "Offset (bits)": "136"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS9 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS9 Relative Scale",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS10 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS10 Relative Scale",
        "Offset (bits)": "152"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS Threshold",
        "Length (bits)": "8",
        "Name": "CSS Threshold",
        "Offset (bits)": "160"
      }
    ],
    "Table": "Table 183: CSS Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Control power to selected components",
      "Parameters Length (bytes)": "3",
      "Set ID/Get ID": "11/197"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Control power to electronics of CubeControl Signal PIC. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeControl Signal Power Selection",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to electronics of CubeControl Motor PIC. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeControl Motor Power Selection",
        "Offset (bits)": "2"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeSense1. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeSense1 Power Selection",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeSense2. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeSense2 Power Selection",
        "Offset (bits)": "6"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeStar. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeStarPower Power Selection",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeWheel1. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeWheel1Power Power Selection",
        "Offset (bits)": "10"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeWheel2. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeWheel2Power Power Selection",
        "Offset (bits)": "12"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to the CubeWheel3. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "CubeWheel3Power Power Selection",
        "Offset (bits)": "14"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to Motor electronics. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "Motor Power",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "Control power to GPS LNA. Possible values are in Table 185: PowerSelect Enumeration Values",
        "Length (bits)": "2",
        "Name": "GPS Power",
        "Offset (bits)": "18"
      }
    ],
    "Table": "Table 184: ADCS Power Control Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Off",
        "Name": "Off",
        "Numeric Value": "0"
      },
      {
        "Description": "On",
        "Name": "On",
        "Numeric Value": "1"
      },
      {
        "Description": "Power state kept the same",
        "Name": "Power state kept the same",
        "Numeric Value": "2"
      }
    ],
    "Table": "Table 185: PowerSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Commanded attitude angles",
      "Parameters Length (bytes)": "6",
      "Set ID/Get ID": "15/199"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Commanded roll angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Commanded Roll Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded pitch angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Commanded Pitch Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Commanded yaw angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Commanded Yaw Angle",
        "Offset (bits)": "32"
      }
    ],
    "Table": "Table 186: Commanded Attitude Angles Message Format"
  },
  {
    "Properties": {
      "Description": "Target reference for tracking control mode",
      "Parameters Length (bytes)": "12",
      "Set ID/Get ID": "55/200"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Geocentric longitude of target. (Unit of measure is [deg])",
        "Length (bits)": "32",
        "Name": "Geocentric longitude of target",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Geocentric latitude of target. (Unit of measure is [deg])",
        "Length (bits)": "32",
        "Name": "Geocentric latitude of target",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Geocentric altitude of target. (Unit of measure is [meter])",
        "Length (bits)": "32",
        "Name": "Geocentric altitude of target",
        "Offset (bits)": "64"
      }
    ],
    "Table": "Table 187: Tracking Controller Target Reference Message Format"
  },
  {
    "Properties": {
      "Description": "Set configurations of CubeStar",
      "Parameters Length (bytes)": "53",
      "Set ID/Get ID": "37/202"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Alpha Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Beta Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Gamma Angle",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "StarTracker exposure time",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "analog gain register value",
        "Length (bits)": "16",
        "Name": "StarTracker analog gain",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "UINT",
        "Description": "StarTracker detection threshold",
        "Length (bits)": "8",
        "Name": "StarTracker detection threshold",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "StarTracker star threshold",
        "Length (bits)": "8",
        "Name": "StarTracker star threshold",
        "Offset (bits)": "88"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum of stars that the star tracker will match",
        "Length (bits)": "8",
        "Name": "Maximum Star Matched",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "UINT",
        "Description": "Time allowed for detection",
        "Length (bits)": "16",
        "Name": "Detection Timeout duration",
        "Offset (bits)": "104"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum pixels in a star",
        "Length (bits)": "8",
        "Name": "Maximum Star Pixel",
        "Offset (bits)": "120"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum pixels in a star",
        "Length (bits)": "8",
        "Name": "Minimum Star Pixel",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "UINT",
        "Description": "% Error margin of the star identification. Raw parameter value is obtained using the formula: (formatted value) [%] = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Star Tracker Error Margin",
        "Offset (bits)": "136"
      },
      {
        "Data Type": "UINT",
        "Description": "Delay Time. (Unit of measure is [milliseconds])",
        "Length (bits)": "16",
        "Name": "Star Tracker Delay Time",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Pixel centroid X",
        "Length (bits)": "32",
        "Name": "Star Tracker Centroid X",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Pixel centroid Y",
        "Length (bits)": "32",
        "Name": "Star Tracker Centroid Y",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Star Tracker Focal Length. (Unit of measure is [mm])",
        "Length (bits)": "32",
        "Name": "Star Tracker Focal Length",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "FLOAT",
        "Description": "First radial distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "K1 radial distortion coefficient",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Second radial distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "K2 radial distortion coefficient",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "FLOAT",
        "Description": "First tangential distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "P1 tangential distortion coefficient",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Second tangential distortion coefficients. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "P2 tangential distortion coefficient",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "UINT",
        "Description": "Window width",
        "Length (bits)": "8",
        "Name": "Star tracking window width",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "UINT",
        "Description": "Tracking Margin. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/100.0",
        "Length (bits)": "8",
        "Name": "Star Tracking Margin",
        "Offset (bits)": "392"
      },
      {
        "Data Type": "UINT",
        "Description": "Validation Margin. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/100.0",
        "Length (bits)": "8",
        "Name": "Star Validation Margin",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "BOOL",
        "Description": "Module Enable",
        "Length (bits)": "1",
        "Name": "Star Tracking Module Enable",
        "Offset (bits)": "408"
      },
      {
        "Data Type": "BOOL",
        "Description": "LocationPredictionEnable",
        "Length (bits)": "1",
        "Name": "Star Tracking Location Prediction Enable",
        "Offset (bits)": "409"
      },
      {
        "Data Type": "UINT",
        "Description": "Search Width. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/5.0",
        "Length (bits)": "8",
        "Name": "Star Tracking Search Width",
        "Offset (bits)": "416"
      }
    ],
    "Table": "Table 188: Set Star Tracker Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "CubeSense configuration parameters",
      "Parameters Length (bytes)": "112",
      "Set ID/Get ID": "25/203"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Alpha Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Beta Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Gamma Angle",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "",
        "Length (bits)": "8",
        "Name": "Cam1 detection threshold",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "BOOL",
        "Description": "0 = disabled and 1 = enabled",
        "Length (bits)": "1",
        "Name": "Cam1 sensor auto adjust mode",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "Cam1 sensor exposure time",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "UINT",
        "Description": "X Pixel location of Cam1 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Boresight X",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "Y Pixel location of Cam1 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Boresight Y",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Alpha Angle",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Beta Angle",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Gamma Angle",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam2 detection threshold",
        "Length (bits)": "8",
        "Name": "Cam2 detection threshold",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "BOOL",
        "Description": "0 = disabled and 1 = enabled",
        "Length (bits)": "1",
        "Name": "Cam2 sensor auto adjust mode",
        "Offset (bits)": "168"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "Cam2 sensor exposure time",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "UINT",
        "Description": "X Pixel location of Cam2 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Boresight X",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "UINT",
        "Description": "Y Pixel location of Cam2 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Boresight Y",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "UINT",
        "Description": "Percentage of measured angular radius as edge's maximum allowable deviation",
        "Length (bits)": "8",
        "Name": "Nadir Max Deviation Percentage",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum amount of edges allowed outside maximum deviation (>50 to disable)",
        "Length (bits)": "8",
        "Name": "Nadir Max Bad Edges",
        "Offset (bits)": "232"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum Radius. (Unit of measure is [°])",
        "Length (bits)": "8",
        "Name": "Nadir Max Radius",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum Radius. (Unit of measure is [°])",
        "Length (bits)": "8",
        "Name": "Nadir Min Radius",
        "Offset (bits)": "248"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 1",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 1",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 1",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 1",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 2",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 2",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 2",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 2",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 3",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 3",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 3",
        "Offset (bits)": "416"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 3",
        "Offset (bits)": "432"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 4",
        "Offset (bits)": "448"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 4",
        "Offset (bits)": "464"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 4",
        "Offset (bits)": "480"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 4",
        "Offset (bits)": "496"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 5",
        "Offset (bits)": "512"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 5",
        "Offset (bits)": "528"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 5",
        "Offset (bits)": "544"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 5",
        "Offset (bits)": "560"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 1",
        "Offset (bits)": "576"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 1",
        "Offset (bits)": "592"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 1",
        "Offset (bits)": "608"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 1",
        "Offset (bits)": "624"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 2",
        "Offset (bits)": "640"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 2",
        "Offset (bits)": "656"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 2",
        "Offset (bits)": "672"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 2",
        "Offset (bits)": "688"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 3",
        "Offset (bits)": "704"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 3",
        "Offset (bits)": "720"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 3",
        "Offset (bits)": "736"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 3",
        "Offset (bits)": "752"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 4",
        "Offset (bits)": "768"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 4",
        "Offset (bits)": "784"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 4",
        "Offset (bits)": "800"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 4",
        "Offset (bits)": "816"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 5",
        "Offset (bits)": "832"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 5",
        "Offset (bits)": "848"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 5",
        "Offset (bits)": "864"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 5",
        "Offset (bits)": "880"
      }
    ],
    "Table": "Table 189: CubeSense Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Magnetometer configuration parameters",
      "Parameters Length (bytes)": "30",
      "Set ID/Get ID": "26/204"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Alpha Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Beta Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Gamma Angle",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 1 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 1 Offset",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 2 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 2 Offset",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 3 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 3 Offset",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S11. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S11",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S22. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S22",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S33. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S33",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S12. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S12",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S13. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S13",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S21. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S21",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S23. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S23",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S31. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S31",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S32. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S32",
        "Offset (bits)": "224"
      }
    ],
    "Table": "Table 190: Magnetometer Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Redundant magnetometer configuration parameters",
      "Parameters Length (bytes)": "30",
      "Set ID/Get ID": "36/205"
    },
    "Rows": [
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Alpha Angle",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Beta Angle",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Gamma Angle",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 1 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 1 Offset",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 2 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 2 Offset",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 3 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 3 Offset",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S11. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S11",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S22. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S22",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S33. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S33",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S12. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S12",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S13. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S13",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S21. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S21",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S23. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S23",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S31. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S31",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S32. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S32",
        "Offset (bits)": "224"
      }
    ],
    "Table": "Table 191: Redundant Magnetometer Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Current configuration",
      "Parameters Length (bytes)": "504",
      "Set ID/Get ID": "20/206"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 1 Configuration",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 2 Configuration",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "ENUM",
        "Description": "Magnetorquer 3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Magnetorquer 3 Configuration",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW1 Configuration",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW2 Configuration",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW3 Configuration",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "ENUM",
        "Description": "RW4 or Momentum wheel Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "RW4 Configuration",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "ENUM",
        "Description": "Gyro1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro1 Configuration",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "ENUM",
        "Description": "Gyro2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro2 Configuration",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "ENUM",
        "Description": "Gyro3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Gyro3 Configuration",
        "Offset (bits)": "72"
      },
      {
        "Data Type": "INT",
        "Description": "X-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "X-Rate Sensor Offset",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "INT",
        "Description": "Y-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Y-Rate Sensor Offset",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "INT",
        "Description": "Z-Rate Sensor Offset. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Z-Rate Sensor Offset",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "UINT",
        "Description": "Multiplier of rate sensor measurement",
        "Length (bits)": "8",
        "Name": "RateSensorMult",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS1 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS1 Configuration",
        "Offset (bits)": "136"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS2 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS2 Configuration",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS3 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS3 Configuration",
        "Offset (bits)": "152"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS4 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS4 Configuration",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS5 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS5 Configuration",
        "Offset (bits)": "168"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS6 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS6 Configuration",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS7 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS7 Configuration",
        "Offset (bits)": "184"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS8 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS8 Configuration",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS9 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS9 Configuration",
        "Offset (bits)": "200"
      },
      {
        "Data Type": "ENUM",
        "Description": "CSS10 Configuration. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "CSS10 Configuration",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS1 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS1 Relative Scale",
        "Offset (bits)": "216"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS2 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS2 Relative Scale",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS3 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS3 Relative Scale",
        "Offset (bits)": "232"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS4 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS4 Relative Scale",
        "Offset (bits)": "240"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS5 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS5 Relative Scale",
        "Offset (bits)": "248"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS6 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS6 Relative Scale",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS7 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS7 Relative Scale",
        "Offset (bits)": "264"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS8 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS8 Relative Scale",
        "Offset (bits)": "272"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS9 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS9 Relative Scale",
        "Offset (bits)": "280"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS10 Relative Scaling Factor. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "CSS10 Relative Scale",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "UINT",
        "Description": "CSS Threshold",
        "Length (bits)": "8",
        "Name": "CSS Threshold",
        "Offset (bits)": "296"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Alpha Angle",
        "Offset (bits)": "304"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Beta Angle",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "INT",
        "Description": "Cam1 Sensor Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Sensor Mounting Transform Gamma Angle",
        "Offset (bits)": "336"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam1 detection threshold",
        "Length (bits)": "8",
        "Name": "Cam1 detection threshold",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "BOOL",
        "Description": "0 = disabled and 1 = enabled",
        "Length (bits)": "1",
        "Name": "Cam1 sensor auto adjust mode",
        "Offset (bits)": "360"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "Cam1 sensor exposure time",
        "Offset (bits)": "368"
      },
      {
        "Data Type": "UINT",
        "Description": "X Pixel location of Cam1 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Boresight X",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "UINT",
        "Description": "Y Pixel location of Cam1 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam1 Boresight Y",
        "Offset (bits)": "400"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Alpha Angle",
        "Offset (bits)": "416"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Beta Angle",
        "Offset (bits)": "432"
      },
      {
        "Data Type": "INT",
        "Description": "Cam2 Sensor Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Sensor Mounting Transform Gamma Angle",
        "Offset (bits)": "448"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam2 detection threshold",
        "Length (bits)": "8",
        "Name": "Cam2 detection threshold",
        "Offset (bits)": "464"
      },
      {
        "Data Type": "BOOL",
        "Description": "0 = disabled and 1 = enabled",
        "Length (bits)": "1",
        "Name": "Cam2 sensor auto adjust mode",
        "Offset (bits)": "472"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "Cam2 sensor exposure time",
        "Offset (bits)": "480"
      },
      {
        "Data Type": "UINT",
        "Description": "X Pixel location of Cam2 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Boresight X",
        "Offset (bits)": "496"
      },
      {
        "Data Type": "UINT",
        "Description": "Y Pixel location of Cam2 boresight. Raw parameter value is obtained using the formula: (formatted value) [pixels] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Cam2 Boresight Y",
        "Offset (bits)": "512"
      },
      {
        "Data Type": "UINT",
        "Description": "Percentage of measured angular radius as edge's maximum allowable deviation",
        "Length (bits)": "8",
        "Name": "Nadir Max Deviation Percentage",
        "Offset (bits)": "528"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum amount of edges allowed outside maximum deviation (>50 to disable)",
        "Length (bits)": "8",
        "Name": "Nadir Max Bad Edges",
        "Offset (bits)": "536"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum Radius. (Unit of measure is [°])",
        "Length (bits)": "8",
        "Name": "Nadir Max Radius",
        "Offset (bits)": "544"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum Radius. (Unit of measure is [°])",
        "Length (bits)": "8",
        "Name": "Nadir Min Radius",
        "Offset (bits)": "552"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 1",
        "Offset (bits)": "560"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 1",
        "Offset (bits)": "576"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 1",
        "Offset (bits)": "592"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 1",
        "Offset (bits)": "608"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 2",
        "Offset (bits)": "624"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 2",
        "Offset (bits)": "640"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 2",
        "Offset (bits)": "656"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 2",
        "Offset (bits)": "672"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 3",
        "Offset (bits)": "688"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 3",
        "Offset (bits)": "704"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 3",
        "Offset (bits)": "720"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 3",
        "Offset (bits)": "736"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 4",
        "Offset (bits)": "752"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 4",
        "Offset (bits)": "768"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 4",
        "Offset (bits)": "784"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 4",
        "Offset (bits)": "800"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum X of area 5",
        "Offset (bits)": "816"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum X of area 5",
        "Offset (bits)": "832"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Minimum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Minimum Y of area 5",
        "Offset (bits)": "848"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 1 Maximum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 1 Maximum Y of area 5",
        "Offset (bits)": "864"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 1",
        "Offset (bits)": "880"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 1",
        "Offset (bits)": "896"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 1",
        "Offset (bits)": "912"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 1",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 1",
        "Offset (bits)": "928"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 2",
        "Offset (bits)": "944"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 2",
        "Offset (bits)": "960"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 2",
        "Offset (bits)": "976"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 2",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 2",
        "Offset (bits)": "992"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 3",
        "Offset (bits)": "1008"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 3",
        "Offset (bits)": "1024"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 3",
        "Offset (bits)": "1040"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 3",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 3",
        "Offset (bits)": "1056"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 4",
        "Offset (bits)": "1072"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 4",
        "Offset (bits)": "1088"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 4",
        "Offset (bits)": "1104"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 4",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 4",
        "Offset (bits)": "1120"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum X of area 5",
        "Offset (bits)": "1136"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum X of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum X of area 5",
        "Offset (bits)": "1152"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Minimum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Minimum Y of area 5",
        "Offset (bits)": "1168"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam 2 Maximum Y of Area 5",
        "Length (bits)": "16",
        "Name": "Cam 2 Maximum Y of area 5",
        "Offset (bits)": "1184"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Alpha Angle",
        "Offset (bits)": "1200"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Beta Angle",
        "Offset (bits)": "1216"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Magnetometer Mounting Transform Gamma Angle",
        "Offset (bits)": "1232"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 1 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 1 Offset",
        "Offset (bits)": "1248"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 2 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 2 Offset",
        "Offset (bits)": "1264"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Channel 3 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Channel 3 Offset",
        "Offset (bits)": "1280"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S11. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S11",
        "Offset (bits)": "1296"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S22. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S22",
        "Offset (bits)": "1312"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S33. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S33",
        "Offset (bits)": "1328"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S12. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S12",
        "Offset (bits)": "1344"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S13. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S13",
        "Offset (bits)": "1360"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S21. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S21",
        "Offset (bits)": "1376"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S23. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S23",
        "Offset (bits)": "1392"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S31. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S31",
        "Offset (bits)": "1408"
      },
      {
        "Data Type": "INT",
        "Description": "Magnetometer Sensitivity Matrix S32. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Magnetometer Sensitivity Matrix S32",
        "Offset (bits)": "1424"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Alpha Angle",
        "Offset (bits)": "1440"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Beta Angle",
        "Offset (bits)": "1456"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Mounting Transform Gamma Angle",
        "Offset (bits)": "1472"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 1 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 1 Offset",
        "Offset (bits)": "1488"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 2 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 2 Offset",
        "Offset (bits)": "1504"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Channel 3 Offset. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Channel 3 Offset",
        "Offset (bits)": "1520"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S11. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S11",
        "Offset (bits)": "1536"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S22. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S22",
        "Offset (bits)": "1552"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S33. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S33",
        "Offset (bits)": "1568"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S12. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S12",
        "Offset (bits)": "1584"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S13. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S13",
        "Offset (bits)": "1600"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S21. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S21",
        "Offset (bits)": "1616"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S23. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S23",
        "Offset (bits)": "1632"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S31. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S31",
        "Offset (bits)": "1648"
      },
      {
        "Data Type": "INT",
        "Description": "Redundant Magnetometer Sensitivity Matrix S32. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Redundant Magnetometer Sensitivity Matrix S32",
        "Offset (bits)": "1664"
      },
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Alpha Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Alpha Angle",
        "Offset (bits)": "1680"
      },
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Beta Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Beta Angle",
        "Offset (bits)": "1696"
      },
      {
        "Data Type": "INT",
        "Description": "StarTracker Mounting Transform Gamma Angle. Raw parameter value is obtained using the formula: (formatted value) [deg] = RAWVAL*0.01",
        "Length (bits)": "16",
        "Name": "StarTracker Mounting Transform Gamma Angle",
        "Offset (bits)": "1712"
      },
      {
        "Data Type": "UINT",
        "Description": "exposure time register value",
        "Length (bits)": "16",
        "Name": "StarTracker exposure time",
        "Offset (bits)": "1728"
      },
      {
        "Data Type": "UINT",
        "Description": "analog gain register value",
        "Length (bits)": "16",
        "Name": "StarTracker analog gain",
        "Offset (bits)": "1744"
      },
      {
        "Data Type": "UINT",
        "Description": "StarTracker detection threshold",
        "Length (bits)": "8",
        "Name": "StarTracker detection threshold",
        "Offset (bits)": "1760"
      },
      {
        "Data Type": "UINT",
        "Description": "StarTracker star threshold",
        "Length (bits)": "8",
        "Name": "StarTracker star threshold",
        "Offset (bits)": "1768"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum of stars that the star tracker will match",
        "Length (bits)": "8",
        "Name": "Maximum Star Matched",
        "Offset (bits)": "1776"
      },
      {
        "Data Type": "UINT",
        "Description": "Time allowed for detection",
        "Length (bits)": "16",
        "Name": "Detection Timeout duration",
        "Offset (bits)": "1784"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum pixels in a star",
        "Length (bits)": "8",
        "Name": "Maximum Star Pixel",
        "Offset (bits)": "1800"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum pixels in a star",
        "Length (bits)": "8",
        "Name": "Minimum Star Pixel",
        "Offset (bits)": "1808"
      },
      {
        "Data Type": "UINT",
        "Description": "% Error margin of the star identification. Raw parameter value is obtained using the formula: (formatted value) [%] = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Star Tracker Error Margin",
        "Offset (bits)": "1816"
      },
      {
        "Data Type": "UINT",
        "Description": "Delay Time. (Unit of measure is [milliseconds])",
        "Length (bits)": "16",
        "Name": "Star Tracker Delay Time",
        "Offset (bits)": "1824"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Pixel centroid X",
        "Length (bits)": "32",
        "Name": "Star Tracker Centroid X",
        "Offset (bits)": "1840"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Pixel centroid Y",
        "Length (bits)": "32",
        "Name": "Star Tracker Centroid Y",
        "Offset (bits)": "1872"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Star Tracker Focal Length. (Unit of measure is [mm])",
        "Length (bits)": "32",
        "Name": "Star Tracker Focal Length",
        "Offset (bits)": "1904"
      },
      {
        "Data Type": "FLOAT",
        "Description": "First radial distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "K1 radial distortion coefficient",
        "Offset (bits)": "1936"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Second radial distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "K2 radial distortion coefficient",
        "Offset (bits)": "1968"
      },
      {
        "Data Type": "FLOAT",
        "Description": "First tangential distortion coefficient. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "P1 tangential distortion coefficient",
        "Offset (bits)": "2000"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Second tangential distortion coefficients. (Unit of measure is [gain])",
        "Length (bits)": "32",
        "Name": "P2 tangential distortion coefficient",
        "Offset (bits)": "2032"
      },
      {
        "Data Type": "UINT",
        "Description": "Window width",
        "Length (bits)": "8",
        "Name": "Star tracking window width",
        "Offset (bits)": "2064"
      },
      {
        "Data Type": "UINT",
        "Description": "Tracking Margin. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/100.0",
        "Length (bits)": "8",
        "Name": "Star Tracking Margin",
        "Offset (bits)": "2072"
      },
      {
        "Data Type": "UINT",
        "Description": "Validation Margin. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/100.0",
        "Length (bits)": "8",
        "Name": "Star Validation Margin",
        "Offset (bits)": "2080"
      },
      {
        "Data Type": "BOOL",
        "Description": "Module Enable",
        "Length (bits)": "1",
        "Name": "Star Tracking Module Enable",
        "Offset (bits)": "2088"
      },
      {
        "Data Type": "BOOL",
        "Description": "LocationPredictionEnable",
        "Length (bits)": "1",
        "Name": "Star Tracking Location Prediction Enable",
        "Offset (bits)": "2089"
      },
      {
        "Data Type": "UINT",
        "Description": "Search Width. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL/5.0",
        "Length (bits)": "8",
        "Name": "Star Tracking Search Width",
        "Offset (bits)": "2096"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Detumbling Spin Gain (Ks)",
        "Length (bits)": "32",
        "Name": "Detumbling Spin Gain",
        "Offset (bits)": "2104"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Detumbling Damping Gain (Kd)",
        "Length (bits)": "32",
        "Name": "Detumbling Damping Gain",
        "Offset (bits)": "2136"
      },
      {
        "Data Type": "INT",
        "Description": "Reference spin rate (wy-ref). Must always be smaller than 0. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Reference spin rate",
        "Offset (bits)": "2168"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Fast BDot Detumbling Gain (Kdf)",
        "Length (bits)": "32",
        "Name": "Fast BDot Detumbling Gain",
        "Offset (bits)": "2184"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-Momentum Control Gain (Kh)",
        "Length (bits)": "32",
        "Name": "Y-Momentum Control Gain",
        "Offset (bits)": "2216"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Nutation Damping Gain (Kn)",
        "Length (bits)": "32",
        "Name": "Y-momentum Nutation Damping Gain",
        "Offset (bits)": "2248"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Proportional Gain (Kp1)",
        "Length (bits)": "32",
        "Name": "Y-momentum Proportional Gain",
        "Offset (bits)": "2280"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Derivative Gain (Kd1)",
        "Length (bits)": "32",
        "Name": "Y-momentum Derivative Gain",
        "Offset (bits)": "2312"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Reference Wheel Momentum (H-ref). Must always be smaller than 0. (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "Reference Wheel Momentum",
        "Offset (bits)": "2344"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RWheel Proportional Gain (Kp2)",
        "Length (bits)": "32",
        "Name": "RWheel Proportional Gain",
        "Offset (bits)": "2376"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RWheel Derivative Gain (Kd2)",
        "Length (bits)": "32",
        "Name": "RWheel Derivative Gain",
        "Offset (bits)": "2408"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-Wheel Bias Momentum (H-bias). (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "Y-Wheel Bias Momentum",
        "Offset (bits)": "2440"
      },
      {
        "Data Type": "ENUM",
        "Description": "Satellite body axis that will align with sun vector. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "7",
        "Name": "Sun-pointing Facet",
        "Offset (bits)": "2472"
      },
      {
        "Data Type": "BOOL",
        "Description": "Enable/disable automatic transition from wheel control modes to Y-Thomson mode in case of wheel error",
        "Length (bits)": "1",
        "Name": "Automatic Control Transition due to Wheel Errors",
        "Offset (bits)": "2479"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Proportional Gain (Kp3)",
        "Length (bits)": "32",
        "Name": "Tracking Proportional Gain",
        "Offset (bits)": "2480"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Derivative Gain (Kd3)",
        "Length (bits)": "32",
        "Name": "Tracking Derivative Gain",
        "Offset (bits)": "2512"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Integral Gain (Ki3)",
        "Length (bits)": "32",
        "Name": "Tracking Integral Gain",
        "Offset (bits)": "2544"
      },
      {
        "Data Type": "ENUM",
        "Description": "Satellite body axis that will point to target. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Target-tracking Facet",
        "Offset (bits)": "2576"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Ixx. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Ixx",
        "Offset (bits)": "2584"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Iyy. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Iyy",
        "Offset (bits)": "2616"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Izz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Izz",
        "Offset (bits)": "2648"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Ixy. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Ixy",
        "Offset (bits)": "2680"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Ixz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Ixz",
        "Offset (bits)": "2712"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Iyz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Iyz",
        "Offset (bits)": "2744"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetometer Rate Filter System Noise",
        "Length (bits)": "32",
        "Name": "Magnetometer Rate Filter System Noise",
        "Offset (bits)": "2776"
      },
      {
        "Data Type": "FLOAT",
        "Description": "EKF System Noise",
        "Length (bits)": "32",
        "Name": "EKF System Noise",
        "Offset (bits)": "2808"
      },
      {
        "Data Type": "FLOAT",
        "Description": "CSS Measurement Noise",
        "Length (bits)": "32",
        "Name": "CSS Measurement Noise",
        "Offset (bits)": "2840"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Sun Sensor Measurement Noise",
        "Length (bits)": "32",
        "Name": "Sun Sensor Measurement Noise",
        "Offset (bits)": "2872"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Nadir Sensor Measurement Noise",
        "Length (bits)": "32",
        "Name": "Nadir Sensor Measurement Noise",
        "Offset (bits)": "2904"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetometer Measurement Noise",
        "Length (bits)": "32",
        "Name": "Magnetometer Measurement Noise",
        "Offset (bits)": "2936"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Star Tracker Measurement Noise",
        "Length (bits)": "32",
        "Name": "Star Tracker Measurement Noise",
        "Offset (bits)": "2968"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Sun Sensor measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Sun Sensor",
        "Offset (bits)": "3000"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Nadir Sensor measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Nadir Sensor",
        "Offset (bits)": "3001"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use CSS measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use CSS",
        "Offset (bits)": "3002"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Star Tracker measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Star Tracker",
        "Offset (bits)": "3003"
      },
      {
        "Data Type": "BOOL",
        "Description": "Select to ignore Nadir sensor measurements when terminator is in FOV",
        "Length (bits)": "1",
        "Name": "Nadir sensor terminator test",
        "Offset (bits)": "3004"
      },
      {
        "Data Type": "BOOL",
        "Description": "Select whether automatic switch to redundant magnetometer should occur in case of failure",
        "Length (bits)": "1",
        "Name": "Automatic Magnetometer Recovery",
        "Offset (bits)": "3005"
      },
      {
        "Data Type": "ENUM",
        "Description": "Mode describing which magnetometer is used for estimation and control. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Magnetometer Mode",
        "Offset (bits)": "3006"
      },
      {
        "Data Type": "ENUM",
        "Description": "Select which magnetometer and sampling to use for 2nd raw magnetometer tlm frame. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Magnetometer Selection for RAW MTM TLM",
        "Offset (bits)": "3008"
      },
      {
        "Data Type": "BOOL",
        "Description": "Enable/disable automatic transition from MEMS rate estimation mode to RKF in case of rate sensor error",
        "Length (bits)": "1",
        "Name": "Automatic Estimation Transition due to Rate Sensor Errors",
        "Offset (bits)": "3010"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam1 and Cam2 sensor sampling period. Lower four bits are Cam1 period and upper four bits the Cam2 period. Setting period to zero for sensor will disable sampling of sensor. (Unit of measure is [s])",
        "Length (bits)": "8",
        "Name": "Cam1 and Cam2 Sampling Period",
        "Offset (bits)": "3016"
      },
      {
        "Data Type": "UINT",
        "Description": "Inclination filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Incl. coefficient",
        "Offset (bits)": "3024"
      },
      {
        "Data Type": "UINT",
        "Description": "RAAN filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Raan coefficient",
        "Offset (bits)": "3040"
      },
      {
        "Data Type": "UINT",
        "Description": "Eccentricity filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Ecc coefficient",
        "Offset (bits)": "3056"
      },
      {
        "Data Type": "UINT",
        "Description": "Argument of perigee filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Aop coefficient",
        "Offset (bits)": "3072"
      },
      {
        "Data Type": "UINT",
        "Description": "Time filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Time coefficient",
        "Offset (bits)": "3088"
      },
      {
        "Data Type": "UINT",
        "Description": "Position filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Pos coefficient",
        "Offset (bits)": "3104"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum position error for asgp4 to continue working. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Maximum position error",
        "Offset (bits)": "3120"
      },
      {
        "Data Type": "ENUM",
        "Description": "The type of filter asgp4 is using. Possible values are in Table 193: AsgpFilter Enumeration Values",
        "Length (bits)": "8",
        "Name": "ASGP4 filter",
        "Offset (bits)": "3128"
      },
      {
        "Data Type": "INT",
        "Description": "Polar coefficient xp. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.0000001",
        "Length (bits)": "32",
        "Name": "xp coefficient",
        "Offset (bits)": "3136"
      },
      {
        "Data Type": "INT",
        "Description": "Polar coefficient yp. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.0000001",
        "Length (bits)": "32",
        "Name": "yp coefficient",
        "Offset (bits)": "3168"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS roll over number",
        "Length (bits)": "8",
        "Name": "GPS roll over",
        "Offset (bits)": "3200"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum position standard deviation for asgp4 to operate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Position sd",
        "Offset (bits)": "3208"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum velocity standard deviation for asgp4 to operate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Velocity sd",
        "Offset (bits)": "3216"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum satellites for asgp4 to operate",
        "Length (bits)": "8",
        "Name": "Min. satellites",
        "Offset (bits)": "3224"
      },
      {
        "Data Type": "UINT",
        "Description": "Time offset compensation gain. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Time gain",
        "Offset (bits)": "3232"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum lagged timestamp measurements to incorporate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Max. lag",
        "Offset (bits)": "3240"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum samples to use for asgp4 process",
        "Length (bits)": "16",
        "Name": "Min. samples",
        "Offset (bits)": "3248"
      },
      {
        "Data Type": "ARRAY",
        "Description": "Settings for user coded control mode(s)",
        "Length (bits)": "384",
        "Name": "User Coded Controller Settings",
        "Offset (bits)": "3264"
      },
      {
        "Data Type": "ARRAY",
        "Description": "Settings for user coded estimation mode(s)",
        "Length (bits)": "384",
        "Name": "User Coded Estimator Settings",
        "Offset (bits)": "3648"
      }
    ],
    "Table": "Table 192: ADCS Configuration Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Use LPF",
        "Name": "LPF",
        "Numeric Value": "0"
      },
      {
        "Description": "Use averaging filter",
        "Name": "Average",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 193: AsgpFilter Enumeration Values"
  },
  {
    "Properties": {
      "Description": "SGP4 Orbit Parameters",
      "Parameters Length (bytes)": "64",
      "Set ID/Get ID": "45/207"
    },
    "Rows": [
      {
        "Data Type": "DOUBLE",
        "Description": "Inclination. (Unit of measure is [deg])",
        "Length (bits)": "64",
        "Name": "Inclination",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Eccentricity",
        "Length (bits)": "64",
        "Name": "Eccentricity",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Right-ascension of the Ascending Node. (Unit of measure is [deg])",
        "Length (bits)": "64",
        "Name": "Right-ascension of the Ascending Node",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Argument of Perigee. (Unit of measure is [deg])",
        "Length (bits)": "64",
        "Name": "Argument of Perigee",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "B-Star drag term",
        "Length (bits)": "64",
        "Name": "B-Star drag term",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Mean Motion. (Unit of measure is [orbits/day])",
        "Length (bits)": "64",
        "Name": "Mean Motion",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Mean Anomaly. (Unit of measure is [deg])",
        "Length (bits)": "64",
        "Name": "Mean Anomaly",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "DOUBLE",
        "Description": "Epoch (year.day). (Unit of measure is [year.day])",
        "Length (bits)": "64",
        "Name": "Epoch",
        "Offset (bits)": "448"
      }
    ],
    "Table": "Table 194: SGP4 Orbit Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Set controller gains and reference values for Detumbling control mode",
      "Parameters Length (bytes)": "14",
      "Set ID/Get ID": "38/208"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Detumbling Spin Gain (Ks)",
        "Length (bits)": "32",
        "Name": "Detumbling Spin Gain",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Detumbling Damping Gain (Kd)",
        "Length (bits)": "32",
        "Name": "Detumbling Damping Gain",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "INT",
        "Description": "Reference spin rate (wy-ref). Must always be smaller than 0. Raw parameter value is obtained using the formula: (formatted value) [deg/s] = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Reference spin rate",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Fast BDot Detumbling Gain (Kdf)",
        "Length (bits)": "32",
        "Name": "Fast BDot Detumbling Gain",
        "Offset (bits)": "80"
      }
    ],
    "Table": "Table 195: Set Detumbling Control Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Set controller gains and reference value for Y-wheel control mode",
      "Parameters Length (bytes)": "20",
      "Set ID/Get ID": "39/209"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Y-Momentum Control Gain (Kh)",
        "Length (bits)": "32",
        "Name": "Y-Momentum Control Gain",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Nutation Damping Gain (Kn)",
        "Length (bits)": "32",
        "Name": "Y-momentum Nutation Damping Gain",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Proportional Gain (Kp1)",
        "Length (bits)": "32",
        "Name": "Y-momentum Proportional Gain",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-momentum Derivative Gain (Kd1)",
        "Length (bits)": "32",
        "Name": "Y-momentum Derivative Gain",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Reference Wheel Momentum (H-ref). Must always be smaller than 0. (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "Reference Wheel Momentum",
        "Offset (bits)": "128"
      }
    ],
    "Table": "Table 196: Set Y-Wheel Control Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Set controller gains and reference value for reaction wheel control mode",
      "Parameters Length (bytes)": "13",
      "Set ID/Get ID": "40/217"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "RWheel Proportional Gain (Kp2)",
        "Length (bits)": "32",
        "Name": "RWheel Proportional Gain",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RWheel Derivative Gain (Kd2)",
        "Length (bits)": "32",
        "Name": "RWheel Derivative Gain",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Y-Wheel Bias Momentum (H-bias). (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "Y-Wheel Bias Momentum",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "ENUM",
        "Description": "Satellite body axis that will align with sun vector. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "7",
        "Name": "Sun-pointing Facet",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "BOOL",
        "Description": "Enable/disable automatic transition from wheel control modes to Y-Thomson mode in case of wheel error",
        "Length (bits)": "1",
        "Name": "Automatic Control Transition due to Wheel Errors",
        "Offset (bits)": "103"
      }
    ],
    "Table": "Table 197: Set Reaction Wheel Control Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Set controller gains for tracking control mode",
      "Parameters Length (bytes)": "13",
      "Set ID/Get ID": "54/221"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Proportional Gain (Kp3)",
        "Length (bits)": "32",
        "Name": "Tracking Proportional Gain",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Derivative Gain (Kd3)",
        "Length (bits)": "32",
        "Name": "Tracking Derivative Gain",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Tracking Integral Gain (Ki3)",
        "Length (bits)": "32",
        "Name": "Tracking Integral Gain",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "ENUM",
        "Description": "Satellite body axis that will point to target. Possible values are in Table 180: AxisSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Target-tracking Facet",
        "Offset (bits)": "96"
      }
    ],
    "Table": "Table 198: Set Tracking Controller Gain Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Satellite moment of inertia matrix",
      "Parameters Length (bytes)": "24",
      "Set ID/Get ID": "41/222"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Ixx. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Ixx",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Iyy. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Iyy",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Moment Of Inertia - Izz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Moment Of Inertia - Izz",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Ixy. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Ixy",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Ixz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Ixz",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Product Of Inertia - Iyz. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "Product Of Inertia - Iyz",
        "Offset (bits)": "160"
      }
    ],
    "Table": "Table 199: Moment of Inertia Matrix Message Format"
  },
  {
    "Properties": {
      "Description": "Estimation noise covariance and sensor mask",
      "Parameters Length (bytes)": "31",
      "Set ID/Get ID": "27/223"
    },
    "Rows": [
      {
        "Data Type": "FLOAT",
        "Description": "Magnetometer Rate Filter System Noise",
        "Length (bits)": "32",
        "Name": "Magnetometer Rate Filter System Noise",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "FLOAT",
        "Description": "EKF System Noise",
        "Length (bits)": "32",
        "Name": "EKF System Noise",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "FLOAT",
        "Description": "CSS Measurement Noise",
        "Length (bits)": "32",
        "Name": "CSS Measurement Noise",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Sun Sensor Measurement Noise",
        "Length (bits)": "32",
        "Name": "Sun Sensor Measurement Noise",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Nadir Sensor Measurement Noise",
        "Length (bits)": "32",
        "Name": "Nadir Sensor Measurement Noise",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetometer Measurement Noise",
        "Length (bits)": "32",
        "Name": "Magnetometer Measurement Noise",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Star Tracker Measurement Noise",
        "Length (bits)": "32",
        "Name": "Star Tracker Measurement Noise",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Sun Sensor measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Sun Sensor",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Nadir Sensor measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Nadir Sensor",
        "Offset (bits)": "225"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use CSS measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use CSS",
        "Offset (bits)": "226"
      },
      {
        "Data Type": "BOOL",
        "Description": "Use Star Tracker measurement in EKF",
        "Length (bits)": "1",
        "Name": "Use Star Tracker",
        "Offset (bits)": "227"
      },
      {
        "Data Type": "BOOL",
        "Description": "Select to ignore Nadir sensor measurements when terminator is in FOV",
        "Length (bits)": "1",
        "Name": "Nadir sensor terminator test",
        "Offset (bits)": "228"
      },
      {
        "Data Type": "BOOL",
        "Description": "Select whether automatic switch to redundant magnetometer should occur in case of failure",
        "Length (bits)": "1",
        "Name": "Automatic Magnetometer Recovery",
        "Offset (bits)": "229"
      },
      {
        "Data Type": "ENUM",
        "Description": "Mode describing which magnetometer is used for estimation and control. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Magnetometer Mode",
        "Offset (bits)": "230"
      },
      {
        "Data Type": "ENUM",
        "Description": "Select which magnetometer and sampling to use for 2nd raw magnetometer tlm frame. Possible values are in Table 90: MagModeVal Enumeration Values",
        "Length (bits)": "2",
        "Name": "Magnetometer Selection for RAW MTM TLM",
        "Offset (bits)": "232"
      },
      {
        "Data Type": "BOOL",
        "Description": "Enable/disable automatic transition from MEMS rate estimation mode to RKF in case of rate sensor error",
        "Length (bits)": "1",
        "Name": "Automatic Estimation Transition due to Rate Sensor Errors",
        "Offset (bits)": "234"
      },
      {
        "Data Type": "UINT",
        "Description": "Cam1 and Cam2 sensor sampling period. Lower four bits are Cam1 period and upper four bits the Cam2 period. Setting period to zero for sensor will disable sampling of sensor. (Unit of measure is [s])",
        "Length (bits)": "8",
        "Name": "Cam1 and Cam2 Sampling Period",
        "Offset (bits)": "240"
      }
    ],
    "Table": "Table 200: Estimation Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Current hard-coded system configuration",
      "Parameters Length (bytes)": "173",
      "Set ID/Get ID": "30/225"
    },
    "Rows": [
      {
        "Data Type": "ENUM",
        "Description": "ACP Type. Possible values are in Table 202: AcpProgramType Enumeration Values",
        "Length (bits)": "4",
        "Name": "ACP Type",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ENUM",
        "Description": "Special Control Selection. Possible values are in Table 203: SpecialConSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "Special Control Selection",
        "Offset (bits)": "4"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl Signal Version",
        "Length (bits)": "8",
        "Name": "CubeControl Signal Version",
        "Offset (bits)": "8"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeControl Motor Version",
        "Length (bits)": "8",
        "Name": "CubeControl Motor Version",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense1 Version",
        "Length (bits)": "8",
        "Name": "CubeSense1 Version",
        "Offset (bits)": "24"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeSense2 Version",
        "Length (bits)": "8",
        "Name": "CubeSense2 Version",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense1 Camera Type. Possible values are in Table 204: CsCamType Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense1 Camera Type",
        "Offset (bits)": "40"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense2 Camera Type. Possible values are in Table 204: CsCamType Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense2 Camera Type",
        "Offset (bits)": "44"
      },
      {
        "Data Type": "UINT",
        "Description": "CubeStar Version",
        "Length (bits)": "8",
        "Name": "CubeStar Version",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "ENUM",
        "Description": "GPS Type. Possible values are in Table 205: GpsSelect Enumeration Values",
        "Length (bits)": "4",
        "Name": "GPS Type",
        "Offset (bits)": "56"
      },
      {
        "Data Type": "BOOL",
        "Description": "Redundant MTM Included",
        "Length (bits)": "1",
        "Name": "Redundant MTM Included",
        "Offset (bits)": "60"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetorquer-X Max Dipole. (Unit of measure is [A.m^2])",
        "Length (bits)": "32",
        "Name": "Magnetorquer-X Max Dipole",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetorquer-Y Max Dipole. (Unit of measure is [A.m^2])",
        "Length (bits)": "32",
        "Name": "Magnetorquer-Y Max Dipole",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetorquer-Z Max Dipole. (Unit of measure is [A.m^2])",
        "Length (bits)": "32",
        "Name": "Magnetorquer-Z Max Dipole",
        "Offset (bits)": "128"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetorquer On-time Resolution. (Unit of measure is [s])",
        "Length (bits)": "32",
        "Name": "Magnetorquer On-time Resolution",
        "Offset (bits)": "160"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Magnetorquer Maximum On-time. (Unit of measure is [s])",
        "Length (bits)": "32",
        "Name": "Magnetorquer Maximum On-time",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-X Maximum Torque. (Unit of measure is [N.m])",
        "Length (bits)": "32",
        "Name": "RW-X Maximum Torque",
        "Offset (bits)": "224"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Y Maximum Torque. (Unit of measure is [N.m])",
        "Length (bits)": "32",
        "Name": "RW-Y Maximum Torque",
        "Offset (bits)": "256"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Z Maximum Torque. (Unit of measure is [N.m])",
        "Length (bits)": "32",
        "Name": "RW-Z Maximum Torque",
        "Offset (bits)": "288"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-X Maximum Momentum. (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "RW-X Maximum Momentum",
        "Offset (bits)": "320"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Y Maximum Momentum. (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "RW-Y Maximum Momentum",
        "Offset (bits)": "352"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Z Maximum Momentum. (Unit of measure is [Nms])",
        "Length (bits)": "32",
        "Name": "RW-Z Maximum Momentum",
        "Offset (bits)": "384"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-X Inertia. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "RW-X Inertia",
        "Offset (bits)": "416"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Y Inertia. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "RW-Y Inertia",
        "Offset (bits)": "448"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW-Z Inertia. (Unit of measure is [kg.m^2])",
        "Length (bits)": "32",
        "Name": "RW-Z Inertia",
        "Offset (bits)": "480"
      },
      {
        "Data Type": "FLOAT",
        "Description": "RW Torque Increment. (Unit of measure is [N.m])",
        "Length (bits)": "32",
        "Name": "RW Torque Increment",
        "Offset (bits)": "512"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM X-Bias d1",
        "Length (bits)": "32",
        "Name": "Primary MTM X-Bias d1",
        "Offset (bits)": "544"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Y-Bias d1",
        "Length (bits)": "32",
        "Name": "Primary MTM Y-Bias d1",
        "Offset (bits)": "576"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Z-Bias d1",
        "Length (bits)": "32",
        "Name": "Primary MTM Z-Bias d1",
        "Offset (bits)": "608"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM X-Bias d2",
        "Length (bits)": "32",
        "Name": "Primary MTM X-Bias d2",
        "Offset (bits)": "640"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Y-Bias d2",
        "Length (bits)": "32",
        "Name": "Primary MTM Y-Bias d2",
        "Offset (bits)": "672"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Z-Bias d2",
        "Length (bits)": "32",
        "Name": "Primary MTM Z-Bias d2",
        "Offset (bits)": "704"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM X-Sens s1",
        "Length (bits)": "32",
        "Name": "Primary MTM X-Sens s1",
        "Offset (bits)": "736"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Y-Sens s1",
        "Length (bits)": "32",
        "Name": "Primary MTM Y-Sens s1",
        "Offset (bits)": "768"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Z-Sens s1",
        "Length (bits)": "32",
        "Name": "Primary MTM Z-Sens s1",
        "Offset (bits)": "800"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM X-Sens s2",
        "Length (bits)": "32",
        "Name": "Primary MTM X-Sens s2",
        "Offset (bits)": "832"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Y-Sens s2",
        "Length (bits)": "32",
        "Name": "Primary MTM Y-Sens s2",
        "Offset (bits)": "864"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Primary MTM Z-Sens s2",
        "Length (bits)": "32",
        "Name": "Primary MTM Z-Sens s2",
        "Offset (bits)": "896"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM X-Bias d1",
        "Length (bits)": "32",
        "Name": "Redundant MTM X-Bias d1",
        "Offset (bits)": "928"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Y-Bias d1",
        "Length (bits)": "32",
        "Name": "Redundant MTM Y-Bias d1",
        "Offset (bits)": "960"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Z-Bias d1",
        "Length (bits)": "32",
        "Name": "Redundant MTM Z-Bias d1",
        "Offset (bits)": "992"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM X-Bias d2",
        "Length (bits)": "32",
        "Name": "Redundant MTM X-Bias d2",
        "Offset (bits)": "1024"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Y-Bias d2",
        "Length (bits)": "32",
        "Name": "Redundant MTM Y-Bias d2",
        "Offset (bits)": "1056"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Z-Bias d2",
        "Length (bits)": "32",
        "Name": "Redundant MTM Z-Bias d2",
        "Offset (bits)": "1088"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM X-Sens s1",
        "Length (bits)": "32",
        "Name": "Redundant MTM X-Sens s1",
        "Offset (bits)": "1120"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Y-Sens s1",
        "Length (bits)": "32",
        "Name": "Redundant MTM Y-Sens s1",
        "Offset (bits)": "1152"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Z-Sens s1",
        "Length (bits)": "32",
        "Name": "Redundant MTM Z-Sens s1",
        "Offset (bits)": "1184"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM X-Sens s2",
        "Length (bits)": "32",
        "Name": "Redundant MTM X-Sens s2",
        "Offset (bits)": "1216"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Y-Sens s2",
        "Length (bits)": "32",
        "Name": "Redundant MTM Y-Sens s2",
        "Offset (bits)": "1248"
      },
      {
        "Data Type": "FLOAT",
        "Description": "Redundant MTM Z-Sens s2",
        "Length (bits)": "32",
        "Name": "Redundant MTM Z-Sens s2",
        "Offset (bits)": "1280"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Signal Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Signal Enable Port",
        "Offset (bits)": "1312"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Signal Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Signal Enable Pin",
        "Offset (bits)": "1316"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Motor Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Motor Enable Port",
        "Offset (bits)": "1320"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Motor Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Motor Enable Pin",
        "Offset (bits)": "1324"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Common Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Common Enable Port",
        "Offset (bits)": "1328"
      },
      {
        "Data Type": "ENUM",
        "Description": "CC Common Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CC Common Enable Pin",
        "Offset (bits)": "1332"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense1 Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense1 Enable Port",
        "Offset (bits)": "1336"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense1 Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense1 Enable Pin",
        "Offset (bits)": "1340"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense2 Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense2 Enable Port",
        "Offset (bits)": "1344"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeSense2 Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeSense2 Enable Pin",
        "Offset (bits)": "1348"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeStar Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeStar Enable Port",
        "Offset (bits)": "1352"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeStar Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeStar Enable Pin",
        "Offset (bits)": "1356"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel1 Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel1 Enable Port",
        "Offset (bits)": "1360"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel1 Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel1 Enable Pin",
        "Offset (bits)": "1364"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel2 Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel2 Enable Port",
        "Offset (bits)": "1368"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel2 Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel2 Enable Pin",
        "Offset (bits)": "1372"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel3 Enable GPIO port. Possible values are in Table 206: GpioPort Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel3 Enable Port",
        "Offset (bits)": "1376"
      },
      {
        "Data Type": "ENUM",
        "Description": "CubeWheel3 Enable GPIO port pin. Possible values are in Table 207: GpioPortPin Enumeration Values",
        "Length (bits)": "4",
        "Name": "CubeWheel3 Enable Pin",
        "Offset (bits)": "1380"
      }
    ],
    "Table": "Table 201: ADCS System Configuration Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "3-Axis ACP",
        "Name": "3-Axis ACP",
        "Numeric Value": "0"
      },
      {
        "Description": "Y-Momentum ACP",
        "Name": "Y-Momentum ACP",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 202: AcpProgramType Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "None",
        "Name": "None",
        "Numeric Value": "0"
      },
      {
        "Description": "Z-axis Sun pointing",
        "Name": "Z-axis Sun pointing",
        "Numeric Value": "1"
      },
      {
        "Description": "GEO Tracking",
        "Name": "GEO Tracking",
        "Numeric Value": "2"
      },
      {
        "Description": "Inertial pointing",
        "Name": "Inertial pointing",
        "Numeric Value": "3"
      },
      {
        "Description": "Y-axis Sun pointing",
        "Name": "Y-axis Sun pointing",
        "Numeric Value": "4"
      }
    ],
    "Table": "Table 203: SpecialConSelect Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Sun Sensor",
        "Name": "Sun Sensor",
        "Numeric Value": "0"
      },
      {
        "Description": "Nadir Sensor",
        "Name": "Nadir Sensor",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 204: CsCamType Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "No GPS support",
        "Name": "No GPS Support",
        "Numeric Value": "0"
      },
      {
        "Description": "Novatel GPS",
        "Name": "Novatel GPS",
        "Numeric Value": "1"
      },
      {
        "Description": "Skyfox GPS",
        "Name": "Skyfox GPS",
        "Numeric Value": "2"
      }
    ],
    "Table": "Table 205: GpsSelect Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Port A",
        "Name": "Port A",
        "Numeric Value": "0"
      },
      {
        "Description": "Port B",
        "Name": "Port B",
        "Numeric Value": "1"
      },
      {
        "Description": "Port C",
        "Name": "Port C",
        "Numeric Value": "2"
      },
      {
        "Description": "Port D",
        "Name": "Port D",
        "Numeric Value": "3"
      },
      {
        "Description": "Port E",
        "Name": "Port E",
        "Numeric Value": "4"
      },
      {
        "Description": "Port F",
        "Name": "Port F",
        "Numeric Value": "5"
      }
    ],
    "Table": "Table 206: GpioPort Enumeration Values"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Pin 0",
        "Name": "Pin 0",
        "Numeric Value": "0"
      },
      {
        "Description": "Pin 1",
        "Name": "Pin 1",
        "Numeric Value": "1"
      },
      {
        "Description": "Pin 2",
        "Name": "Pin 2",
        "Numeric Value": "2"
      },
      {
        "Description": "Pin 3",
        "Name": "Pin 3",
        "Numeric Value": "3"
      },
      {
        "Description": "Pin 4",
        "Name": "Pin 4",
        "Numeric Value": "4"
      },
      {
        "Description": "Pin 5",
        "Name": "Pin 5",
        "Numeric Value": "5"
      },
      {
        "Description": "Pin 6",
        "Name": "Pin 6",
        "Numeric Value": "6"
      },
      {
        "Description": "Pin 7",
        "Name": "Pin 7",
        "Numeric Value": "7"
      },
      {
        "Description": "Pin 8",
        "Name": "Pin 8",
        "Numeric Value": "8"
      },
      {
        "Description": "Pin 9",
        "Name": "Pin 9",
        "Numeric Value": "9"
      },
      {
        "Description": "Pin 10",
        "Name": "Pin 10",
        "Numeric Value": "10"
      },
      {
        "Description": "Pin 11",
        "Name": "Pin 11",
        "Numeric Value": "11"
      },
      {
        "Description": "Pin 12",
        "Name": "Pin 12",
        "Numeric Value": "12"
      },
      {
        "Description": "Pin 13",
        "Name": "Pin 13",
        "Numeric Value": "13"
      },
      {
        "Description": "Pin 14",
        "Name": "Pin 14",
        "Numeric Value": "14"
      },
      {
        "Description": "Pin 15",
        "Name": "Pin 15",
        "Numeric Value": "15"
      }
    ],
    "Table": "Table 207: GpioPortPin Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Settings for user-coded estimation and control modes",
      "Parameters Length (bytes)": "96",
      "Set ID/Get ID": "29/226"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Settings for user coded control mode(s)",
        "Length (bits)": "384",
        "Name": "User Coded Controller Settings",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "ARRAY",
        "Description": "Settings for user coded estimation mode(s)",
        "Length (bits)": "384",
        "Name": "User Coded Estimator Settings",
        "Offset (bits)": "384"
      }
    ],
    "Table": "Table 208: User-coded Controller and Estimator Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Settings for GPS augmented SGP4",
      "Parameters Length (bytes)": "30",
      "Set ID/Get ID": "28/227"
    },
    "Rows": [
      {
        "Data Type": "UINT",
        "Description": "Inclination filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Incl. coefficient",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "RAAN filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Raan coefficient",
        "Offset (bits)": "16"
      },
      {
        "Data Type": "UINT",
        "Description": "Eccentricity filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Ecc coefficient",
        "Offset (bits)": "32"
      },
      {
        "Data Type": "UINT",
        "Description": "Argument of perigee filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Aop coefficient",
        "Offset (bits)": "48"
      },
      {
        "Data Type": "UINT",
        "Description": "Time filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Time coefficient",
        "Offset (bits)": "64"
      },
      {
        "Data Type": "UINT",
        "Description": "Position filter coefficient. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.001",
        "Length (bits)": "16",
        "Name": "Pos coefficient",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum position error for asgp4 to continue working. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Maximum position error",
        "Offset (bits)": "96"
      },
      {
        "Data Type": "ENUM",
        "Description": "The type of filter asgp4 is using. Possible values are in Table 193: AsgpFilter Enumeration Values",
        "Length (bits)": "8",
        "Name": "ASGP4 filter",
        "Offset (bits)": "104"
      },
      {
        "Data Type": "INT",
        "Description": "Polar coefficient xp. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.0000001",
        "Length (bits)": "32",
        "Name": "xp coefficient",
        "Offset (bits)": "112"
      },
      {
        "Data Type": "INT",
        "Description": "Polar coefficient yp. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.0000001",
        "Length (bits)": "32",
        "Name": "yp coefficient",
        "Offset (bits)": "144"
      },
      {
        "Data Type": "UINT",
        "Description": "GPS roll over number",
        "Length (bits)": "8",
        "Name": "GPS roll over",
        "Offset (bits)": "176"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum position standard deviation for asgp4 to operate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.1",
        "Length (bits)": "8",
        "Name": "Position sd",
        "Offset (bits)": "184"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum velocity standard deviation for asgp4 to operate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Velocity sd",
        "Offset (bits)": "192"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum satellites for asgp4 to operate",
        "Length (bits)": "8",
        "Name": "Min. satellites",
        "Offset (bits)": "200"
      },
      {
        "Data Type": "UINT",
        "Description": "Time offset compensation gain. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Time gain",
        "Offset (bits)": "208"
      },
      {
        "Data Type": "UINT",
        "Description": "Maximum lagged timestamp measurements to incorporate. Raw parameter value is obtained using the formula: (formatted value) = RAWVAL*0.01",
        "Length (bits)": "8",
        "Name": "Max. lag",
        "Offset (bits)": "216"
      },
      {
        "Data Type": "UINT",
        "Description": "Minimum samples to use for asgp4 process",
        "Length (bits)": "16",
        "Name": "Min. samples",
        "Offset (bits)": "224"
      }
    ],
    "Table": "Table 209: Augmented-SGP4 Parameters Message Format"
  },
  {
    "Properties": {
      "Description": "Log selection and period for LOG1",
      "Parameters Length (bytes)": "13",
      "Set ID/Get ID": "104/235"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Log Selection - up to 80 flags indicating which telemetry frames should be logged",
        "Length (bits)": "80",
        "Name": "Log Selection",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Log period. Set to 0 to disable logging",
        "Length (bits)": "16",
        "Name": "Log Period",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "ENUM",
        "Description": "Which SD card to use to store log file. Possible values are in Table 211: SdLogSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Log Destination",
        "Offset (bits)": "96"
      }
    ],
    "Table": "Table 210: SD Log1 Configuration Message Format"
  },
  {
    "Properties": {},
    "Rows": [
      {
        "Description": "Use Primary (on-board) SD card for log file",
        "Name": "Primary SD Card",
        "Numeric Value": "0"
      },
      {
        "Description": "Use Secondary SD card for log file",
        "Name": "Secondary SD Card",
        "Numeric Value": "1"
      }
    ],
    "Table": "Table 211: SdLogSelect Enumeration Values"
  },
  {
    "Properties": {
      "Description": "Log selection and period for LOG2",
      "Parameters Length (bytes)": "13",
      "Set ID/Get ID": "105/236"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Log Selection - up to 80 flags indicating which telemetry frames should be logged",
        "Length (bits)": "80",
        "Name": "Log Selection",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Log period. Set to 0 to disable logging",
        "Length (bits)": "16",
        "Name": "Log Period",
        "Offset (bits)": "80"
      },
      {
        "Data Type": "ENUM",
        "Description": "Which SD card to use to store log file. Possible values are in Table 211: SdLogSelect Enumeration Values",
        "Length (bits)": "8",
        "Name": "Log Destination",
        "Offset (bits)": "96"
      }
    ],
    "Table": "Table 212: SD Log2 Configuration Message Format"
  },
  {
    "Properties": {
      "Description": "Log selection and period for UART (unsolicited TLM)",
      "Parameters Length (bytes)": "12",
      "Set ID/Get ID": "106/237"
    },
    "Rows": [
      {
        "Data Type": "ARRAY",
        "Description": "Log Selection - up to 80 flags indicating which telemetry frames should be logged",
        "Length (bits)": "80",
        "Name": "Log Selection",
        "Offset (bits)": "0"
      },
      {
        "Data Type": "UINT",
        "Description": "Log period. Set to 0 to disable logging",
        "Length (bits)": "16",
        "Name": "Log Period",
        "Offset (bits)": "80"
      }
    ],
    "Table": "Table 213: UART Log Configuration Message Format"
  }
])END";
}

}
