#!/bin/bash

rm -rf rootfs
make install DESTDIR=rootfs
tar czf "Nebula-$(git describe --tags --long --dirty=+)-$(date "+%Y-%m-%d").tar.gz" rootfs
