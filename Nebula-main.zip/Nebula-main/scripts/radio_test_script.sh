#!/bin/bash

# This script will be run by the detector during the radio test

# Update the addresses when you run this for real
CURRENT_PI_ADDRESS='127.0.0.1'
DET_ADDRESS='127.0.0.1'
DET_PROCESS_PORT=61999

COMS_ADDRESS='127.0.0.1:12345'
CDH_ADDRESS='127.0.0.1:12345'

# Health listener (udp_capture on the detector Pi)
UDPCAP_ADDRESS='127.0.0.1:61100'

# 1. init the detector process (init command)
echo "../bin/ni_send -a '$CURRENT_PI_ADDRESS' -s '$DET_ADDRESS' -p '$DET_PROCESS_PORT' -m 'init' -d" | at -M now

# 2. start periodic health collection every N seconds. doesn't matter how often. maybe every 5s?
echo "../bin/ni_send -a '$CURRENT_PI_ADDRESS' -s '$DET_ADDRESS' -p '$DET_PROCESS_PORT' -m 'start-periodic-health 10 $COMS_ADDRESS $CDH_ADDRESS $UDPCAP_ADDRESS' -d" | at -M now

# 3. start nominal
echo "../bin/ni_send -a '$CURRENT_PI_ADDRESS' -s '$DET_ADDRESS' -p '$DET_PROCESS_PORT' -m 'start-nominal' -d" | at -M now

# 4. wait 10 minutes
# 5. send the "shutdown" command to the process
echo "../bin/ni_send -a '$CURRENT_PI_ADDRESS' -s '$DET_ADDRESS' -p '$DET_PROCESS_PORT' -m 'shutdown' -d" | at -M now + 10 minutes


# after that the detector is done. what remains is
# 6. scp the files over from the detector Pi. they will be in /home/smallsat/downlink/*.gz
# 7. gzip all the flies into one big archive, or send them one by one.

# 8. send the files down to the ground
# ???
# 9. put all the files in a folder and we can run a script to read them all in and plot stuff to make sure it looks good
# ???
